/* Novel Reader service worker v5 — multi-site, offline-first, bundled fonts */
const CACHE_STATIC = 'novel-reader-v5-static';
const CACHE_IMG = 'novel-reader-v5-img';
const CACHE_API = 'novel-reader-v5-api';
const CACHE_HTML = 'novel-reader-v5-html';

const STATIC_ASSETS = [
  '/', '/home.html', '/index.html', '/catalog.html',
  '/admin.html', '/detail.html', '/reader.html',
  '/settings.html', '/stats.html', '/search.html', '/login.html',
  '/history.html', '/highlights.html', '/achievements.html', '/goals.html',
  '/updates.html', '/wiki.html', '/queue.html', '/komikku.html',
  '/discover.html',
  '/style.css', '/app.js', '/manifest.json',
  // Bundled Persian font (was previously loaded from Google CDN — broke offline)
  '/fonts/Vazirmatn-Regular.woff2',
  '/fonts/Vazirmatn-Medium.woff2',
  '/fonts/Vazirmatn-Bold.woff2',
  '/icons/favicon.svg', '/icons/icon-192.png', '/icons/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    Promise.all([
      caches.open(CACHE_STATIC).then(c => c.addAll(STATIC_ASSETS).catch(err => {
        console.warn('SW: some assets failed to cache', err);
      })),
      // Pre-warm image and API caches
      caches.open(CACHE_IMG),
      caches.open(CACHE_API),
      caches.open(CACHE_HTML)
    ]).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys
        .filter(k => ![CACHE_STATIC, CACHE_IMG, CACHE_API, CACHE_HTML].includes(k))
        .map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  // Don't intercept SSE
  if (url.pathname === '/api/events') return;

  // Never intercept non-GET
  if (e.request.method !== 'GET') {
    e.respondWith(fetch(e.request));
    return;
  }

  /* ---- Image proxy: cache-first, long TTL ---- */
  if (url.pathname === '/api/img' && url.searchParams.has('src')) {
    e.respondWith(
      caches.open(CACHE_IMG).then(c => c.match(e.request).then(cached => {
        if (cached) {
          // background refresh
          fetch(e.request).then(r => {
            if (r && r.status === 200) c.put(e.request, r.clone()).catch(() => {});
          }).catch(() => {});
          return cached;
        }
        return fetch(e.request).then(r => {
          if (r && r.status === 200) c.put(e.request, r.clone()).catch(() => {});
          return r;
        }).catch(() => new Response('', { status: 404 }));
      }))
    );
    return;
  }

  /* ---- HTML pages: stale-while-revalidate ---- */
  const isHtml = url.pathname === '/' ||
                 url.pathname.startsWith('/') && (
                   url.pathname.endsWith('.html') ||
                   ['/home', '/library', '/catalog', '/discover', '/read', '/detail',
                    '/admin', '/settings', '/stats', '/search', '/login',
                    '/history', '/highlights', '/achievements', '/goals',
                    '/updates', '/wiki', '/queue', '/komikku'].includes(url.pathname)
                 );

  if (isHtml) {
    e.respondWith(
      caches.open(CACHE_HTML).then(c => c.match(e.request).then(cached => {
        const networkFetch = fetch(e.request).then(resp => {
          if (resp && resp.status === 200) {
            const copy = resp.clone();
            c.put(e.request, copy).catch(() => {});
          }
          return resp;
        }).catch(() => cached || caches.match('/home.html') || caches.match('/'));
        return cached || networkFetch;
      }))
    );
    return;
  }

  /* ---- API: network-first with API cache fallback (for GET only) ---- */
  if (url.pathname.startsWith('/api/')) {
    // Some read APIs benefit from caching (novels, sources, genres)
    const cacheableApis = ['/api/novels', '/api/discover/sources', '/api/discover/genres',
                          '/api/stats', '/api/settings', '/api/bookmarks',
                          '/api/jobs', '/api/updates', '/api/queue',
                          '/api/highlights', '/api/goals', '/api/achievements',
                          '/api/reading/sessions', '/api/reading/stats'];
    const isCacheable = cacheableApis.some(api => url.pathname === api || url.pathname.startsWith(api + '?'));
    if (isCacheable) {
      e.respondWith(
        fetch(e.request).then(resp => {
          if (resp && resp.status === 200) {
            const copy = resp.clone();
            caches.open(CACHE_API).then(c => c.put(e.request, copy)).catch(() => {});
          }
          return resp;
        }).catch(() =>
          caches.open(CACHE_API).then(c => c.match(e.request).then(cached =>
            cached || new Response(JSON.stringify({ error: 'offline', cached: false }),
              { status: 503, headers: { 'Content-Type': 'application/json' } })
          ))
        )
      );
      return;
    }
    // Non-cacheable API: network only, fail on offline
    e.respondWith(
      fetch(e.request).catch(() => new Response(
        JSON.stringify({ error: 'offline', message: 'این قابلیت نیاز به اینترنت دارد' }),
        { status: 503, headers: { 'Content-Type': 'application/json' } }
      ))
    );
    return;
  }

  /* ---- Other static assets (CSS, JS, icons): stale-while-revalidate ---- */
  e.respondWith(
    caches.open(CACHE_STATIC).then(c => c.match(e.request).then(cached => {
      const networkFetch = fetch(e.request).then(resp => {
        if (resp && resp.status === 200) {
          const copy = resp.clone();
          c.put(e.request, copy).catch(() => {});
        }
        return resp;
      }).catch(() => cached);
      return cached || networkFetch;
    }))
  );
});

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting') self.skipWaiting();
  if (e.data === 'clearCaches') {
    Promise.all([
      caches.delete(CACHE_IMG),
      caches.delete(CACHE_API),
      caches.delete(CACHE_HTML),
      caches.delete(CACHE_STATIC)
    ]).then(() => {
      e.source && e.source.postMessage({ cleared: true });
    });
  }
});
