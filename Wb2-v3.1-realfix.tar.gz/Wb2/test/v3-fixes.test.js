'use strict';
/**
 * v3 Fixes Test Suite — verifies that the "mega update" actually fixed
 * the critical bugs identified in the audit.
 */
const path = require('path');
const fs = require('fs');
const assert = require('assert');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ✓ ' + name); }
  catch (e) { failed++; console.log('  ✗ ' + name + '\n    ' + e.message); }
}
async function testAsync(name, fn) {
  try { await fn(); passed++; console.log('  ✓ ' + name); }
  catch (e) { failed++; console.log('  ✗ ' + name + '\n    ' + e.message); }
}

// Use a temp DB location for the test
process.env.NODE_ENV = 'test';
const TMP_DIR = path.join(__dirname, '..', 'data-test-v3');
fs.mkdirSync(TMP_DIR, { recursive: true });

// We need to monkey-patch db before requiring — set SQLITE_PATH
// Actually easier: just require db (uses default path) and clean up test data

const db = require('../lib/db');
const scraper = require('../lib/scraper');
const translator = require('../lib/translator');
const recommend = require('../lib/recommend');
const auth = require('../lib/auth');
const rateLimit = require('../lib/rateLimit');

console.log('\nv3 Fixes Tests:\n');

/* 1. Route shadowing fix — verified by reading server.js source */
test('server.js has no route shadowing (sub-routes before /api/novel/:id)', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  // The specific routes (/chapters, /tags, /wiki) must appear BEFORE the generic
  const genericIdx = src.indexOf("if (m === 'GET' && p.startsWith('/api/novel/')) {");
  const chaptersIdx = src.indexOf("p.startsWith('/api/novel/') && p.endsWith('/chapters')");
  const tagsIdx = src.indexOf("p.startsWith('/api/novel/') && p.endsWith('/tags')");
  const wikiIdx = src.indexOf("p.startsWith('/api/novel/') && p.endsWith('/wiki')");
  assert.ok(genericIdx > 0, 'generic route exists');
  assert.ok(chaptersIdx > 0 && chaptersIdx < genericIdx, 'chapters route before generic');
  assert.ok(tagsIdx > 0 && tagsIdx < genericIdx, 'tags route before generic');
  assert.ok(wikiIdx > 0 && wikiIdx < genericIdx, 'wiki route before generic');
});

/* 2. listPendingJobs exists and returns FIFO order */
test('db.listPendingJobs exists and returns oldest-first', () => {
  assert.strictEqual(typeof db.listPendingJobs, 'function');
  // Create some jobs in different states
  const id1 = db.createJob('scrape', { url: 'http://x', n: 1 });
  const id2 = db.createJob('scrape', { url: 'http://x', n: 2 });
  const id3 = db.createJob('scrape', { url: 'http://x', n: 3 });
  // Mark id2 as done — should NOT appear in pending list
  db.updateJob(id2, { status: 'done' });
  const pending = db.listPendingJobs(10);
  const ids = pending.map(j => j.id);
  assert.ok(ids.includes(id1), 'id1 in pending');
  assert.ok(ids.includes(id3), 'id3 in pending');
  assert.ok(!ids.includes(id2), 'id2 (done) NOT in pending');
  // Order should be id1 before id3 (FIFO)
  assert.ok(ids.indexOf(id1) < ids.indexOf(id3), 'FIFO order: id1 before id3');
  // Cleanup
  db.updateJob(id1, { status: 'cancelled' });
  db.updateJob(id3, { status: 'cancelled' });
});

/* 3. SSRF protection in /api/img — verified by checking scraper.isAllowed */
test('scraper.isAllowed supports wildcard patterns (booktoki*.com)', () => {
  // Save original allowedDomains
  assert.ok(scraper.isAllowed('booktoki123.com'), 'booktoki123.com matches booktoki*.com');
  assert.ok(scraper.isAllowed('booktoki.com'), 'booktoki.com matches booktoki*.com');
  assert.ok(scraper.isAllowed('sub.booktoki.com'), 'subdomain of booktoki*.com matches');
  assert.ok(!scraper.isAllowed('example.com'), 'example.com does NOT match booktoki*.com');
  // URL form
  assert.ok(scraper.isAllowed('https://booktoki123.com/page'), 'URL form works');
  assert.ok(!scraper.isAllowed('http://169.254.169.254/metadata'), 'AWS metadata IP blocked');
  assert.ok(!scraper.isAllowed('http://localhost:8080/admin'), 'localhost blocked');
});

/* 4. Auth: timing-safe comparison + brute-force lockout */
test('auth uses timing-safe comparison (no plaintext !==)', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'auth.js'), 'utf8');
  assert.ok(src.includes('timingSafeEqual'), 'uses crypto.timingSafeEqual');
  assert.ok(!/password !== [^;]+;/.test(src) || !src.includes('if (password !=='), 'no plaintext password !==');
  // Brute-force protection
  assert.ok(src.includes('recordFailure'), 'has recordFailure');
  assert.ok(src.includes('isLocked'), 'has isLocked');
  assert.ok(src.includes('MAX_FAILURES'), 'has MAX_FAILURES');
});

test('auth brute-force lockout activates after 5 failures', () => {
  const ip = 'test-ip-' + Date.now();
  const internal = auth._internal;
  // 5 failed logins
  for (let i = 0; i < 5; i++) {
    auth.login('wrong', 'wrong', { ip });
  }
  // 6th should be locked out
  assert.ok(internal.isLocked(ip), 'IP locked after 5 failures');
  assert.ok(internal.getLockMsRemaining(ip) > 0, 'lock has remaining time');
  internal.clearFailures(ip);
});

/* 5. rateLimit: doesn't trust X-Forwarded-For by default */
test('rateLimit does NOT trust X-Forwarded-For by default', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'rateLimit.js'), 'utf8');
  // Check that x-forwarded-for is only used when TRUST_PROXY is set
  assert.ok(src.includes('TRUST_PROXY'), 'has TRUST_PROXY config check');
  assert.ok(src.includes('trustProxy'), 'has trustProxy config field');
  // Verify default behavior
  const fakeReq = {
    headers: { 'x-forwarded-for': '1.2.3.4' },
    socket: { remoteAddress: '127.0.0.1' }
  };
  const ip = rateLimit.getClientIp(fakeReq);
  // Default config has trustProxy = false, so should use socket IP
  assert.strictEqual(ip, '127.0.0.1', 'uses socket IP when trustProxy=false');
});

/* 6. PDF module is Persian-aware */
test('pdf.js has Persian shaping + font embedding', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'pdf.js'), 'utf8');
  assert.ok(src.includes('pdfkit'), 'uses pdfkit');
  assert.ok(src.includes('arabic-reshaper'), 'uses arabic-reshaper');
  assert.ok(src.includes('shapePersian'), 'has shapePersian function');
  assert.ok(src.includes('Vazirmatn'), 'embeds Vazirmatn font');
  assert.ok(src.includes('isPersian'), 'has isPersian detection');
  assert.ok(src.includes('addPage'), 'paginates properly');
  // Should NOT have the old truncation
  assert.ok(!src.includes('slice(0, 50)'), 'no 50-chapter truncation');
  assert.ok(!src.includes('slice(0, 2000)'), 'no 2000-char truncation');
});

/* 7. importAll restores all data types */
test('db.importAll restores chapters + bookmarks + glossary + sessions', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'db.js'), 'utf8');
  // The new importAll must handle these data types
  assert.ok(src.includes('chapterIdMap'), 'has chapter ID mapping');
  assert.ok(src.includes('novelIdMap'), 'has novel ID mapping');
  assert.ok(src.includes('tagIdMap'), 'has tag ID mapping');
  // Must import these (previously only novels)
  ['chapters', 'bookmarks', 'glossary', 'sessions', 'highlights', 'tags', 'wiki', 'achievements', 'goals', 'queue', 'variants'].forEach(t => {
    assert.ok(src.includes('data.' + t), 'handles data.' + t);
  });
});

/* 8. Translator: SOCKS5 support + glossary caching + scoreTranslation */
test('translator.js supports SOCKS5 proxy + glossary cache + scoreTranslation', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'translator.js'), 'utf8');
  assert.ok(src.includes("require('./socks5')"), 'uses socks5 client');
  assert.ok(src.includes('_PROXY_KIND'), 'tracks proxy kind');
  assert.ok(src.includes('socks'), 'handles socks scheme');
  // Glossary cache
  assert.ok(src.includes('_glossaryCache'), 'has glossary cache');
  assert.ok(src.includes('GLOSSARY_CACHE_TTL'), 'has cache TTL');
  assert.ok(src.includes('bustGlossaryCache'), 'has cache buster');
  // Quality scoring
  assert.ok(src.includes('scoreTranslation'), 'exports scoreTranslation');
  // Env var support
  assert.ok(src.includes('NR_'), 'supports NR_ env vars');
  assert.ok(src.includes('process.env'), 'reads process.env');
});

/* 9. Env var support: API keys from env override config */
test('translator prefers NR_<PROVIDER>_API_KEY env var over config', () => {
  // Set env var for opencode
  process.env.NR_OPENCODE_API_KEY = 'test-key-from-env-1234567890';
  const { cfg } = translator.getProviderCfg('opencode');
  assert.strictEqual(cfg.apiKey, 'test-key-from-env-1234567890', 'env var overrides config');
  assert.ok(translator.isConfigured('opencode'), 'provider considered configured via env');
  delete process.env.NR_OPENCODE_API_KEY;
});

/* 10. Discovery: checkForUpdates uses correct field name + arg types */
test('discovery.checkForUpdates uses source_url (snake_case) + numeric newChapters', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'discovery.js'), 'utf8');
  assert.ok(src.includes('novel.source_url || novel.sourceUrl'), 'reads snake_case source_url');
  // Should NOT pass objects as 3rd arg to setUpdateStatus
  assert.ok(!src.includes("{ new_chapters_count:"), 'no object arg to setUpdateStatus');
  assert.ok(!src.includes("{ error:"), 'no object arg for error case');
  // Should use modest limit (200) instead of 10000
  assert.ok(!src.includes('limit: 10000'), 'no 10000-chapter fetch');
});

/* 11. Recommend: no N+1 (sessions fetched once) */
test('recommend.js fetches sessions once (no N+1)', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'recommend.js'), 'utf8');
  // Strip comments before checking for the old buggy pattern
  const code = src.replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
  // getSessions must be called OUTSIDE the .map() loop
  assert.ok(code.includes('const allSessions = db.getSessions'), 'fetches all sessions once');
  assert.ok(code.includes('otherNovelIds'), 'builds set of other novel IDs');
  // The old buggy pattern was: db.getSessions({ limit: 500 }) called inside the loop
  // over targetSessions. The new code should NOT have that pattern.
  assert.ok(!code.includes('for (const s of targetSessions)'), 'no per-target-session loop');
  assert.ok(!/db\.getSessions\(\{\s*limit:\s*500\s*\}\)/.test(code), 'no per-iteration getSessions(500)');
});

/* 12. Queue: passes range opts + checks cancellation */
test('queue.js passes range opts + checks for cancellation', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'queue.js'), 'utf8');
  // runScrape must destructure startChapter/endChapter
  assert.ok(src.includes('startChapter, endChapter, translateRange'), 'runScrape destructures range');
  // runTranslateNovel must filter by range
  assert.ok(src.includes('startChapter != null') && src.includes('endChapter != null'), 'translate novel filters by range');
  // Cancellation check
  assert.ok(src.includes('isCancelled'), 'has isCancelled helper');
  assert.ok(src.includes('if (isCancelled(jobId))'), 'worker checks cancellation');
});

/* 13. config.json: no hardcoded API keys */
test('config.json has no hardcoded API keys (all empty)', () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.json'), 'utf8'));
  for (const [name, p] of Object.entries(cfg.translator.providers || {})) {
    assert.strictEqual(p.apiKey, '', `provider ${name} apiKey must be empty`);
  }
});

/* 14. .env.example exists */
test('.env.example exists and documents NR_ env vars', () => {
  const envPath = path.join(__dirname, '..', '.env.example');
  assert.ok(fs.existsSync(envPath), '.env.example exists');
  const content = fs.readFileSync(envPath, 'utf8');
  assert.ok(content.includes('NR_OPENCODE_API_KEY'), 'documents NR_OPENCODE_API_KEY');
  assert.ok(content.includes('NR_SESSION_SECRET'), 'documents NR_SESSION_SECRET');
  assert.ok(content.includes('NR_TRUST_PROXY'), 'documents NR_TRUST_PROXY');
});

/* 15. Vazirmatn font bundled locally (no Google CDN dependency) */
test('Vazirmatn fonts bundled in public/fonts/ (no Google CDN)', () => {
  const fontsDir = path.join(__dirname, '..', 'public', 'fonts');
  assert.ok(fs.existsSync(path.join(fontsDir, 'Vazirmatn-Regular.woff2')), 'Vazirmatn-Regular.woff2 exists');
  assert.ok(fs.existsSync(path.join(fontsDir, 'Vazirmatn-Bold.woff2')), 'Vazirmatn-Bold.woff2 exists');
  // CSS should NOT have Google CDN import anymore
  const css = fs.readFileSync(path.join(__dirname, '..', 'public', 'style.css'), 'utf8');
  assert.ok(!css.includes('fonts.googleapis.com'), 'no Google Fonts CDN reference');
  assert.ok(css.includes('@font-face'), 'uses @font-face declarations');
});

/* 16. Server has OPDS + stats export + quality scoring endpoints */
test('server.js has OPDS, stats export, and quality scoring endpoints', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.ok(src.includes('/opds'), 'has OPDS endpoint');
  assert.ok(src.includes('/api/stats/export'), 'has stats export endpoint');
  assert.ok(src.includes('/api/translate/score'), 'has quality scoring endpoint');
  assert.ok(src.includes('escXml'), 'has XML escaping helper');
});

/* 17. Package.json version is 3.0+ */
test('package.json version bumped to 3.0+', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  const major = parseInt(pkg.version.split('.')[0]);
  assert.ok(major >= 3, `version >= 3.0 (got ${pkg.version})`);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
