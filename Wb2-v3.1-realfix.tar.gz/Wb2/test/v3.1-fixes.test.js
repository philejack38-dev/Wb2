'use strict';
/**
 * v3.1 Mega Update Test Suite — verifies translator quality improvements,
 * Komikku extension installer, and VPS install script.
 */
const path = require('path');
const fs = require('fs');
const assert = require('assert');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ✓ ' + name); }
  catch (e) { failed++; console.log('  ✗ ' + name + '\n    ' + e.message); }
}

const translator = require('../lib/translator');
const installer = require('../lib/extensions-installer');

console.log('\nv3.1 Mega Update Tests:\n');

/* 1. Translator: system + user prompt separation */
test('translator has buildSystemPrompt + buildUserPrompt', () => {
  assert.strictEqual(typeof translator.buildSystemPrompt, 'function');
  assert.strictEqual(typeof translator.buildUserPrompt, 'function');
  const sys = translator.buildSystemPrompt({ sourceText: '罗冠' });
  const usr = translator.buildUserPrompt('罗冠', {});
  assert.ok(sys.includes('WEB NOVEL'), 'system prompt mentions web novel');
  assert.ok(sys.includes('OUTPUT CONTRACT'), 'system prompt has output contract');
  assert.ok(usr.includes('SOURCE TEXT TO TRANSLATE'), 'user prompt has source text marker');
  assert.ok(!sys.includes('SOURCE TEXT TO TRANSLATE'), 'system prompt does NOT contain source text');
});

/* 2. Translator: glossary filtering (only terms appearing in chunk) */
test('filterGlossaryForChunk only includes relevant terms', () => {
  const allGlossary = translator.buildGlossaryText(null);
  const sourceWithCultivation = '他运转灵气，丹田中金光大盛。';  // contains 灵气
  const filtered = translator.filterGlossaryForChunk(allGlossary, sourceWithCultivation);
  assert.ok(filtered.includes('灵气'), '灵气 included (appears in source)');
  assert.ok(!filtered.includes('妖兽'), '妖兽 excluded (does NOT appear in source)');
});

/* 3. Translator: validation function */
test('validateTranslation detects bad output', () => {
  const src = '罗冠站在江宁城外，望着远处的青山。他运转灵气，丹田中金光大盛。';
  assert.ok(translator.validateTranslation(src, 'لوگوان بیرون شهر ایستاده بود.').ok, 'good translation passes');
  assert.ok(!translator.validateTranslation(src, '').ok, 'empty fails');
  assert.ok(!translator.validateTranslation(src, src).ok, 'echo fails');
  assert.ok(!translator.validateTranslation(src, '```markdown\nhello\n```').ok, 'markdown fence fails');
  assert.ok(!translator.validateTranslation(src, 'Translation: hello').ok, '"Translation:" prefix fails');
  // Paragraph count mismatch
  const longSrc = Array(10).fill('一段中文段落').join('\n\n');
  const shortTrans = 'فقط یک پاراگراف';
  assert.ok(!translator.validateTranslation(longSrc, shortTrans).ok, 'paragraph count too low fails');
});

/* 4. Translator: callProvider supports system+user messages */
test('callProvider accepts systemPrompt in opts', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'translator.js'), 'utf8');
  assert.ok(src.includes('opts.systemPrompt'), 'callProvider reads opts.systemPrompt');
  assert.ok(src.includes("role: 'system'"), 'uses system role for OpenAI-compatible');
  assert.ok(src.includes('body.system = systemText'), 'anthropic uses body.system');
  assert.ok(src.includes('body.systemInstruction'), 'gemini uses systemInstruction');
});

/* 5. Translator: style guide has expanded principles + few-shot */
test('style-guide.json has expanded principles + few-shot examples', () => {
  const sg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'lib', 'style-guide.json'), 'utf8'));
  assert.ok(sg.style_principles.length >= 15, `at least 15 principles (got ${sg.style_principles.length})`);
  assert.ok(sg.few_shot.length >= 5, `at least 5 few-shot examples (got ${sg.few_shot.length})`);
  // Check for new specific principles
  assert.ok(sg.style_principles.some(p => p.includes('guillemets')), 'mentions guillemets');
  assert.ok(sg.style_principles.some(p => p.includes('pro-drop') || p.includes('Pronouns')), 'mentions pro-drop');
  assert.ok(sg.style_principles.some(p => p.includes('Persian comma')), 'mentions Persian comma');
});

/* 6. Extensions installer module: HONEST API (no fake 'install' anymore) */
test('extensions-installer.js has honest API (bookmark, not install)', () => {
  assert.strictEqual(typeof installer.bookmark, 'function', 'has bookmark()');
  assert.strictEqual(typeof installer.unbookmark, 'function', 'has unbookmark()');
  assert.strictEqual(typeof installer.listBookmarked, 'function', 'has listBookmarked()');
  assert.strictEqual(typeof installer.isBookmarked, 'function', 'has isBookmarked()');
  assert.strictEqual(typeof installer.detectAdapter, 'function', 'has detectAdapter()');
  assert.strictEqual(typeof installer.getSupportedSources, 'function', 'has getSupportedSources()');
  // Must NOT have misleading install/uninstall functions anymore
  assert.strictEqual(typeof installer.install, 'undefined', 'NO install() function (was misleading)');
  assert.strictEqual(typeof installer.uninstall, 'undefined', 'NO uninstall() function (was misleading)');
  assert.strictEqual(typeof installer.listInstalled, 'undefined', 'NO listInstalled() (renamed to listBookmarked)');
  assert.strictEqual(typeof installer.isInstalled, 'undefined', 'NO isInstalled() (renamed to isBookmarked)');
});

/* 7. detectAdapter honestly returns null for sources that don't work */
test('detectAdapter only returns adapters for VERIFIED working sources', () => {
  // NovelFull is verified working
  assert.strictEqual(installer.detectAdapter('https://novelfull.com/x'), 'novelfull');
  assert.strictEqual(installer.detectAdapter('https://www.novelfull.com/x'), 'novelfull');
  // These have adapters in code but their sites block us — must return null
  // so the UI shows them as 'browse only' honestly
  assert.strictEqual(installer.detectAdapter('https://www.royalroad.com/fiction/1'), null, 'royalroad returns null (Cloudflare 403)');
  assert.strictEqual(installer.detectAdapter('https://www.scribblehub.com/series/1'), null, 'scribblehub returns null (Cloudflare 403)');
  assert.strictEqual(installer.detectAdapter('https://www.webnovel.com/book/1'), null, 'webnovel returns null (URL pattern changed)');
  assert.strictEqual(installer.detectAdapter('https://www.lightnovelworld.com/novel/x'), null, 'lightnovelworld returns null (site redesigned)');
  // Unknown
  assert.strictEqual(installer.detectAdapter('https://example.com'), null, 'unknown returns null');
});

/* 8. Extensions: bookmark lifecycle (was misleadingly called 'install' before) */
test('extensions can be bookmarked + unbookmarked', () => {
  const meta = {
    name: 'Test Source',
    baseUrl: 'https://test.example.com',
    lang: 'en',
    nsfw: false,
    version: 1
  };
  const r = installer.bookmark('test-pkg', meta);
  assert.ok(r.ok, 'bookmark succeeds');
  assert.ok(installer.isBookmarked('test-pkg'), 'test-pkg is bookmarked');
  const list = installer.listBookmarked();
  assert.ok(list.find(e => e.pkg === 'test-pkg'), 'test-pkg in bookmark list');
  // detectAdapter should be applied during bookmark
  assert.strictEqual(r.bookmarked.adapter, null, 'adapter null for unknown domain');
  const r2 = installer.unbookmark('test-pkg');
  assert.ok(r2.ok, 'unbookmark succeeds');
  assert.ok(!installer.isBookmarked('test-pkg'), 'test-pkg no longer bookmarked');
  // Cleanup manifest
  fs.writeFileSync(installer.MANIFEST_PATH, JSON.stringify({ bookmarks: {}, version: 1 }, null, 2));
});

/* 8b. Extensions: getSupportedSources returns the honest list of what works */
test('getSupportedSources returns only VERIFIED working sources', () => {
  const supported = installer.getSupportedSources();
  assert.ok(Array.isArray(supported), 'returns array');
  // Only NovelFull is verified working as of 2025-07-21
  assert.ok(supported.length >= 1, `at least 1 supported source (got ${supported.length})`);
  const ids = supported.map(s => s.id);
  assert.ok(ids.includes('novelfull'), 'NovelFull is supported (verified)');
  // Sources that DON'T work must NOT be in the list
  assert.ok(!ids.includes('royalroad'), 'RoyalRoad NOT in supported (Cloudflare blocks us)');
  assert.ok(!ids.includes('scribblehub'), 'ScribbleHub NOT in supported (Cloudflare blocks us)');
  assert.ok(!ids.includes('webnovel'), 'Webnovel NOT in supported (URL pattern changed)');
  assert.ok(!ids.includes('lightnovelworld'), 'LightNovelWorld NOT in supported (site redesigned)');
  // Each supported entry must have verified date + notes
  for (const s of supported) {
    assert.ok(s.verified, `${s.name} has verified date`);
    assert.ok(s.notes, `${s.name} has notes`);
  }
});

/* 9. Scraper: extendAllowList function exists */
test('scraper.extendAllowList exists and works at runtime', () => {
  const scraper = require('../lib/scraper');
  assert.strictEqual(typeof scraper.extendAllowList, 'function');
  assert.strictEqual(typeof scraper.isAllowedExtended, 'function');
  // Add a domain that's NOT in config.json
  scraper.extendAllowList('komikku-test-source.example');
  assert.ok(scraper.isAllowedExtended('komikku-test-source.example'), 'runtime-added domain allowed');
  assert.ok(scraper.isAllowedExtended('sub.komikku-test-source.example'), 'subdomain of runtime-added domain allowed');
});

/* 10. VPS install script exists and has correct shebang */
test('scripts/install-vps.sh exists and is executable', () => {
  const scriptPath = path.join(__dirname, '..', 'scripts', 'install-vps.sh');
  assert.ok(fs.existsSync(scriptPath), 'install-vps.sh exists');
  const content = fs.readFileSync(scriptPath, 'utf8');
  assert.ok(content.startsWith('#!/usr/bin/env bash'), 'has bash shebang');
  assert.ok(content.includes('systemd'), 'installs systemd service');
  assert.ok(content.includes('nginx'), 'configures nginx');
  assert.ok(content.includes('Node.js'), 'installs Node.js');
  assert.ok(content.includes('fonts-vazirmatn'), 'installs Persian fonts');
  assert.ok(content.includes('ufw'), 'configures firewall');
  assert.ok(content.includes('--no-nginx'), 'has --no-nginx option');
  assert.ok(content.includes('--caddy'), 'has --caddy option for HTTPS');
});

/* 11. Server has extension bookmark routes (NOT misleading 'install' anymore) */
test('server.js has honest /api/extensions endpoints (bookmark, not install)', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.ok(src.includes("p === '/api/extensions'"), 'GET /api/extensions');
  assert.ok(src.includes("p === '/api/extensions/bookmark'"), 'POST /api/extensions/bookmark');
  assert.ok(src.includes("p === '/api/extensions/unbookmark'"), 'POST /api/extensions/unbookmark');
  assert.ok(src.includes("p === '/api/extensions/sources'"), 'GET /api/extensions/sources');
  assert.ok(src.includes("p === '/api/extensions/supported'"), 'GET /api/extensions/supported');
  // Must NOT have misleading install/uninstall routes anymore
  assert.ok(!/p === '\/api\/extensions\/install'/.test(src), 'NO install route (was misleading)');
  assert.ok(!/p === '\/api\/extensions\/uninstall'/.test(src), 'NO uninstall route (was misleading)');
});

/* 12. Server has reading status, progress, heatmap routes */
test('server.js has v3.1 reading routes', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.ok(src.includes("/status"), 'PUT /api/novel/:id/status');
  assert.ok(src.includes("/rating"), 'PUT /api/novel/:id/rating');
  assert.ok(src.includes("/api/reading/continue"), 'GET /api/reading/continue');
  assert.ok(src.includes("/api/reading/progress"), 'POST /api/reading/progress');
  assert.ok(src.includes("/api/reading/heatmap"), 'GET /api/reading/heatmap');
  assert.ok(src.includes("/api/reading/by-status"), 'GET /api/reading/by-status');
});

/* 13. DB has new v3.1 functions */
test('db.js exports v3.1 functions', () => {
  const db = require('../lib/db');
  assert.strictEqual(typeof db.setReadingStatus, 'function');
  assert.strictEqual(typeof db.getReadingStatus, 'function');
  assert.strictEqual(typeof db.getNovelsByStatus, 'function');
  assert.strictEqual(typeof db.setRating, 'function');
  assert.strictEqual(typeof db.saveProgress, 'function');
  assert.strictEqual(typeof db.getProgress, 'function');
  assert.strictEqual(typeof db.getContinueReading, 'function');
  assert.strictEqual(typeof db.getHeatmap, 'function');
  assert.strictEqual(Array.isArray(db.READING_STATUSES), true);
});

/* 14. Extensions page exists and is honest about what works */
test('public/extensions.html is honest about Komikku limitations', () => {
  const p = path.join(__dirname, '..', 'public', 'extensions.html');
  assert.ok(fs.existsSync(p), 'extensions.html exists');
  const html = fs.readFileSync(p, 'utf8');
  // Honest messaging
  assert.ok(html.includes('حقیقت صادقانه'), 'has honest reality-check section');
  assert.ok(html.includes('.apk'), 'mentions .apk file format');
  assert.ok(html.includes('اندروید'), 'mentions Android-only');
  assert.ok(html.includes('فقط مرور'), 'has browse-only badge');
  assert.ok(html.includes('پشتیبانی‌شده'), 'has supported badge');
  // Bookmark (NOT install)
  assert.ok(html.includes('data-bookmark'), 'uses data-bookmark attribute');
  assert.ok(html.includes('/api/extensions/bookmark'), 'calls bookmark API');
  assert.ok(html.includes('/api/extensions/unbookmark'), 'calls unbookmark API');
  // Must NOT have misleading 'install' language
  assert.ok(!/install-button|data-install/.test(html), 'no install-button language');
});

/* 15. All HTML pages updated to v3.1 footer */
test('all HTML pages have v3.1 footer (not v2)', () => {
  const publicDir = path.join(__dirname, '..', 'public');
  const htmls = fs.readdirSync(publicDir).filter(f => f.endsWith('.html'));
  let count = 0;
  for (const f of htmls) {
    const c = fs.readFileSync(path.join(publicDir, f), 'utf8');
    if (c.includes('drawer-footer')) {
      count++;
      assert.ok(c.includes('Novel Reader v3.1'), `${f} has v3.1 footer`);
      assert.ok(!c.includes('Novel Reader v2</div>'), `${f} does NOT have v2 footer`);
    }
  }
  assert.ok(count >= 10, `at least 10 pages with footer (got ${count})`);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
