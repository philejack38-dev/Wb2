#!/usr/bin/env bash
# ==============================================================================
# Novel Reader v3.1 — VPS installer
#
# Sets up a fresh Linux VPS (Debian/Ubuntu) to run Novel Reader as a
# production systemd service, fronted by Nginx (with optional HTTPS via
# Caddy or Certbot). Designed to be idempotent — safe to re-run.
#
# Usage:
#   sudo bash scripts/install-vps.sh                  # full install
#   sudo bash scripts/install-vps.sh --no-nginx       # skip Nginx
#   sudo bash scripts/install-vps.sh --user novel     # custom user
#   sudo bash scripts/install-vps.sh --port 8080      # custom port
#
# After install:
#   - App runs at http://YOUR-VPS-IP/ (or :8080 if --no-nginx)
#   - Service: systemctl status novel-reader
#   - Logs:    journalctl -u novel-reader -f
#   - Config:  /opt/novel-reader/.env
# ==============================================================================
set -euo pipefail

# --- Defaults ---
INSTALL_USER="novel"
INSTALL_DIR="/opt/novel-reader"
PORT="8080"
USE_NGINX=true
USE_CADDY=false

# --- Parse args ---
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-nginx)  USE_NGINX=false; shift ;;
    --caddy)     USE_CADDY=true; shift ;;
    --user)      INSTALL_USER="$2"; shift 2 ;;
    --port)      PORT="$2"; shift 2 ;;
    --dir)       INSTALL_DIR="$2"; shift 2 ;;
    -h|--help)
      grep '^#' "$0" | sed 's/^# \?//'
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

echo "================================================"
echo "  Novel Reader v3.1 — VPS Installer"
echo "================================================"
echo "  User:    $INSTALL_USER"
echo "  Dir:     $INSTALL_DIR"
echo "  Port:    $PORT"
echo "  Nginx:   $USE_NGINX"
echo "  Caddy:   $USE_CADDY"
echo "================================================"

# --- 1. Install Node.js 20 LTS (via NodeSource) ---
if ! command -v node &>/dev/null || [[ "$(node -v | cut -dv -f2 | cut -d. -f1)" -lt 18 ]]; then
  echo "→ Installing Node.js 20 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
else
  echo "✓ Node.js already installed: $(node -v)"
fi

# --- 2. Install build deps for better-sqlite3 + Persian fonts ---
echo "→ Installing build dependencies + Persian fonts..."
apt-get update -qq
apt-get install -y --no-install-recommends \
  build-essential python3 ca-certificates \
  nginx ufw curl git \
  fonts-vazirmatn fonts-noto fonts-noto-cjk

# --- 3. Create service user ---
if ! id "$INSTALL_USER" &>/dev/null; then
  echo "→ Creating user: $INSTALL_USER"
  useradd --system --create-home --shell /bin/bash "$INSTALL_USER"
else
  echo "✓ User $INSTALL_USER already exists"
fi

# --- 4. Create install dir + copy app ---
echo "→ Setting up $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "$SCRIPT_DIR" != "$INSTALL_DIR" ]]; then
  rsync -a --delete --exclude node_modules --exclude data \
    --exclude .git --exclude .env \
    "$SCRIPT_DIR/" "$INSTALL_DIR/"
fi
chown -R "$INSTALL_USER:$INSTALL_USER" "$INSTALL_DIR"

# --- 5. Install npm deps (as the service user) ---
echo "→ Installing npm dependencies..."
sudo -u "$INSTALL_USER" -- bash -c "cd '$INSTALL_DIR' && npm install --omit=dev 2>&1" || {
  echo "⚠ npm install failed — better-sqlite3 may need build tools"
  echo "  Falling back to JSON storage mode (still works, just slower for search)"
}

# --- 6. Create .env from template if missing ---
ENV_FILE="$INSTALL_DIR/.env"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "→ Creating .env from .env.example..."
  cp "$INSTALL_DIR/.env.example" "$ENV_FILE"
  chown "$INSTALL_USER:$INSTALL_USER" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  echo "  → Edit $ENV_FILE to add your API keys"
fi

# --- 7. Create data dir ---
mkdir -p "$INSTALL_DIR/data"
chown -R "$INSTALL_USER:$INSTALL_USER" "$INSTALL_DIR/data"

# --- 8. Update config.json port ---
CONFIG_FILE="$INSTALL_DIR/config.json"
if [[ -f "$CONFIG_FILE" ]]; then
  python3 -c "
import json
with open('$CONFIG_FILE', 'r') as f: cfg = json.load(f)
cfg['port'] = $PORT
cfg['host'] = '127.0.0.1'  # always bind to localhost; nginx proxies to it
with open('$CONFIG_FILE', 'w') as f: json.dump(cfg, f, indent=2, ensure_ascii=False)
"
fi

# --- 9. systemd service ---
echo "→ Installing systemd service..."
cat > /etc/systemd/system/novel-reader.service <<EOF
[Unit]
Description=Novel Reader v3.1 — Web-novel scraper + AI translator
After=network.target

[Service]
Type=simple
User=$INSTALL_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node $INSTALL_DIR/server.js
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production
EnvironmentFile=$INSTALL_DIR/.env

# Hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadWritePaths=$INSTALL_DIR/data $INSTALL_DIR/lib/extensions
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
RestrictRealtime=true
MemoryDenyWriteExecute=false
LockPersonality=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable novel-reader
systemctl restart novel-reader
echo "✓ Service installed: systemctl status novel-reader"

# --- 10. Nginx reverse proxy ---
if $USE_NGINX && ! $USE_CADDY; then
  echo "→ Configuring Nginx reverse proxy..."
  cat > /etc/nginx/sites-available/novel-reader <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name _;

    # Allow large uploads (backup restore can be big)
    client_max_body_size 100M;

    # Rate limit (120 req/min per IP — same as app default)
    limit_req_zone \$binary_remote_addr zone=novel:10m rate=2r/s;

    location / {
        limit_req zone=novel burst=30 nodelay;
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;

        # SSE support — long-lived connections
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }

    # Static assets — long cache
    location ~* \.(woff2|png|jpg|jpeg|gif|svg|ico|css|js)\$ {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_cache_valid 200 1d;
        add_header Cache-Control "public, max-age=86400";
    }
}
EOF
  ln -sf /etc/nginx/sites-available/novel-reader /etc/nginx/sites-enabled/novel-reader
  rm -f /etc/nginx/sites-enabled/default
  nginx -t && systemctl reload nginx || echo "⚠ Nginx config test failed — check /etc/nginx/sites-available/novel-reader"
  echo "✓ Nginx configured"
fi

# --- 11. Caddy (alternative — auto-HTTPS) ---
if $USE_CADDY; then
  echo "→ Installing Caddy (auto-HTTPS)..."
  apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -qq
  apt-get install -y caddy
  cat > /etc/caddy/Caddyfile <<EOF
:80 {
    reverse_proxy 127.0.0.1:$PORT
    encode gzip
}
EOF
  systemctl enable caddy
  systemctl restart caddy
  echo "✓ Caddy installed (edit /etc/caddy/Caddyfile to add your domain for HTTPS)"
fi

# --- 12. Firewall ---
if command -v ufw &>/dev/null; then
  echo "→ Configuring UFW firewall..."
  ufw allow OpenSSH || true
  if $USE_NGINX || $USE_CADDY; then
    ufw allow "Nginx Full" || true
  else
    ufw allow "$PORT"/tcp || true
  fi
  yes | ufw enable 2>/dev/null || true
  echo "✓ Firewall configured"
fi

# --- 13. Print summary ---
SERVER_IP=$(curl -s --max-time 3 ifconfig.me || echo "YOUR-VPS-IP")
PUBLIC_URL="http://$SERVER_IP"
if $USE_NGINX || $USE_CADDY; then PUBLIC_URL="http://$SERVER_IP/"; else PUBLIC_URL="http://$SERVER_IP:$PORT"; fi

echo ""
echo "================================================"
echo "  ✓ Installation complete!"
echo "================================================"
echo ""
echo "  App URL:        $PUBLIC_URL"
echo "  Service:        systemctl status novel-reader"
echo "  Logs:           journalctl -u novel-reader -f"
echo "  Config (.env):  $INSTALL_DIR/.env"
echo "  Data dir:       $INSTALL_DIR/data"
echo ""
echo "  Next steps:"
echo "    1. Edit .env: nano $INSTALL_DIR/.env  (add API keys)"
echo "    2. Restart:   systemctl restart novel-reader"
if $USE_NGINX; then
  echo "    3. For HTTPS: certbot --nginx -d your-domain.com"
fi
if $USE_CADDY; then
  echo "    3. For HTTPS: edit /etc/caddy/Caddyfile, add your domain"
fi
echo ""
