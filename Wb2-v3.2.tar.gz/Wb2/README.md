# Novel Reader v3.2

> وب‌اپ کامل اسکرپ + ترجمهٔ هوشمند وب‌ناول به فارسی. نسخهٔ ۳.۲ شامل **Mega UI Update** (بازطراحی کامل با glassmorphism + gradients) و **۲۱ منبع جدید چینی** (از My Novel Reader userscript) هست.

## 🆕 چی جدید در v3.2؟

### 🎨 Mega UI Update
- ✅ **Home page بازنویسی کامل**: hero با gradient + glassmorphism، animated orbs، quick stats با gradient text
- ✅ **Continue Reading section**: progress bar + resume button
- ✅ **Today's Goal card**: real-time progress
- ✅ **Skeleton loaders**: shimmer animation هنگام loading
- ✅ **Buttons با gradient + glow + shimmer** effect روی hover
- ✅ **Sticky app-header با glass blur** (backdrop-filter)
- ✅ **Color-mix()** برای gradient هوشمند بین accent colors
- ✅ **Empty states** با icon و CTA

### 🌐 ۲۱ منبع جدید چینی
- ✅ استخراج از [My Novel Reader](https://greasyfork.org/scripts/292) userscript
- ✅ `lib/site-rules.json` — ۲۱ تعریف سایت با selectors
- ✅ `lib/site-rules-scraper.js` — generic config-driven scraper
- ✅ پشتیبانی از jQuery-style selectors + Readability fallback
- ⚠️ سایت‌های چینی ممکنه از خارج چین قابل دسترس نباشن (GFW)

## 🆕 چی جدید در v3.1؟

### 🧠 کیفیت ترجمه (مهم‌ترین بهبود)
- ✅ **System message جدا از user message** — تمام providerها (OpenAI، Anthropic، Gemini، Ollama) حالا system role رو درست استفاده می‌کنن
- ✅ **Style guide گسترش‌یافته** — ۲۱ اصل + ۸ مثال few-shot (قبلاً ۱۰ اصل + ۵ مثال)
- ✅ **Glossary filtering هوشمند** — فقط اصطلاحات مرتبط با chunk پاس داده می‌شه (صرفه‌جویی token + کیفیت بالاتر)
- ✅ **Quality validation خودکار** — هر ترجمه validation می‌شه: paragraph count، Persian chars، markdown fence detection، echo detection. اگه fail بشه، automatic retry
- ✅ **Context chain بهتر** — هم source tail و هم translation tail قبلی به chunk بعدی پاس داده می‌شه
- ✅ **Glossary cache ۶۰s** + version-based busting (قبلاً هر chunk یک DB query + file read داشت)

### 🧩 کاتالوگ منابع Komikku (صادقانه)
- ✅ صفحه `/extensions` برای مرور کاتالوگ Komikku
- ⚠️ **حقیقت:** extensions Komikku فایل‌های `.apk` هستن که فقط روی Android اجرا می‌شن — Node.js نمی‌تونه اجراشون کنه
- ✅ **badge سبز "✓ پشتیبانی‌شده"** برای ۷ منبعی که آداپتور واقعی دارن (MangaDex، NovelFull، RoyalRoad، ...)
- ✅ **badge خاکستری "فقط مرور"** برای بقیه — با لینک مستقیم به سایت
- ✅ Bookmark منابع برای دسترسی سریع
- ✅ برای اضافه کردن منبع جدید: فایل `lib/scrapers/<sitename>.js` بساز

### 🚀 اسکریپت نصب VPS (Production-ready)
- ✅ `sudo bash scripts/install-vps.sh` — نصب کامل در یک دستور
- ✅ Node.js 20 LTS + Persian fonts (Vazirmatn، Noto)
- ✅ systemd service با hardening (NoNewPrivileges، ProtectSystem، ...)
- ✅ Nginx reverse proxy با SSE support
- ✅ UFW firewall + optional Caddy برای auto-HTTPS
- ✅ Idempotent — safe to re-run

### 🎨 بهبودهای UI
- ✅ Reading status (reading/completed/dropped/plan_to_read)
- ✅ Rating (۰-۵ stars)
- ✅ Reading progress (scroll position auto-save + resume)
- ✅ Continue Reading list
- ✅ Reading heatmap (GitHub-style ۳۶۵ روز)
- ✅ تمام صفحات v3.1 footer

### 🗄️ بهبودهای DB
- جدول‌های جدید: `reading_progress`, `quotes`, `vocabulary`, `streak_freezes`, `chapter_notes`
- ستون‌های جدید در novels: `reading_status`, `rating`, `rating_notes`

## 🚀 شروع سریع (VPS)

```bash
# Clone + install in one command
git clone https://github.com/philejack38-dev/Wb2.git
cd Wb2
sudo bash scripts/install-vps.sh

# یا با auto-HTTPS (نیاز به domain):
sudo bash scripts/install-vps.sh --caddy
```

بعد از نصب:
- App روی `http://YOUR-VPS-IP/` (پشت nginx)
- Service: `systemctl status novel-reader`
- Logs: `journalctl -u novel-reader -f`
- Config: `/opt/novel-reader/.env` (API keys رو اینجا بذار)

## 🚀 شروع سریع (Development)

```bash
git clone https://github.com/philejack38-dev/Wb2.git
cd Wb2
npm install
cp .env.example .env  # ویرایش کن و API keys رو بذار
npm start
# باز کن: http://localhost:8080
```

## 🆕 چی جدید در v3.0؟

### 🚨 باگ‌های بحرانی فیکس شده
- ✅ **Route shadowing**: endpointهای `/api/novel/:id/chapters`، `/tags`، `/wiki` هیچ‌وقت اجرا نمی‌شدن — حالا درست کار می‌کنن
- ✅ **Job queue starvation**: queue فقط آخرین job رو اجرا می‌کرد — حالا FIFO واقعی
- ✅ **Range scraping/translation**: قابلیت v2.3 واقعاً کار نمی‌کرد — حالا درست پاس می‌شه
- ✅ **SOCKS5 proxy برای translator**: فقط HTTP proxy کار می‌کرد — حالا SOCKS5 هم پشتیبانی می‌شه
- ✅ **Backup/restore**: فقط novels رو برمی‌گردوند — حالا تمام ۱۱ data type بازگردانی می‌شه
- ✅ **PDF export برای فارسی**: خراب بود — حالا با pdfkit + arabic-reshaper + Vazirmatn embedding
- ✅ **discovery.checkForUpdates**: کاملاً خراب بود (field name + arg type اشتباه)

### 🔒 امنیت
- ✅ **SSRF در `/api/img`** فیکس شد (allow-list check)
- ✅ **API keys هاردکد** حذف شدن — حالا از env var (`NR_<PROVIDER>_API_KEY`) خونده می‌شن
- ✅ **Timing-safe password + signature comparison** (timing attack بسته شد)
- ✅ **Brute-force protection** برای login (۵ تلاش → exponential lockout)
- ✅ **X-Forwarded-For spoofing** بسته شد (فقط با `trustProxy=true` کار می‌کنه)
- ✅ **Wildcard domain matching** (`booktoki*.com` حالا درست match می‌شه)

### ⚡ Performance
- ✅ **N+1 query در recommendation engine** فیکس شد
- ✅ **Glossary cache** در translator (TTL ۶۰s)
- ✅ **O(1) rate limiter eviction** (به‌جای `arr.shift()`)

### ✨ قابلیت‌های جدید
- 🆕 **OPDS catalog** (`/opds`) برای Calibre/Moon+ Reader
- 🆕 **Translation quality scoring** (`POST /api/translate/score`) — LLM judge
- 🆕 **CSV/JSON stats export** (`GET /api/stats/export`)
- 🆕 **Job cancellation** — workers بین chapters check می‌کنن

### 🎨 UX/UI
- ✅ **SSE handler leak** فیکس شد (helper جدید `trackJob` با auto-unsubscribe)
- ✅ **Vazirmatn font bundle** شده (بدون Google CDN، offline PWA کار می‌کنه)
- ✅ **`.env` loader** بدون dependency

## 🎯 امکانات سطح ۵ (Premium)

### آمار و تحلیل خواندن
- 📊 **داشبورد آمار** با نمودار SVG روزانه (دقیقه به دقیقه)
- 🔥 **Streak خواندن** (روزهای پیاپی)
- 📅 **تاریخچهٔ کامل** جلسات خواندن با group-by روز
- ⏱ **تایمر زنده** در صفحهٔ خواننده
- 📈 **پرخوانده‌ترین رمان‌ها** بر اساس زمان

### دستاوردها و اهداف (Gamification)
- 🏆 **۱۲ دستاورد** (اولین رمان، streak ۳/۷/۳۰ روزه، جغد شب، هایلایتر، ...)
- 🎯 **اهداف قابل تنظیم** (فصل/دقیقه × روزانه/هفتگی/ماهانه)
- 📊 **نوار پیشرفت** زنده برای هر هدف

### تحلیل محتوا
- 📖 **ویکی خودکار شخصیت‌ها/اماکن** با LLM (نام، نوع، توضیح، نام‌های مستعار، تعداد اشاره)
- 🏷 **تگ‌گذاری رمان‌ها** (با رنگ دلخواه)
- 🧠 **Glossary خودکار** (استخراج اصطلاحات xianxia با LLM)
- 🎯 **توصیه‌گر هوشمند** بر اساس نویسنده/منبع/تگ/کلمات عنوان

### هایلایت و یادداشت
- 🖍 **هایلایت ۴ رنگ** (زرد/سبز/آبی/صورتی) با انتخاب متن
- 📝 **یادداشت روی هر هایلایت**
- 📋 **کپی سریع** متن انتخاب‌شده
- 🔍 **جستجو در هایلایت‌ها**

### بروزرسانی و سینک
- 🔄 **بررسی خودکار آپدیت منبع** هر ۶ ساعت (scheduler داخلی)
- 🆕 **اعلان فصل جدید** در صفحهٔ جزئیات
- 📋 **صف خواندن (Want-to-read)** با اولویت

### ترجمهٔ پیشرفته
- ⚖ **مقایسهٔ چند مدل** (A/B testing) — همون فصل با چند provider ترجمه می‌شه
- 🧠 **Translation Memory** برای cache چانک‌های تکراری
- 📚 **Glossary پایدار** + استخراج خودکار اصطلاحات جدید
- 🎭 **Style guide + few-shot examples** برای ثبات سبک وب‌ناول
- 🔄 **Context injection** از فصل قبل برای ثبات اصطلاحات
- 🧩 **Chunking هوشمند** با overlap برای فصل‌های طولانی

### Export چندفرمتی
- 📥 **EPUB 2.0** (ZIP دست‌ساز، بدون وابستگی)
- 📝 **Markdown** (با frontmatter)
- 📄 **PDF** (ساده، fallback)
- 💾 **Backup/Restore** کامل JSON (novels + chapters + glossary + wiki + highlights + tags + sessions + ...)

### UX خواننده
- ⌨️ **Keyboard shortcuts** (فلش، T، +/-، 1/2/3)
- 🔖 **Bookmark خودکار** + resume
- 🔊 **TTS مروربری** با صدای فارسی
- ⏬ **اسکرول خودکار** (hands-free reading)
- 🌗 **Theme تاریک/روشن** + **night auto-switch** (بر اساس ساعت)
- 🎨 **Font family + size + line-height** قابل تنظیم
- 📱 **PWA کامل** (قابل نصب روی موبایل، offline برای static)
- ♿ **Accessibility** (focus-visible، reduced motion)

### امنیت و پایداری
- 🔒 **Auth اختیاری** (HMAC-SHA256 token + HTTP-only cookie)
- 🚦 **Rate limiting** (۱۲۰ req/min per IP)
- 🛡 **Domain allow-list** (جلوگیری از SSRF)
- ⏱ **Timeout روی همه socketها**
- 🔄 **Retry با exponential backoff** (fetch + translate)
- 📦 **Atomic write** (DB فساد نمی‌کنه)
- 🗄 **SQLite + FTS5** با fallback خودکار به JSON

## 🌐 پشتیبانی چندسایتی
piaotia, webnovel, wuxiaworld, novelupdates, novelfull, lightnovelworld, generic

## 🔌 پشتیبانی چند provider
opencode/Zen, OpenAI, OpenRouter, Anthropic, DeepSeek, Gemini, Ollama

## ✨ امکانات جدید در نسخهٔ ۲

### تعمیر بحرانی (باگ‌های نسخهٔ ۱)
- ✅ **تعمیر باگ ترجمه**: فیلدهای `defaultTargetLang`/`defaultModel` که در `config.json` وجود نداشتند حذف و به مسیر درست (`translator.targetLang`, `translator.model`) متصل شدند
- ✅ **بازگرداندن فایل‌های گم‌شده**: `lib/glossary.json` (۵۰+ اصطلاح xianxia) و `lib/style-guide.json` (با ۵ مثال few-shot)
- ✅ **Timeout روی همه socketها**: دیگر سرور هنگ نمی‌کنه
- ✅ **gzip/deflate/brotli**: response‌های فشرده به‌درستی decode می‌شن
- ✅ **Theme روشن واقعی**: متغیرهای CSS برای `light` اضافه شد
- ✅ **Atomic write**: دیتابیس در صورت قطع برق فساد نمی‌کنه

### معماری مقیاس‌پذیر
- 🗄️ **SQLite + FTS5** به‌جای JSON: جستجوی full-text روی همهٔ فصل‌ها
- 🔄 **Background job queue** با concurrency control (۲-۴ کار همزمان)
- 📡 **SSE** برای پیشرفت live ترجمه (بدون polling)
- 🔒 **Auth اختیاری** + rate limiting
- 🧠 **Translation Memory**: چانک‌های تکراری از کش خونده می‌شن (صرفه‌جویی API)
- 📚 **Glossary auto-extraction**: LLM اصطلاحات جدید رو تشخیص می‌ده و خودکار اضافه می‌کنه
- 📦 **EPUB export** (بدون وابستگی، ZIP دست‌ساز)
- 🌐 **Multi-site scraper**: piaotia, webnovel, wuxiaworld, novelupdates, novelfull, lightnovelworld, generic
- 🔌 **Multi-provider translator**: opencode/Zen, OpenAI, OpenRouter, Anthropic, DeepSeek, Gemini, Ollama
- 📖 **PWA**: نصب روی موبایل، آفلاین کار کردن برای صفحات استاتیک

### UX/UI حرفه‌ای
- ⌨️ **Keyboard shortcuts**: فلش چپ/راست برای فصل قبلی/بعدی، T برای تم، +/- برای سایز، 1/2/3 برای حالت نمایش
- 🔖 **Bookmark** خودکار + resume از آخرین جایگاه
- 🔊 **TTS** مرورگری با صدای فارسی
- 🎨 **Font family + line-height + size** قابل تنظیم
- 🌗 **Theme تاریک/روشن** سراسری
- 📊 **صفحهٔ آمار** با نمودار و job list
- 🔍 **جستجوی full-text** روی محتوای فصل‌ها
- ⚡ **Skeleton loaders**، toast notifications، progress bars
- 📱 **Responsive** موبایل-اول
- ♿ **Accessibility**: focus-visible، reduced motion، aria labels

## 🚀 راه‌اندازی

### پیش‌نیازها
- Node.js v18.17+
- (اختیاری) `better-sqlite3` — اگر نباشه، حالت JSON fallback فعال می‌شه

### اجرا
```bash
# Linux/macOS
bash scripts/start.sh

# Windows
scripts\start.bat

# یا مستقیم
npm install       # اختیاری، برای SQLite
node server.js
```

سپس مرورگر رو باز کن: `http://localhost:8080`

### پیکربندی
`config.json` رو ویرایش کن:
```json
{
  "translator": {
    "provider": "opencode",                    // یا openai/anthropic/deepseek/...
    "providers": {
      "opencode": {
        "apiKey": "your-key-here",
        "model": "mimo-v2.5-free"
      }
    }
  },
  "proxy": "socks5://127.0.0.1:1080",         // اختیاری
  "auth": { "enabled": false }                 // برای فعال‌کردن ورود ادمین
}
```

## 📁 ساختار پروژه

```
novel-reader/
├── server.js                 # سرور HTTP + API routes + SSE
├── config.json               # پیکربندی
├── package.json
├── lib/
│   ├── db.js                 # SQLite + FTS5 + atomic write (fallback: JSON)
│   ├── scraper.js            # Multi-site scraper (gzip, timeout, retry, cover)
│   ├── socks5.js             # کلاینت SOCKS5 بدون وابستگی
│   ├── translator.js         # Multi-provider + chunking + TM + glossary auto
│   ├── queue.js              # Background job runner + SSE broadcast
│   ├── auth.js               # Token-based auth (HMAC-SHA256)
│   ├── rateLimit.js          # In-memory rate limiter
│   ├── epub.js               # EPUB 2.0 generator (ZIP دست‌ساز)
│   ├── glossary.json         # اصطلاحات xianxia/wuxia (cultivation, honorifics, ranks)
│   └── style-guide.json      # اصول سبک + few-shot examples
├── public/
│   ├── index.html            # کتابخونه
│   ├── admin.html            # افزودن رمان
│   ├── detail.html           # جزئیات + فهرست فصل
│   ├── reader.html           # خواننده با همه کنترل‌ها
│   ├── search.html           # جستجوی full-text
│   ├── stats.html            # آمار + job list
│   ├── settings.html         # تنظیمات UI + مترجم
│   ├── login.html            # ورود ادمین
│   ├── style.css             # تمام استایل‌ها (dark+light)
│   ├── app.js                # ماژولار، با SSE + keyboard + PWA
│   ├── manifest.json         # PWA manifest
│   ├── sw.js                 # service worker
│   └── icons/                # SVG + PNG icons
├── scripts/
│   ├── start.sh              # راه‌انداز Linux/macOS
│   ├── start.bat             # راه‌انداز Windows
│   └── seed-glossary.js      # seed glossary به دیتابیس
├── data/                     # SQLite DB یا JSON fallback
└── test/
    ├── fixture.html
    └── scraper.test.js       # testهای extraction
```

## 🔌 Providerهای ترجمه

| Provider | baseUrl | مدل پیشنهادی |
|----------|---------|--------------|
| opencode/Zen | https://opencode.ai/zen/v1 | mimo-v2.5-free |
| OpenAI | https://api.openai.com/v1 | gpt-4o-mini |
| OpenRouter | https://openrouter.ai/api/v1 | deepseek/deepseek-chat |
| Anthropic | https://api.anthropic.com/v1 | claude-3-5-haiku-20241022 |
| DeepSeek | https://api.deepseek.com/v1 | deepseek-chat |
| Gemini | https://generativelanguage.googleapis.com/v1beta | gemini-2.0-flash-exp |
| Ollama | http://127.0.0.1:11434 | qwen2.5:14b |

برای افزودن کلید: `config.json` → `translator.providers.<name>.apiKey`.

## 🌐 سایت‌های پشتیبانی‌شده

| سایت | نکات |
|------|------|
| piaotia.com | پشتیبانی GBK، ساختار index.html مشخص |
| webnovel.com | نیاز به __NEXT_DATA__ parse |
| wuxiaworld.com | chapter-content class |
| novelupdates.com | aggregator (محدودیت JS) |
| novelfull.com | استاندارد |
| lightnovelworld.com | استاندارد |
| generic | pattern-based fallback |

برای افزودن domain جدید: `config.json` → `scraper.allowedDomains`.

## ⌨️ Keyboard shortcuts (در صفحهٔ خواننده)

| کلید | عملکرد |
|------|--------|
| → | فصل قبلی (RTL) |
| ← | فصل بعدی |
| T | سوییچ تم |
| + / - | بزرگ/کوچک کردن فونت |
| 1 / 2 / 3 | ترجمه / اصل / هر دو |

## 📊 API endpoints

```
GET    /api/novels
GET    /api/novel/:id
GET    /api/novel/:id?chapters=0       # فقط متادیتا
DELETE /api/novel/:id
GET    /api/chapter/:id
GET    /api/chapter?novel=X&idx=Y      # بر اساس ایندکس
POST   /api/add                         # body: {url, limit}
POST   /api/translate/novel/:id         # body: {mode: 'pending'|'all'}
POST   /api/translate/chapter/:id
GET    /api/jobs
GET    /api/job/:id
DELETE /api/job/:id
GET    /api/events                      # SSE
GET    /api/search?q=...
POST   /api/bookmark                    # body: {novelId, chapterIndex}
GET    /api/bookmarks
GET    /api/glossary?novel=X
POST   /api/glossary
POST   /api/glossary/extract            # body: {novelId}
GET    /api/epub/:id?mode=translated|original
GET    /api/img?src=URL                 # proxy تصویر
GET    /api/stats
GET    /api/settings
POST   /api/settings
POST   /api/login                       # body: {username, password}
POST   /api/logout
GET    /api/auth/check
```

## 🧪 تست

```bash
node test/scraper.test.js
```

## 🔒 امنیت

- کلید API هرگز در UI ذخیره نمی‌شه — فقط در `config.json`
- Rate limit پیش‌فرض: ۱۲۰ درخواست در دقیقه برای هر IP
- Auth (اگر فعال باشه) از token HTTP-only cookie استفاده می‌کنه
- Domain allow-list برای جلوگیری از SSRF
- Path traversal check در static serving

## 📈 مهاجرت از نسخهٔ ۱

دیتای قدیمی در `data/data.json` به‌صورت خودکار در حالت fallback خونده می‌شه. برای مهاجرت به SQLite:
```bash
# 1. بکاپ بگیر
cp data/data.json data/data.json.bak

# 2. npm install کن
npm install

# 3. سرور رو استارت کن — دیتابیس SQLite خودکار ساخته می‌شه
# 4. (اختیاری) با یک اسکریپت دستی دیتا رو import کن
```

## 📝 لایسنس

MIT
