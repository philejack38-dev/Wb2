'use strict';
/**
 * v3.1 Mega Update Test Suite — verifies translator quality improvements,
 * Komikku extension installer, and VPS install script.
 */
const path = require('path');
const fs = require('fs');
const assert = require('assert');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ✓ ' + name); }
  catch (e) { failed++; console.log('  ✗ ' + name + '\n    ' + e.message); }
}

const translator = require('../lib/translator');
const installer = require('../lib/extensions-installer');

console.log('\nv3.1 Mega Update Tests:\n');

/* 1. Translator: system + user prompt separation */
test('translator has buildSystemPrompt + buildUserPrompt', () => {
  assert.strictEqual(typeof translator.buildSystemPrompt, 'function');
  assert.strictEqual(typeof translator.buildUserPrompt, 'function');
  const sys = translator.buildSystemPrompt({ sourceText: '罗冠' });
  const usr = translator.buildUserPrompt('罗冠', {});
  assert.ok(sys.includes('WEB NOVEL'), 'system prompt mentions web novel');
  assert.ok(sys.includes('OUTPUT CONTRACT'), 'system prompt has output contract');
  assert.ok(usr.includes('SOURCE TEXT TO TRANSLATE'), 'user prompt has source text marker');
  assert.ok(!sys.includes('SOURCE TEXT TO TRANSLATE'), 'system prompt does NOT contain source text');
});

/* 2. Translator: glossary filtering (only terms appearing in chunk) */
test('filterGlossaryForChunk only includes relevant terms', () => {
  const allGlossary = translator.buildGlossaryText(null);
  const sourceWithCultivation = '他运转灵气，丹田中金光大盛。';  // contains 灵气
  const filtered = translator.filterGlossaryForChunk(allGlossary, sourceWithCultivation);
  assert.ok(filtered.includes('灵气'), '灵气 included (appears in source)');
  assert.ok(!filtered.includes('妖兽'), '妖兽 excluded (does NOT appear in source)');
});

/* 3. Translator: validation function */
test('validateTranslation detects bad output', () => {
  const src = '罗冠站在江宁城外，望着远处的青山。他运转灵气，丹田中金光大盛。';
  assert.ok(translator.validateTranslation(src, 'لوگوان بیرون شهر ایستاده بود.').ok, 'good translation passes');
  assert.ok(!translator.validateTranslation(src, '').ok, 'empty fails');
  assert.ok(!translator.validateTranslation(src, src).ok, 'echo fails');
  assert.ok(!translator.validateTranslation(src, '```markdown\nhello\n```').ok, 'markdown fence fails');
  assert.ok(!translator.validateTranslation(src, 'Translation: hello').ok, '"Translation:" prefix fails');
  // Paragraph count mismatch
  const longSrc = Array(10).fill('一段中文段落').join('\n\n');
  const shortTrans = 'فقط یک پاراگراف';
  assert.ok(!translator.validateTranslation(longSrc, shortTrans).ok, 'paragraph count too low fails');
});

/* 4. Translator: callProvider supports system+user messages */
test('callProvider accepts systemPrompt in opts', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'translator.js'), 'utf8');
  assert.ok(src.includes('opts.systemPrompt'), 'callProvider reads opts.systemPrompt');
  assert.ok(src.includes("role: 'system'"), 'uses system role for OpenAI-compatible');
  assert.ok(src.includes('body.system = systemText'), 'anthropic uses body.system');
  assert.ok(src.includes('body.systemInstruction'), 'gemini uses systemInstruction');
});

/* 5. Translator: style guide has expanded principles + few-shot */
test('style-guide.json has expanded principles + few-shot examples', () => {
  const sg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'lib', 'style-guide.json'), 'utf8'));
  assert.ok(sg.style_principles.length >= 15, `at least 15 principles (got ${sg.style_principles.length})`);
  assert.ok(sg.few_shot.length >= 5, `at least 5 few-shot examples (got ${sg.few_shot.length})`);
  // Check for new specific principles
  assert.ok(sg.style_principles.some(p => p.includes('guillemets')), 'mentions guillemets');
  assert.ok(sg.style_principles.some(p => p.includes('pro-drop') || p.includes('Pronouns')), 'mentions pro-drop');
  assert.ok(sg.style_principles.some(p => p.includes('Persian comma')), 'mentions Persian comma');
});

/* 6. Extensions installer: module exists with required functions */
test('extensions-installer.js exists with required functions', () => {
  assert.strictEqual(typeof installer.install, 'function');
  assert.strictEqual(typeof installer.uninstall, 'function');
  assert.strictEqual(typeof installer.listInstalled, 'function');
  assert.strictEqual(typeof installer.isInstalled, 'function');
  assert.strictEqual(typeof installer.detectAdapter, 'function');
});

/* 7. Extensions installer: detectAdapter for known sources */
test('detectAdapter identifies built-in adapters', () => {
  assert.strictEqual(installer.detectAdapter('https://mangadex.org/title/123'), 'mangadex');
  assert.strictEqual(installer.detectAdapter('https://novelfull.com/x'), 'novelfull');
  assert.strictEqual(installer.detectAdapter('https://www.royalroad.com/fiction/1'), 'royalroad');
  assert.strictEqual(installer.detectAdapter('https://www.scribblehub.com/series/1'), 'scribblehub');
  assert.strictEqual(installer.detectAdapter('https://www.webnovel.com/book/1'), 'webnovel');
  assert.strictEqual(installer.detectAdapter('https://example.com'), null, 'unknown returns null');
});

/* 8. Extensions installer: install + uninstall lifecycle */
test('extensions installer can install + uninstall a fake source', () => {
  // Use the manifest directly — we mock a source by writing to manifest
  const manifest = {
    installed: {
      'test-pkg': {
        pkg: 'test-pkg',
        name: 'Test Source',
        baseUrl: 'https://test.example.com',
        lang: 'en',
        version: 1,
        nsfw: false,
        adapter: null,
        installedAt: new Date().toISOString(),
        autoDetected: false
      }
    },
    installedAt: new Date().toISOString(),
    version: 1
  };
  fs.mkdirSync(path.dirname(installer.MANIFEST_PATH), { recursive: true });
  fs.writeFileSync(installer.MANIFEST_PATH, JSON.stringify(manifest, null, 2));
  assert.ok(installer.isInstalled('test-pkg'), 'test-pkg is installed');
  const list = installer.listInstalled();
  assert.ok(list.find(e => e.pkg === 'test-pkg'), 'test-pkg in list');
  const r = installer.uninstall('test-pkg');
  assert.ok(r.ok, 'uninstall succeeds');
  assert.ok(!installer.isInstalled('test-pkg'), 'test-pkg no longer installed');
  // Cleanup
  fs.writeFileSync(installer.MANIFEST_PATH, JSON.stringify({ installed: {}, version: 1 }, null, 2));
});

/* 9. Scraper: extendAllowList function exists */
test('scraper.extendAllowList exists and works at runtime', () => {
  const scraper = require('../lib/scraper');
  assert.strictEqual(typeof scraper.extendAllowList, 'function');
  assert.strictEqual(typeof scraper.isAllowedExtended, 'function');
  // Add a domain that's NOT in config.json
  scraper.extendAllowList('komikku-test-source.example');
  assert.ok(scraper.isAllowedExtended('komikku-test-source.example'), 'runtime-added domain allowed');
  assert.ok(scraper.isAllowedExtended('sub.komikku-test-source.example'), 'subdomain of runtime-added domain allowed');
});

/* 10. VPS install script exists and has correct shebang */
test('scripts/install-vps.sh exists and is executable', () => {
  const scriptPath = path.join(__dirname, '..', 'scripts', 'install-vps.sh');
  assert.ok(fs.existsSync(scriptPath), 'install-vps.sh exists');
  const content = fs.readFileSync(scriptPath, 'utf8');
  assert.ok(content.startsWith('#!/usr/bin/env bash'), 'has bash shebang');
  assert.ok(content.includes('systemd'), 'installs systemd service');
  assert.ok(content.includes('nginx'), 'configures nginx');
  assert.ok(content.includes('Node.js'), 'installs Node.js');
  assert.ok(content.includes('fonts-vazirmatn'), 'installs Persian fonts');
  assert.ok(content.includes('ufw'), 'configures firewall');
  assert.ok(content.includes('--no-nginx'), 'has --no-nginx option');
  assert.ok(content.includes('--caddy'), 'has --caddy option for HTTPS');
});

/* 11. Server has extension installer routes */
test('server.js has /api/extensions endpoints', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.ok(src.includes("p === '/api/extensions'"), 'GET /api/extensions');
  assert.ok(src.includes("p === '/api/extensions/install'"), 'POST /api/extensions/install');
  assert.ok(src.includes("p === '/api/extensions/uninstall'"), 'POST /api/extensions/uninstall');
  assert.ok(src.includes("p === '/api/extensions/sources'"), 'GET /api/extensions/sources');
  assert.ok(src.includes("p === '/extensions'"), 'static /extensions page');
});

/* 12. Server has reading status, progress, heatmap routes */
test('server.js has v3.1 reading routes', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
  assert.ok(src.includes("/status"), 'PUT /api/novel/:id/status');
  assert.ok(src.includes("/rating"), 'PUT /api/novel/:id/rating');
  assert.ok(src.includes("/api/reading/continue"), 'GET /api/reading/continue');
  assert.ok(src.includes("/api/reading/progress"), 'POST /api/reading/progress');
  assert.ok(src.includes("/api/reading/heatmap"), 'GET /api/reading/heatmap');
  assert.ok(src.includes("/api/reading/by-status"), 'GET /api/reading/by-status');
});

/* 13. DB has new v3.1 functions */
test('db.js exports v3.1 functions', () => {
  const db = require('../lib/db');
  assert.strictEqual(typeof db.setReadingStatus, 'function');
  assert.strictEqual(typeof db.getReadingStatus, 'function');
  assert.strictEqual(typeof db.getNovelsByStatus, 'function');
  assert.strictEqual(typeof db.setRating, 'function');
  assert.strictEqual(typeof db.saveProgress, 'function');
  assert.strictEqual(typeof db.getProgress, 'function');
  assert.strictEqual(typeof db.getContinueReading, 'function');
  assert.strictEqual(typeof db.getHeatmap, 'function');
  assert.strictEqual(Array.isArray(db.READING_STATUSES), true);
});

/* 14. Extensions page exists */
test('public/extensions.html exists and is well-formed', () => {
  const p = path.join(__dirname, '..', 'public', 'extensions.html');
  assert.ok(fs.existsSync(p), 'extensions.html exists');
  const html = fs.readFileSync(p, 'utf8');
  assert.ok(html.includes('افزونه‌های Komikku'), 'has Persian title');
  assert.ok(html.includes('extGrid'), 'has grid container');
  assert.ok(html.includes('/api/extensions/install'), 'calls install API');
  assert.ok(html.includes('/api/extensions/uninstall'), 'calls uninstall API');
  assert.ok(html.includes('data-install'), 'uses data-install attribute');
});

/* 15. All HTML pages updated to v3.1 footer */
test('all HTML pages have v3.1 footer (not v2)', () => {
  const publicDir = path.join(__dirname, '..', 'public');
  const htmls = fs.readdirSync(publicDir).filter(f => f.endsWith('.html'));
  let count = 0;
  for (const f of htmls) {
    const c = fs.readFileSync(path.join(publicDir, f), 'utf8');
    if (c.includes('drawer-footer')) {
      count++;
      assert.ok(c.includes('Novel Reader v3.1'), `${f} has v3.1 footer`);
      assert.ok(!c.includes('Novel Reader v2</div>'), `${f} does NOT have v2 footer`);
    }
  }
  assert.ok(count >= 10, `at least 10 pages with footer (got ${count})`);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
