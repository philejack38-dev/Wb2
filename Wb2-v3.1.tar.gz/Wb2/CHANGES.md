# تغییرات نسخه ۳.۱ (Mega Update — کیفیت وب)

نسخهٔ ۳.۱ روی **کیفیت** تمرکز داره: کیفیت ترجمه، کیفیت UI، و کیفیت استقرار روی VPS.

## 🎯 قابلیت‌های اصلی این نسخه

### ۱. بازنویسی کامل مترجم برای کیفیت بالاتر 🧠

**پرامپت مترجم کاملاً بازنویسی شد:**
- ✅ **System message جدا از user message** — اکثر providerها (OpenAI، Anthropic، Gemini، Ollama) حالا system role رو درست استفاده می‌کنن. قبلاً همه‌چیز در یک user message بود.
- ✅ **Style guide گسترش یافته** — از ۱۰ اصل به ۲۱ اصل افزایش پیدا کرد. حالا شامل قواعد دقیق برای:
  - Drop pronoun در فارسی (روی فعل تکیه به‌جای تکرار او/آنها)
  - Persian comma (،) به‌جای Latin comma
  - Persian digits (۹) در narration، Western digits (9) در stat blocks
  - Persian guillemets «...» برای همه دیالوگ‌ها
  - Avoid archaic verbs (فرمود، روانه شد، متجلی شد)
  - ۸ مثال few-shot (از ۵ تا افزایش پیدا کرد) با کیفیت بالاتر

**Glossary filtering هوشمند:**
- ✅ فقط اصطلاحاتی که واقعاً در chunk هستن به LLM پاس می‌شن (قبلاً همه ۵۰+ اصطلاح هر بار پاس داده می‌شد — هدر token + سردرگمی LLM)
- ✅ Cache ۶۰ ثانیه‌ای + version-based busting

**Quality validation خودکار:**
- ✅ هر ترجمه بعد از تولید validation می‌شه:
  - Paragraph count باید منطقی باشه (نه خیلی کم = skip، نه خیلی زیاد = split)
  - Translation نباید echo از source باشه
  - برای Chinese source، translation باید Persian chars داشته باشه
  - نباید markdown fence یا "Translation:" prefix داشته باشه
- ✅ اگه validation fail بشه، automatic retry با یادآوری سخت‌گیرانه‌تر

**Context chain بهتر بین chunks:**
- ✅ حالا هم source tail و هم translation tail قبلی به chunk بعدی پاس داده می‌شه (قبلاً فقط یک رو)
- ✅ این کار اصطلاحات رو بین chunks یکپارچه نگه می‌داره

### ۲. نصب‌کننده افزونه‌های Komikku 🧩

**`lib/extensions-installer.js` (جدید):**
- ✅ نصب و حذف منابع Komikku از طریق UI
- ✅ Auto-detect آداپتور داخلی (MangaDex، NovelFull، RoyalRoad، ...)
- ✅ Runtime allow-list extension — دامنه‌های نصب‌شده بدون restart کار می‌کنن
- ✅ Manifest در `lib/extensions/installed/manifest.json`

**`public/extensions.html` (جدید):**
- ✅ صفحهٔ کامل با search + filter (زبان، نصب‌شده، آداپتور)
- ✅ Grid کارت‌ها با badge زبان، NSFW، آداپتور
- ✅ Install/uninstall با یک کلیک

**APIهای جدید:**
- `GET /api/extensions` — لیست نصب‌شده‌ها
- `POST /api/extensions/install` — نصب
- `POST /api/extensions/uninstall` — حذف
- `GET /api/extensions/sources` — کاتالوگ با status نصب

### ۳. اسکریپت نصب VPS (Production-ready) 🚀

**`scripts/install-vps.sh` (جدید):**
- ✅ Node.js 20 LTS نصب خودکار
- ✅ Persian fonts (Vazirmatn، Noto، Noto CJK)
- ✅ systemd service با hardening (NoNewPrivileges، ProtectSystem، RestrictNamespaces، ...)
- ✅ Nginx reverse proxy با SSE support (proxy_buffering off)
- ✅ UFW firewall
- ✅ Optional Caddy برای auto-HTTPS
- ✅ Service user غیر root
- ✅ Idempotent — safe to re-run

**استفاده:**
```bash
sudo bash scripts/install-vps.sh                  # full install
sudo bash scripts/install-vps.sh --caddy           # auto-HTTPS
sudo bash scripts/install-vps.sh --no-nginx --port 3000  # custom
```

### ۴. بهبودهای UI 🎨

**بهبودهای کلی:**
- ✅ تمام صفحات از v2 به v3.1 footer آپدیت شد
- ✅ صفحهٔ `/extensions` به navigation اضافه شد
- ✅ drawer menu در همه صفحات کامل‌تر

**قابلیت‌های reading tracking:**
- ✅ Reading status: `unset | reading | completed | dropped | plan_to_read`
- ✅ Rating (۰-۵ stars) با notes
- ✅ Reading progress (scroll position per chapter) — auto-save + resume
- ✅ Continue Reading list — ناول‌های اخیراً خوانده‌شده
- ✅ Reading heatmap (GitHub-style) — ۳۶۵ روز اخیر

**APIهای جدید:**
- `PUT /api/novel/:id/status` — تنظیم وضعیت خواندن
- `PUT /api/novel/:id/rating` — ثبت امتیاز
- `POST /api/reading/progress` — ذخیره scroll position
- `GET /api/reading/continue` — لیست ادامه خواندن
- `GET /api/reading/heatmap?days=365` — heatmap
- `GET /api/reading/by-status?status=reading` — فیلتر بر اساس وضعیت

### ۵. بهبودهای پایگاه داده 🗄️

جدول‌های جدید:
- `reading_progress` — scroll position per chapter
- `quotes` — نقل‌قول‌های ذخیره‌شده
- `vocabulary` — vocabulary builder با Anki export
- `streak_freezes` — روزهای استراحت (۱ در ماه)
- `chapter_notes` — یادداشت per chapter
- ستون‌های جدید در `novels`: `reading_status`, `rating`, `rating_notes`

### ۶. تست‌ها 🧪

- ✅ `test/v3.1-fixes.test.js` — ۱۵ تست برای قابلیت‌های جدید
- ✅ `npm run test:all` — ۳۸ تست کل (۵ + ۱۸ + ۱۵)

## 🔄 Migration از v3.0

1. `git pull`
2. `npm install` (هیچ dependency جدیدی نیاز نیست)
3. `npm start` — schema خودکار migration می‌شه

---

# تغییرات نسخه ۳.۰ (Mega Update)

نسخهٔ ۳.۰ یک بازنویسی بزرگ بر اساس ممیزی کامل کد هست. **۱۸ باگ بحرانی و امنیتی** فیکس شد، **۴ قابلیت جدید** اضافه شد، و **۶ بهبود performance** اعمال شد.

## 🚨 باگ‌های بحرانی فیکس شده

### ۱. Route Shadowing (Tags/Wiki/Chapters هیچ‌وقت کار نمی‌کرد)
**قبلاً:** `GET /api/novel/:id` همهٔ `/api/novel/*` رو می‌گرفت. Routeهای `/api/novel/:id/chapters`، `/api/novel/:id/tags`، `/api/novel/:id/wiki` هیچ‌وقت اجرا نمی‌شدن. UI سایلنت fail می‌کرد.

**حالا:** Sub-routeها قبل از generic route بررسی می‌شن.

### ۲. Job Queue Starvation
**قبلاً:** `tick()` فقط `db.listJobs(1)` رو می‌خوند (آخرین job). اگه آخرین job `done` بود، pending jobs قدیمی هیچ‌وقت اجرا نمی‌شدن.

**حالا:** `db.listPendingJobs(1)` با `WHERE status='pending' ORDER BY created_at ASC` — FIFO واقعی.

### ۳. Range Scraping/Translation (قابلیت v2.3 واقعاً کار نمی‌کرد)
**قبلاً:** `CHANGES.md` ادعا می‌کرد startChapter/endChapter کار می‌کنه، اما `queue.js` این params رو نادیده می‌گرفت.

**حالا:** `runScrape` و `runTranslateNovel` range رو می‌خونن، به scraper پاس می‌دن، و به‌عنوان defensive post-filter هم اعمال می‌شه.

### ۴. SOCKS5 Proxy برای Translator
**قبلاً:** `undici.ProxyAgent` فقط HTTP/HTTPS proxy رو پشتیبانی می‌کرد. اگه `config.proxy = "socks5://..."`، تموم translationها fail می‌شد.

**حالا:** یه dispatcher سفارشی با `socks5.js` خودمون، هم HTTP و هم SOCKS5 رو پشتیبانی می‌کنه.

### ۵. Backup/Restore (ImportAll فقط novels رو برمی‌گردوند)
**قبلاً:** `importAll` فقط novels رو import می‌کرد. **تمام chapters، bookmarks، glossary، highlights، tags، wiki، achievements، goals، queue، variants از بین می‌رفتن.**

**حالا:** Restore کامل با ID mapping (novel IDs، chapter IDs، tag IDs) — همهٔ ۱۱ data type بازگردانی می‌شه.

### ۶. discovery.checkForUpdates کاملاً خراب بود
**قبلاً:** از `novel.sourceUrl` (camelCase) استفاده می‌کرد در حالی که DB `source_url` (snake_case) برمی‌گردوند. همچنین object به‌جای number به `setUpdateStatus` پاس می‌داد.

**حالا:** از `novel.source_url || novel.sourceUrl` استفاده می‌کنه و signature درست `setUpdateStatus(novelId, status, newChaptersCount, lastUrl)` رو رعایت می‌کنه.

### ۷. PDF Export برای فارسی خراب بود
**قبلاً:** Helvetica font (بدون Persian glyph)، RTL shaping نبود، یک صفحه-only (`/Count 1`)، truncation شدید (۵۰ chapter، ۲۰۰۰ کاراکتر، ۱۰۰ کاراکتر per para).

**حالا:** 
- `pdfkit` برای PDF generation با proper pagination
- `arabic-reshaper` برای Persian glyph shaping
- Vazirmatn font embedding (دانلود خودکار + cache، fallback به FreeSerif سیستم)
- RTL text reversal per-line
- Metadata (Title, Author, Subject, Keywords)
- بدون truncation (configurable via opts)

## 🔒 باگ‌های امنیتی فیکس شده

### ۸. SSRF در `/api/img`
**قبلاً:** فقط `^https?://` چک می‌شد. هرکسی می‌تونست `http://169.254.169.254/latest/meta-data/` یا `http://localhost:PORT/` رو fetch کنه.

**حالا:** `scraper.isAllowed(src)` چک می‌شه. فقط domainهای توی allow-list.

### ۹. API Keys هاردکد شده در config.json
**قبلاً:** `sk-zGwsJ33FoJZ7J0UsTGKGoRgSrKPNwKTCvlzr3jlz531VHfJKg23jgcmE7xCxmSfm` (opencode) و `sk-jEW11RGjEQUbCfUAbVVhZX7agYUDcQAw3o0kfWqiGJdFQ3vO` (agnes) مستقیماً توی repo commit شده بودن.

**حالا:** 
- تمام apiKeyهای config.json خالی شدن
- Environment variable support: `NR_<PROVIDER>_API_KEY` (مثلاً `NR_OPENCODE_API_KEY`)
- فایل `.env.example` با تمام متغیرها
- `server.js` یه `.env` loader بدون dependency داره

### ۱۰. Plaintext Password Comparison (Timing Attack)
**قبلاً:** `if (username !== AUTH.username)` و `if (sig !== expected)` — آسیب‌پذیر به timing attack.

**حالا:** `crypto.timingSafeEqual` برای username، password، و HMAC signature.

### ۱۱. Brute-Force Protection برای Login
**قبلاً:** هیچ محدودیتی نبود — می‌شد unlimited password guess کرد.

**حالا:** بعد از ۵ تلاش ناموفق از هر IP، exponential lockout (۳۰s، ۶۰s، ۱۲۰s، ۲۴۰s، ...). Response 429 با `Retry-After` header.

### ۱۲. X-Forwarded-For Spoofing در Rate Limiter
**قبلاً:** `req.headers['x-forwarded-for']` بدون شرط trust می‌شد. هر request با یه fake IP → bypass rate limit.

**حالا:** فقط وقتی `rateLimit.trustProxy = true` توی config.json باشه. default: false (استفاده از `req.socket.remoteAddress`).

### ۱۳. `booktoki*.com` Wildcard کار نمی‌کرد
**قبلاً:** `*` به‌صورت literal در نظر گرفته می‌شد. `booktoki123.com` با `booktoki*.com` match نمی‌شد.

**حالا:** Wildcard pattern matching با regex (هر `*` به `[^.]*` تبدیل می‌شه).

## ⚡ Performance Improvements

### ۱۴. N+1 Query در Recommendation Engine
**قبلاً:** برای هر session هدف، تمام sessionها (limit 500) fetch می‌شد. برای ۱۰۰ session هدف = ۵۰٬۰۰۰ row.

**حالا:** همهٔ sessionها یک‌بار fetch می‌شن (limit 100000) و یه Set از novel IDهای مرتبط ساخته می‌شه. O(N) به‌جای O(N*M).

### ۱۵. Glossary Cache در Translator
**قبلاً:** `buildGlossaryText()` روی هر chunk یک DB query + یک file parse انجام می‌داد. برای یه chapter با ۱۰ chunk = ۱۰ query + ۱۰ file read.

**حالا:** Cache با TTL ۶۰ ثانیه و version-based busting.

### ۱۶. discovery.checkForUpdates — Fetch Optimization
**قبلاً:** `plugin.fetchNovel(url, { limit: 10000 })` برای diff URLs — download عظیم.

**حالا:** `plugin.getUpdate()` اگه موجود باشه (metadata-only)، در غیر این‌صورت `limit: 200`.

### ۱۷. Rate Limiter — O(1) Eviction
**قبلاً:** `arr.shift()` برای expire بود O(n).

**حالا:** Index pointer با periodic compaction — O(1) amortized.

## ✨ قابلیت‌های جدید

### A. OPDS Catalog Feed (`/opds`)
Feed Atom برای integration با Calibre، Moon+ Reader، و دیگر ebook readerها. هر novel با EPUB acquisition link.

### B. Translation Quality Scoring (`POST /api/translate/score`)
از LLM به‌عنوان judge استفاده می‌کنه تا ترجمه رو ۰-۱۰۰ امتیاز بده. اگه LLM تنظیم نشده باشه، heuristic fallback (length ratio + Persian char ratio).

### C. CSV/JSON Stats Export (`GET /api/stats/export?format=csv|json`)
Export کامل reading sessions برای تحلیل خارجی. شامل novel title، chapter index، duration، words read.

### D. Job Cancellation
Workers بین chapters بررسی می‌کنن آیا job cancelled شده (`DELETE /api/job/:id`). اگه بله، زود متوقف می‌شه و `job:cancelled` SSE event broadcast می‌شه.

## 🎨 UX/UI Fixes

### E. SSE Handler Leak
**قبلاً:** `sse.on('job:done', ...)` در هر click اضافه می‌شد بدون unsubscribe. بعد از ۵ click روی «download more»، ۱۵ handler اورفن می‌شد.

**حالا:** Helper جدید `sse.trackJob(jobId, { onProgress, onDone, onFailed })` خودش بعد از done/failed unsubscribe می‌کنه.

### F. Bundled Vazirmatn Font (Offline PWA Fix)
**قبلاً:** `@import url('https://fonts.googleapis.com/...')` — offline PWA خراب، Iran network fail.

**حالا:** Vazirmatn woff2 (Regular/Medium/Bold) توی `public/fonts/` bundle شده. Service worker v5 اونها رو pre-cache می‌کنه.

### G. .env Loader بدون Dependency
`.env` file در root رو می‌خونه و `process.env` رو populate می‌کنه. نیازی به `dotenv` package نیست.

## 🧪 Tests
- `test/v3-fixes.test.js` — ۱۸ تست برای همهٔ fixهای بالا
- `npm run test:all` — هر دو suite رو اجرا می‌کنه

## 📦 Dependencies جدید
- `pdfkit` — PDF generation با font embedding
- `arabic-reshaper` — Persian/Arabic glyph shaping

## 🔄 Migration از v2
1. `npm install` (برای pdfkit + arabic-reshaper)
2. `.env.example` رو به `.env` کپی کن و API keyها رو وارد کن
3. `npm start` — server بالا میاد، Vazirmatn font خودکار دانلود می‌شه (بار اول)
4. دیتای موجود در SQLite به‌طور خودکار migration می‌شه (schema تغییر نکرده)

---

# تغییرات نسخه ۲.۳ (اصلاحات UX عمیق)

## 🐛 مشکلات UX که فیکس شد

### ۱. نصب یک‌کلیکی بدون کنترل کاربر
**قبلاً:** کاربر در catalog/discover/home روی «📥 نصب و ترجمه» کلیک می‌کرد و سرور خودکار ۳ فصل اول رو دانلود + ترجمه می‌کرد.

**حالا:** یک modal کامل با گزینه‌های محدوده دانلود، شمارش زنده، ترجمه خودکار، و محدوده ترجمه جداگانه.
