'use strict';
/**
 * Basic tests for scraper extraction logic.
 * Run: node test/scraper.test.js
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const scraper = require('../lib/scraper');

const fixture = fs.readFileSync(path.join(__dirname, 'fixture.html'), 'utf8');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); console.log('  ✓', name); passed++; }
  catch (e) { console.log('  ✗', name, '\n    ', e.message); failed++; }
}

console.log('\nScraper tests:');

test('extractTitle prefers og:title over <title>', () => {
  const t = scraper.extractTitle(fixture);
  assert.strictEqual(t, 'Test Novel');
});

test('extractTitle falls back to <title> without og:title', () => {
  const html = '<html><head><title>Fallback Title</title></head><body></body></html>';
  const t = scraper.extractTitle(html);
  assert.strictEqual(t, 'Fallback Title');
});

test('extractContent picks largest chapter-content block', () => {
  const c = scraper.extractContent(fixture);
  assert.ok(c.includes('sun rose'), 'should contain "sun rose": ' + c);
  assert.ok(c.includes('Kael'), 'should contain Kael');
  assert.ok(!c.includes('footer'), 'should not contain footer noise');
});

test('detectSite', () => {
  assert.strictEqual(scraper.detectSite('https://www.piaotia.com/x'), 'piaotia');
  assert.strictEqual(scraper.detectSite('https://www.webnovel.com/x'), 'webnovel');
  assert.strictEqual(scraper.detectSite('https://www.wuxiaworld.com/x'), 'wuxiaworld');
  assert.strictEqual(scraper.detectSite('https://example.com/x'), 'generic');
});

test('extractChapterLinks finds chapter anchors', () => {
  const html = `
    <a href="/chapter/1">Chapter 1: Start</a>
    <a href="/chapter/2">Chapter 2: End</a>
    <a href="/about">About</a>
  `;
  const links = scraper.extractChapterLinks(html, 'https://example.com/');
  assert.strictEqual(links.length, 2, 'should find 2 chapter links');
  assert.strictEqual(links[0].href, 'https://example.com/chapter/1');
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
