'use strict';
/**
 * Novel Reader server v2 — Node.js HTTP server with:
 *  - Multi-site scraper (piaotia, webnovel, wuxiaworld, novelupdates, novelfull, generic)
 *  - Multi-provider AI translator (opencode, openai, openrouter, anthropic, deepseek, gemini, ollama)
 *  - SQLite storage with FTS5
 *  - Background job queue with SSE live progress
 *  - Auth + rate limiting (optional)
 *  - EPUB export, glossary auto-extraction, full-text search, bookmarks
 *  - PWA support
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const db = require('./lib/db');
const queue = require('./lib/queue');
const auth = require('./lib/auth');
const rateLimit = require('./lib/rateLimit');
const epub = require('./lib/epub');
const markdown = require('./lib/markdown');
const pdf = require('./lib/pdf');
const scraper = require('./lib/scraper');
const registry = require('./lib/scrapers');
const translator = require('./lib/translator');
const recommend = require('./lib/recommend');
const discovery = require('./lib/discovery');
const scheduler = require('./lib/scheduler');
const komikku = require('./lib/komikku');

const CONFIG = require('./config.json');
const PUBLIC = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.epub': 'application/epub+zip',
  '.webmanifest': 'application/manifest+json'
};

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/octet-stream' }, headers || {}));
  res.end(body);
}
function json(res, status, obj) {
  const body = JSON.stringify(obj);
  send(res, status, body, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
}
function readBody(req, limit = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new Error('payload too large')); req.destroy(); return; }
      data += c;
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}
function serveStatic(req, res, override) {
  let urlPath = override || req.url.split('?')[0];
  if (urlPath === '/') urlPath = '/index.html';
  // normalize and prevent path traversal
  const filePath = path.resolve(path.join(PUBLIC, path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '')));
  if (!filePath.startsWith(PUBLIC)) return send(res, 403, 'Forbidden');
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, 'Not found');
    const ext = path.extname(filePath);
    send(res, 200, data, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
  });
}

/* ------------------------------------------------------------------ *
 * Routes
 * ------------------------------------------------------------------ */
const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://${req.headers.host}`); }
  catch { return json(res, 400, { error: 'bad url' }); }

  // Apply rate limiter + auth
  rateLimit.middleware(req, res, async () => {
    if (auth.enabled()) {
      // Auth wraps everything; if not enabled, just continue
      return authRun(req, res, url);
    }
    return authRun(req, res, url);
  });
});

function authRun(req, res, url) {
  if (!auth.enabled()) return handle(req, res, url);
  auth.middleware(req, res, () => handle(req, res, url));
}

async function handle(req, res, url) {
  const p = url.pathname;
  const m = req.method;
  try {
    /* ---------- Static pages ---------- */
    if (m === 'GET' && p === '/') return serveStatic(req, res, '/home.html');
    if (m === 'GET' && p === '/home') return serveStatic(req, res, '/home.html');
    if (m === 'GET' && p === '/library') return serveStatic(req, res, '/index.html');
    if (m === 'GET' && p === '/catalog') return serveStatic(req, res, '/catalog.html');
    if (m === 'GET' && p === '/read') return serveStatic(req, res, '/reader.html');
    if (m === 'GET' && p === '/detail') return serveStatic(req, res, '/detail.html');
    if (m === 'GET' && p === '/admin') return serveStatic(req, res, '/admin.html');
    if (m === 'GET' && p === '/settings') return serveStatic(req, res, '/settings.html');
    if (m === 'GET' && p === '/stats') return serveStatic(req, res, '/stats.html');
    if (m === 'GET' && p === '/search') return serveStatic(req, res, '/search.html');
    if (m === 'GET' && p === '/login') return serveStatic(req, res, '/login.html');
    if (m === 'GET' && p === '/history') return serveStatic(req, res, '/history.html');
    if (m === 'GET' && p === '/highlights') return serveStatic(req, res, '/highlights.html');
    if (m === 'GET' && p === '/achievements') return serveStatic(req, res, '/achievements.html');
    if (m === 'GET' && p === '/goals') return serveStatic(req, res, '/goals.html');
    if (m === 'GET' && p === '/updates') return serveStatic(req, res, '/updates.html');
    if (m === 'GET' && p === '/wiki') return serveStatic(req, res, '/wiki.html');
    if (m === 'GET' && p === '/queue') return serveStatic(req, res, '/queue.html');
    if (m === 'GET' && p === '/komikku') return serveStatic(req, res, '/komikku.html');
    if (m === 'GET' && p === '/discover') return serveStatic(req, res, '/discover.html');
    if (m === 'GET' && p === '/manifest.json') return serveStatic(req, res, '/manifest.json');
    if (m === 'GET' && p === '/sw.js') return serveStatic(req, res, '/sw.js');
    if (m === 'GET' && p === '/favicon.ico') return serveStatic(req, res, '/icons/favicon.svg');

    /* ---------- Auth ---------- */
    if (m === 'POST' && p === '/api/login') {
      const body = JSON.parse(await readBody(req) || '{}');
      const token = auth.login(body.username, body.password);
      if (!token) return json(res, 401, { error: 'invalid credentials' });
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Set-Cookie': `nr_token=${token}; Path=/; HttpOnly; Max-Age=${(CONFIG.auth?.tokenTtlMinutes || 720) * 60}; SameSite=Lax`
      });
      return res.end(JSON.stringify({ token }));
    }
    if (m === 'POST' && p === '/api/logout') {
      res.writeHead(200, { 'Set-Cookie': 'nr_token=; Path=/; HttpOnly; Max-Age=0' });
      return res.end(JSON.stringify({ ok: true }));
    }
    if (m === 'GET' && p === '/api/auth/check') {
      return json(res, 200, { authenticated: !auth.enabled() || !!auth.verify((req.headers.authorization || '').replace('Bearer ', '')), enabled: auth.enabled() });
    }

    /* ---------- Stats ---------- */
    if (m === 'GET' && p === '/api/stats') return json(res, 200, db.stats());

    /* ---------- Settings ---------- */
    if (m === 'GET' && p === '/api/settings') {
      const settings = db.getSetting('ui', { theme: 'dark', fontFamily: 'Vazirmatn', fontSize: 18, lineHeight: 1.9 });
      const tcfg = CONFIG.translator || {};
      return json(res, 200, {
        ui: settings,
        providers: Object.keys(tcfg.providers || {}),
        activeProvider: tcfg.provider,
        activeModel: (tcfg.providers?.[tcfg.provider] || {}).model,
        translatorConfigured: translator.isConfigured(),
        authEnabled: auth.enabled()
      });
    }
    if (m === 'POST' && p === '/api/settings') {
      const body = JSON.parse(await readBody(req) || '{}');
      const cur = db.getSetting('ui', {});
      db.setSetting('ui', { ...cur, ...body });
      return json(res, 200, { ok: true, ui: db.getSetting('ui') });
    }

    /* ---------- Novels ---------- */
    if (m === 'GET' && p === '/api/novels') return json(res, 200, db.getNovels());

    if (m === 'GET' && p.startsWith('/api/novel/')) {
      const id = p.split('/')[3];
      const withChapters = url.searchParams.get('chapters') !== '0';
      if (withChapters) {
        const novel = db.getNovel(id);
        if (!novel) return json(res, 404, { error: 'novel not found' });
        return json(res, 200, novel);
      } else {
        const meta = db.getNovelMeta(id);
        if (!meta) return json(res, 404, { error: 'novel not found' });
        return json(res, 200, meta);
      }
    }

    if (m === 'GET' && p.startsWith('/api/novel/') && p.endsWith('/chapters')) {
      const id = p.split('/')[3];
      return json(res, 200, db.listChapters(id));
    }

    if (m === 'DELETE' && p.startsWith('/api/novel/')) {
      const id = p.split('/')[3];
      db.deleteNovel(id);
      return json(res, 200, { ok: true });
    }

    /* ---------- Chapters ---------- */
    if (m === 'GET' && p.startsWith('/api/chapter/')) {
      const id = p.split('/')[3];
      const ch = db.getChapter(id);
      if (!ch) return json(res, 404, { error: 'chapter not found' });
      return json(res, 200, ch);
    }

    if (m === 'GET' && p === '/api/chapter' && url.searchParams.has('novel') && url.searchParams.has('idx')) {
      const novelId = url.searchParams.get('novel');
      const idx = parseInt(url.searchParams.get('idx'));
      const ch = db.getChapterByIndex(novelId, idx);
      if (!ch) return json(res, 404, { error: 'chapter not found' });
      return json(res, 200, ch);
    }

    /* ---------- Add (scrape) ---------- */
    if (m === 'POST' && p === '/api/add') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.url) return json(res, 400, { error: 'url required' });
      const limit = Math.min(2000, Math.max(1, parseInt(body.limit) || 3));
      const autoTranslate = !!body.autoTranslate;
      const startChapter = body.startChapter ? Math.max(1, parseInt(body.startChapter)) : 1;
      const endChapter = body.endChapter ? Math.max(startChapter, parseInt(body.endChapter)) : null;
      // Optional: separate translate range (if user wants different range for translation)
      const translateRange = (body.translateStart && body.translateEnd)
        ? { start: parseInt(body.translateStart), end: parseInt(body.translateEnd) }
        : null;
      const jobId = queue.enqueue('scrape', {
        url: body.url,
        limit,
        autoTranslate,
        startChapter,
        endChapter,
        translateRange
      });
      return json(res, 202, { jobId, status: 'queued', message: 'scrape started' });
    }

    /* ---------- Add more chapters to existing novel ---------- */
    if (m === 'POST' && p === '/api/add-more') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.novelId) return json(res, 400, { error: 'novelId required' });
      const novel = db.getNovelMeta(body.novelId);
      if (!novel) return json(res, 404, { error: 'novel not found' });
      const url = novel.source_url || novel.sourceUrl;
      if (!url) return json(res, 400, { error: 'novel has no source URL' });
      const startChapter = body.startChapter ? Math.max(1, parseInt(body.startChapter)) : (novel.chapterCount || 0) + 1;
      const endChapter = body.endChapter ? Math.max(startChapter, parseInt(body.endChapter)) : null;
      const autoTranslate = !!body.autoTranslate;
      const jobId = queue.enqueue('scrape', {
        url,
        limit: endChapter ? (endChapter - startChapter + 1) : 5,
        autoTranslate,
        startChapter,
        endChapter
      });
      return json(res, 202, { jobId, status: 'queued', message: 'scrape more started' });
    }

    /* ---------- Translate ---------- */
    if (m === 'POST' && p.startsWith('/api/translate/')) {
      const parts = p.split('/');
      if (parts[3] === 'novel') {
        const novelId = parts[4];
        const novel = db.getNovelMeta(novelId);
        if (!novel) return json(res, 404, { error: 'novel not found' });
        const body = JSON.parse(await readBody(req).catch(() => '{}') || '{}');
        const mode = body.mode || 'pending';
        // Support range translation: { mode: 'range', start: 5, end: 10 }
        const startChapter = body.start ? parseInt(body.start) : null;
        const endChapter = body.end ? parseInt(body.end) : null;
        const jobId = queue.enqueue('translate_novel', { novelId, mode, startChapter, endChapter });
        return json(res, 202, { jobId, status: 'queued' });
      } else if (parts[3] === 'chapter') {
        const chId = parts[4];
        const ch = db.getChapter(chId);
        if (!ch) return json(res, 404, { error: 'chapter not found' });
        const jobId = queue.enqueue('translate_chapter', { chapterId: chId });
        return json(res, 202, { jobId, status: 'queued' });
      } else {
        // legacy: /api/translate/:chapterId
        const chId = parts[3];
        const ch = db.getChapter(chId);
        if (!ch) return json(res, 404, { error: 'chapter not found' });
        const jobId = queue.enqueue('translate_chapter', { chapterId: chId });
        return json(res, 202, { jobId, status: 'queued' });
      }
    }

    /* ---------- Jobs ---------- */
    if (m === 'GET' && p === '/api/jobs') return json(res, 200, db.listJobs(50));
    if (m === 'GET' && p.startsWith('/api/job/')) {
      const id = p.split('/')[3];
      const j = db.getJob(id);
      if (!j) return json(res, 404, { error: 'job not found' });
      return json(res, 200, j);
    }
    if (m === 'DELETE' && p.startsWith('/api/job/')) {
      const id = p.split('/')[3];
      db.updateJob(id, { status: 'cancelled' });
      return json(res, 200, { ok: true });
    }

    /* ---------- SSE stream ---------- */
    if (m === 'GET' && p === '/api/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no'
      });
      res.write(': connected\n\n');
      const remove = queue.addSSEClient(res);
      const ka = setInterval(() => { try { res.write(': keepalive\n\n'); } catch {} }, 25000);
      req.on('close', () => { clearInterval(ka); remove(); });
      return;
    }

    /* ---------- Search ---------- */
    if (m === 'GET' && p === '/api/search') {
      const q = url.searchParams.get('q') || '';
      return json(res, 200, db.searchChapters(q, 100));
    }

    /* ---------- Bookmarks ---------- */
    if (m === 'POST' && p === '/api/bookmark') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.novelId) return json(res, 400, { error: 'novelId required' });
      db.setBookmark(body.novelId, body.chapterIndex);
      return json(res, 200, { ok: true });
    }
    if (m === 'GET' && p === '/api/bookmarks') return json(res, 200, db.getAllBookmarks());

    /* ---------- Glossary ---------- */
    if (m === 'GET' && p === '/api/glossary') {
      const novelId = url.searchParams.get('novel');
      const entries = db.getGlossary(novelId);
      // Merge with static glossary file
      const staticG = translator.GLOSSARY;
      const staticEntries = [];
      for (const cat of ['cultivation', 'honorifics', 'ranks']) {
        const obj = staticG[cat];
        if (!obj) continue;
        for (const [k, v] of Object.entries(obj)) {
          if (k.startsWith('_')) continue;
          staticEntries.push({ term: k, translation: v, category: cat, novelId: null });
        }
      }
      // Deduplicate (DB overrides static)
      const seen = new Set();
      const out = [];
      for (const e of entries) { seen.add(e.term); out.push(e); }
      for (const e of staticEntries) { if (!seen.has(e.term)) out.push(e); }
      return json(res, 200, out);
    }
    if (m === 'POST' && p === '/api/glossary') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.term || !body.translation) return json(res, 400, { error: 'term + translation required' });
      db.addGlossaryEntry(body.novelId, body.term, body.translation, body.category || 'manual');
      return json(res, 200, { ok: true });
    }
    if (m === 'POST' && p === '/api/glossary/extract') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.novelId) return json(res, 400, { error: 'novelId required' });
      const jobId = queue.enqueue('extract_glossary', { novelId: body.novelId });
      return json(res, 202, { jobId });
    }

    /* ---------- EPUB export ---------- */
    if (m === 'GET' && p.startsWith('/api/epub/')) {
      const id = p.split('/')[3];
      const useOriginal = url.searchParams.get('mode') === 'original';
      try {
        const buf = epub.generate(id, { useOriginal });
        const safeTitle = (db.getNovelMeta(id)?.title || 'novel').replace(/[^\w\u0600-\u06FF\-_ ]/g, '_');
        res.writeHead(200, {
          'Content-Type': 'application/epub+zip',
          'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(safeTitle)}.epub`,
          'Content-Length': buf.length
        });
        return res.end(buf);
      } catch (e) {
        return json(res, 400, { error: e.message });
      }
    }

    /* ---------- Markdown / PDF export ---------- */
    if (m === 'GET' && p.startsWith('/api/markdown/')) {
      const id = p.split('/')[3];
      const useOriginal = url.searchParams.get('mode') === 'original';
      try {
        const buf = markdown.generate(id, { useOriginal });
        const safeTitle = (db.getNovelMeta(id)?.title || 'novel').replace(/[^\w\u0600-\u06FF\-_ ]/g, '_');
        res.writeHead(200, {
          'Content-Type': 'text/markdown; charset=utf-8',
          'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(safeTitle)}.md`,
          'Content-Length': buf.length
        });
        return res.end(buf);
      } catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (m === 'GET' && p.startsWith('/api/pdf/')) {
      const id = p.split('/')[3];
      try {
        const buf = pdf.generate(id);
        const safeTitle = (db.getNovelMeta(id)?.title || 'novel').replace(/[^\w\u0600-\u06FF\-_ ]/g, '_');
        res.writeHead(200, {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(safeTitle)}.pdf`,
          'Content-Length': buf.length
        });
        return res.end(buf);
      } catch (e) { return json(res, 400, { error: e.message }); }
    }

    /* ---------- Backup / restore ---------- */
    if (m === 'GET' && p === '/api/backup') {
      const data = db.exportAll();
      const body = JSON.stringify(data);
      return res.writeHead(200, {
        'Content-Type': 'application/json',
        'Content-Disposition': 'attachment; filename="novel-reader-backup.json"',
        'Content-Length': Buffer.byteLength(body)
      }).end(body);
    }
    if (m === 'POST' && p === '/api/restore') {
      const body = JSON.parse(await readBody(req, 50 * 1024 * 1024) || '{}');
      const r = db.importAll(body);
      return json(res, 200, r);
    }

    /* ---------- Reading sessions ---------- */
    if (m === 'POST' && p === '/api/reading/session') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (body.action === 'start') {
        const id = db.startSession(body.novelId, body.chapterId, body.chapterIndex);
        return json(res, 200, { sessionId: id });
      } else if (body.action === 'end' && body.sessionId) {
        db.endSession(body.sessionId, body.wordsRead);
        db.checkAchievements();
        return json(res, 200, { ok: true });
      }
      return json(res, 400, { error: 'invalid action' });
    }
    if (m === 'GET' && p === '/api/reading/stats') {
      const range = url.searchParams.get('range') || 'week';
      return json(res, 200, db.getReadingStats(range));
    }
    if (m === 'GET' && p === '/api/reading/sessions') {
      const novelId = url.searchParams.get('novel');
      const limit = parseInt(url.searchParams.get('limit')) || 100;
      return json(res, 200, db.getSessions({ novelId, limit }));
    }
    if (m === 'GET' && p === '/api/reading/streak') {
      return json(res, 200, { streak: db.getStreak() });
    }

    /* ---------- Highlights ---------- */
    if (m === 'POST' && p === '/api/highlights') {
      const body = JSON.parse(await readBody(req) || '{}');
      const id = db.addHighlight(body);
      db.checkAchievements();
      return json(res, 200, { id });
    }
    if (m === 'GET' && p === '/api/highlights') {
      const novelId = url.searchParams.get('novel');
      const chapterId = url.searchParams.get('chapter');
      return json(res, 200, db.getHighlights({ novelId, chapterId }));
    }
    if (m === 'DELETE' && p.startsWith('/api/highlights/')) {
      const id = p.split('/')[3];
      db.deleteHighlight(id);
      return json(res, 200, { ok: true });
    }

    /* ---------- Tags ---------- */
    if (m === 'GET' && p === '/api/tags') return json(res, 200, db.listTags());
    if (m === 'POST' && p === '/api/tags') {
      const body = JSON.parse(await readBody(req) || '{}');
      const t = db.addTag(body.name, body.color);
      return json(res, 200, t);
    }
    if (m === 'GET' && p.startsWith('/api/novel/') && p.endsWith('/tags')) {
      const id = p.split('/')[3];
      return json(res, 200, db.getNovelTags(id));
    }
    if (m === 'POST' && p.startsWith('/api/novel/') && p.endsWith('/tags')) {
      const id = p.split('/')[3];
      const body = JSON.parse(await readBody(req) || '{}');
      db.setNovelTags(id, body.tags || []);
      return json(res, 200, { ok: true });
    }

    /* ---------- Wiki ---------- */
    if (m === 'GET' && p.startsWith('/api/novel/') && p.endsWith('/wiki')) {
      const id = p.split('/')[3];
      return json(res, 200, db.getWiki(id));
    }
    if (m === 'POST' && p === '/api/wiki/extract') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.novelId) return json(res, 400, { error: 'novelId required' });
      const jobId = queue.enqueue('extract_wiki', { novelId: body.novelId });
      return json(res, 202, { jobId });
    }

    /* ---------- Achievements ---------- */
    if (m === 'GET' && p === '/api/achievements') {
      return json(res, 200, db.checkAchievements());
    }

    /* ---------- Goals ---------- */
    if (m === 'GET' && p === '/api/goals') return json(res, 200, db.listGoals());
    if (m === 'POST' && p === '/api/goals') {
      const body = JSON.parse(await readBody(req) || '{}');
      const id = db.addGoal(body.type, body.target, body.period);
      return json(res, 200, { id });
    }
    if (m === 'DELETE' && p.startsWith('/api/goals/')) {
      db.deleteGoal(p.split('/')[3]);
      return json(res, 200, { ok: true });
    }

    /* ---------- Source updates ---------- */
    if (m === 'GET' && p === '/api/updates') return json(res, 200, db.listUpdates());
    if (m === 'POST' && p === '/api/updates/check') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (body.all) {
        const jobId = queue.enqueue('check_all_updates', {});
        return json(res, 202, { jobId });
      }
      if (!body.novelId) return json(res, 400, { error: 'novelId required' });
      const jobId = queue.enqueue('check_updates', { novelId: body.novelId });
      return json(res, 202, { jobId });
    }
    if (m === 'GET' && p.startsWith('/api/updates/') && p.endsWith('/status')) {
      const id = p.split('/')[3];
      return json(res, 200, db.getUpdateStatus(id) || { status: 'unknown' });
    }

    /* ---------- Recommendations ---------- */
    if (m === 'GET' && p.startsWith('/api/recommend/') && p.endsWith('/novel')) {
      const id = p.split('/')[3];
      return json(res, 200, recommend.recommend(id));
    }
    if (m === 'GET' && p === '/api/recommend/global') {
      return json(res, 200, recommend.recommendGlobal());
    }

    /* ---------- Translation variants (A/B) ---------- */
    if (m === 'GET' && p.startsWith('/api/variants/') && p.endsWith('/chapter')) {
      const id = p.split('/')[3];
      return json(res, 200, db.getVariants(id));
    }
    if (m === 'POST' && p === '/api/translate/compare') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.chapterId) return json(res, 400, { error: 'chapterId required' });
      const jobId = queue.enqueue('compare_models', { chapterId: body.chapterId, providers: body.providers });
      return json(res, 202, { jobId });
    }

    /* ---------- Reading queue ---------- */
    if (m === 'GET' && p === '/api/queue') return json(res, 200, db.getQueue());
    if (m === 'POST' && p === '/api/queue') {
      const body = JSON.parse(await readBody(req) || '{}');
      db.addToQueue(body.novelId, body.priority || 0);
      return json(res, 200, { ok: true });
    }
    if (m === 'DELETE' && p.startsWith('/api/queue/')) {
      db.removeFromQueue(p.split('/')[3]);
      return json(res, 200, { ok: true });
    }

    /* ---------- Discovery Engine v2 ---------- */
    if (m === 'GET' && p === '/api/discover/sources') {
      const sources = await discovery.getSources().catch(() => []);
      return json(res, 200, sources);
    }
    if (m === 'GET' && p === '/api/discover/genres') {
      const genres = await discovery.getGenres().catch(() => []);
      return json(res, 200, genres);
    }
    if (m === 'GET' && p === '/api/discover/search') {
      const q = url.searchParams.get('q') || '';
      const sitesParam = url.searchParams.get('sites');
      const sites = sitesParam ? sitesParam.split(',').filter(Boolean) : null;
      const results = await discovery.searchAll(q, { sites }).catch(() => []);
      return json(res, 200, results);
    }
    if (m === 'GET' && p === '/api/discover/trending') {
      const sitesParam = url.searchParams.get('sites');
      const sites = sitesParam ? sitesParam.split(',').filter(Boolean) : null;
      const results = await discovery.getTrending({ sites }).catch(() => []);
      return json(res, 200, results);
    }
    if (m === 'GET' && p === '/api/discover/popular') {
      const sitesParam = url.searchParams.get('sites');
      const sites = sitesParam ? sitesParam.split(',').filter(Boolean) : null;
      const results = await discovery.getPopular({ sites }).catch(() => []);
      return json(res, 200, results);
    }
    if (m === 'GET' && p === '/api/discover/random') {
      return json(res, 200, discovery.getRandomLegendary());
    }
    if (m === 'GET' && p === '/api/discover/taste') {
      const results = await discovery.getTasteRecommendations().catch(() => []);
      return json(res, 200, results);
    }
    if (m === 'GET' && p === '/api/discover/genre') {
      const g = url.searchParams.get('g') || 'Fantasy';
      const sitesParam = url.searchParams.get('sites');
      const sites = sitesParam ? sitesParam.split(',').filter(Boolean) : null;
      const results = await discovery.getByGenre(g, { sites }).catch(() => []);
      return json(res, 200, results);
    }
    /* Auto-detect site plugin for a URL (for the admin page) */
    if (m === 'GET' && p === '/api/discover/detect') {
      const u = url.searchParams.get('url');
      if (!u) return json(res, 400, { error: 'url required' });
      const plugin = registry.findForUrl(u);
      if (!plugin) return json(res, 404, { error: 'no plugin' });
      return json(res, 200, { id: plugin.id, name: plugin.name, baseUrl: plugin.baseUrl });
    }

    /* ---------- Komikku catalog ---------- */
    if (m === 'GET' && p === '/api/komikku/sources') {
      const lang = url.searchParams.get('lang');
      const query = url.searchParams.get('q');
      const category = url.searchParams.get('cat');
      const limit = parseInt(url.searchParams.get('limit')) || 500;
      try {
        const list = await komikku.listSources({ lang, query, category, limit });
        return json(res, 200, list.map(s => ({
          name: s.name,
          className: s.className,
          lang: s.lang,
          baseUrl: s.baseUrl,
          category: s.category,
          version: s.version,
          nsfw: s.nsfw,
          scrapable: komikku.isScrapable(s)
        })));
      } catch (e) { return json(res, 502, { error: e.message }); }
    }
    if (m === 'GET' && p === '/api/komikku/languages') {
      try { return json(res, 200, await komikku.listLanguages()); }
      catch (e) { return json(res, 502, { error: e.message }); }
    }
    if (m === 'GET' && p.startsWith('/api/komikku/source/')) {
      const cls = decodeURIComponent(p.split('/')[4]);
      try {
        const s = await komikku.getSource(cls);
        if (!s) return json(res, 404, { error: 'source not found' });
        return json(res, 200, { ...s, scrapable: komikku.isScrapable(s) });
      } catch (e) { return json(res, 502, { error: e.message }); }
    }
    if (m === 'POST' && p === '/api/komikku/scrape') {
      // Try to scrape a manga from a Komikku source's baseUrl using the generic adapter
      const body = JSON.parse(await readBody(req) || '{}');
      if (!body.url) return json(res, 400, { error: 'url required' });
      const limit = Math.min(50, Math.max(1, parseInt(body.limit) || 3));
      const jobId = queue.enqueue('scrape', { url: body.url, limit });
      return json(res, 202, { jobId, status: 'queued', message: 'scrape started (generic adapter)' });
    }
    if (m === 'POST' && p === '/api/komikku/refresh') {
      try {
        await komikku.fetchCatalog(true);
        return json(res, 200, { ok: true, message: 'catalog refreshed' });
      } catch (e) { return json(res, 502, { error: e.message }); }
    }

    /* ---------- Proxy image (for cover URLs that need same UA) ---------- */
    if (m === 'GET' && p === '/api/img') {
      const src = url.searchParams.get('src');
      if (!src || !/^https?:\/\//.test(src)) return json(res, 400, { error: 'invalid src' });
      try {
        const { buf, ct } = await scraper.fetchBinary(src);
        res.writeHead(200, { 'Content-Type': ct || 'image/jpeg', 'Cache-Control': 'public, max-age=86400', 'Content-Length': buf.length });
        return res.end(buf);
      } catch (e) {
        return json(res, 502, { error: e.message });
      }
    }

    /* ---------- Static ---------- */
    if (m === 'GET' || m === 'POST') return serveStatic(req, res);
    if (m === 'HEAD') {
      // Return headers only for static files
      let urlPath = req.url.split('?')[0];
      if (urlPath === '/') urlPath = '/index.html';
      const filePath = path.resolve(path.join(PUBLIC, path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '')));
      if (!filePath.startsWith(PUBLIC)) return send(res, 403, 'Forbidden');
      fs.stat(filePath, (err, st) => {
        if (err) return send(res, 404, '');
        const ext = path.extname(filePath);
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size });
        res.end();
      });
      return;
    }
    return json(res, 405, { error: 'method not allowed' });
  } catch (e) {
    console.error('[server] error:', e);
    return json(res, 500, { error: String(e && e.message || e) });
  }
}

/* ------------------------------------------------------------------ *
 * Boot
 * ------------------------------------------------------------------ */
queue.start();
scheduler.start();
db.pruneJobs(7);
// Check achievements once on boot
try { db.checkAchievements(); } catch {}

const host = CONFIG.host || '127.0.0.1';
server.listen(CONFIG.port, host, () => {
  console.log(`\n  Novel Reader v2 running at http://${host}:${CONFIG.port}`);
  console.log(`  Storage: ${db.mode === 'sqlite' ? 'SQLite (' + db.stats().dbSizeBytes + ' bytes)' : 'JSON file'}`);
  console.log(`  Translator provider: ${CONFIG.translator?.provider || 'opencode'} — ${translator.isConfigured() ? '✓ configured' : '✗ NOT configured'}`);
  console.log(`  Auth: ${auth.enabled() ? 'enabled' : 'disabled'}`);
  console.log(`  Proxy: ${CONFIG.proxy ? 'SOCKS5 via ' + CONFIG.proxy : 'direct'}\n`);
});

process.on('SIGINT', () => { console.log('\nshutting down…'); queue.stop(); scheduler.stop(); process.exit(0); });
process.on('SIGTERM', () => { queue.stop(); scheduler.stop(); process.exit(0); });
