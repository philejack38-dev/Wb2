#!/usr/bin/env bash
# Novel Reader v2 — start script (Linux / macOS)
set -e
cd "$(dirname "$0")/.."

if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js not found. Install it from https://nodejs.org (v18+)"
  exit 1
fi

NODE_VERSION=$(node -p 'process.versions.node.split(".")[0]')
if [ "$NODE_VERSION" -lt 18 ]; then
  echo "❌ Node.js v18+ required (found v$NODE_VERSION)"
  exit 1
fi

# Install better-sqlite3 if missing AND not declined
if [ ! -d "node_modules/better-sqlite3" ] && [ -z "$NO_INSTALL" ]; then
  echo "📦 Installing dependencies (better-sqlite3)…"
  npm install --omit=dev 2>/dev/null || {
    echo "⚠️  npm install failed — falling back to JSON storage mode."
    echo "    Re-run with NO_INSTALL=1 to skip this check."
  }
fi

PORT="${PORT:-8080}"
echo "🚀 Starting Novel Reader v2 on http://localhost:${PORT}"
echo "   Press Ctrl+C to stop."
exec node server.js
