#!/usr/bin/env node
'use strict';
/**
 * Seed glossary from lib/glossary.json into the database (per-novel or global).
 * Usage:
 *   node scripts/seed-glossary.js                 # global
 *   node scripts/seed-glossary.js n1234abcd        # per-novel
 */
const path = require('path');
const fs = require('fs');
const db = require('../lib/db');

const novelId = process.argv[2] || null;
const G = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'lib', 'glossary.json'), 'utf8'));

let count = 0;
for (const cat of ['cultivation', 'honorifics', 'ranks']) {
  const obj = G[cat];
  if (!obj) continue;
  for (const [k, v] of Object.entries(obj)) {
    if (k.startsWith('_')) continue;
    db.addGlossaryEntry(novelId, k, v, cat);
    count++;
  }
}
console.log(`✓ Seeded ${count} glossary entries ${novelId ? 'for novel ' + novelId : 'globally'}`);
