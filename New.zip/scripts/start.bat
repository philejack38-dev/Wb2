@echo off
REM Novel Reader v2 - start script (Windows)
cd /d "%~dp0\.."

node --version >nul 2>&1 || (
  echo Node.js not found. Install it from https://nodejs.org ^(v18+^)
  pause
  exit /b 1
)

if not exist "node_modules\better-sqlite3" (
  echo Installing dependencies (better-sqlite3)...
  call npm install --omit=dev || echo Warning: npm install failed - falling back to JSON storage mode.
)

echo Starting Novel Reader v2 on http://localhost:8080
echo Press Ctrl+C to stop.
node server.js
pause
