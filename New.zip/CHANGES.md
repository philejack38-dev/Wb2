# تغییرات نسخه ۲.۳ (اصلاحات UX عمیق)

## 🐛 مشکلات UX که فیکس شد

### ۱. نصب یک‌کلیکی بدون کنترل کاربر (مشکل اصلی)
**قبلاً:** کاربر در catalog/discover/home روی «📥 نصب و ترجمه» کلیک می‌کرد و سرور خودکار ۳ فصل اول رو دانلود + ترجمه می‌کرد. هیچ کنترلی روی تعداد یا محدوده نداشت.

**حالا:** یک **modal کامل** با این گزینه‌ها:
- **محدوده دانلود**: از فصل X تا فصل Y (یا «همه فصل‌ها»)
- **شمارش زنده**: «۱۰ فصل دانلود می‌شه» (با تغییر اعداد به‌روز می‌شه)
- **ترجمه خودکار**: checkbox (default: روشن)
- **محدوده ترجمه جداگانه** (اگه کاربر بخواد ترجمه فقط بخش خاصی رو شامل بشه):
  - «ترجمه همون فصل‌هایی که دانلود شد» (default)
  - «ترجمه محدوده دیگه» (با فیلد از/تا جداگانه)
- **هشدار زمان ترجمه**: «هر فصل حدود ۲-۵ ثانیه ترجمه طول می‌کشه»

### ۲. admin.html فاقد محدوده فصل
**قبلاً:** فقط یک فیلد «تعداد فصل اولیه» داشت (default=3، max=100)

**حالا:**
- دو فیلد «از فصل» و «تا فصل» (با placeholder «خالی = تا آخر»)
- شمارش زنده تعداد فصل‌هایی که دانلود می‌شن
- validation: اگه «تا» کوچکتر از «از» باشه، خطا می‌ده
- راهنمای به‌روزشده با توضیح محدوده

### ۳. عدم امکان دانلود فصل‌های بیشتر در صفحه جزئیات
**قبلاً:** کاربر فقط ۳ فصل اول رو می‌گرفت و گیر می‌کرد — هیچ راهی برای دانلود فصل‌های بیشتر نبود.

**حالا:** دکمه «📥 دانلود فصل‌های بیشتر» در صفحه detail:
- modal با محدوده فصل (default: از فصل بعد از آخرین فصل موجود)
- checkbox ترجمه خودکار
- progress live با SSE
- بعد از اتمام، خودکار صفحه refresh می‌شه

### ۴. عدم امکان ترجمه محدوده خاص
**قبلاً:** فقط «ترجمه همه فصل‌های ترجمه‌نشده» وجود داشت. کاربر نمی‌تونست مثلاً فقط فصل ۵ تا ۱۰ رو ترجمه کنه.

**حالا:** دکمه «🎯 ترجمه محدوده خاص» در صفحه detail:
- modal با فیلدهای «از فصل» و «تا فصل» (با max برابر تعداد فصل‌های موجود)
- هشدار: «این کار فصل‌های داخل محدوده رو (حتی اگه قبلاً ترجمه شدن) دوباره ترجمه می‌کنه»

## 🔧 تغییرات Backend

### API های جدید/بهبودیافته

#### `POST /api/add`
پارامترهای جدید:
- `startChapter` (number, 1-indexed, default: 1)
- `endChapter` (number, optional — null = تا آخر)
- `translateStart` (number, optional — برای محدوده ترجمه جداگانه)
- `translateEnd` (number, optional)

`limit` همچنان موجود ولی حالا از `startChapter` و `endChapter` محاسبه می‌شه.

#### `POST /api/add-more` (جدید)
برای افزودن فصل‌های بیشتر به رمان موجود:
- `novelId` (required)
- `startChapter` (default: chapterCount + 1)
- `endChapter` (optional)
- `autoTranslate` (boolean)

سرور خودکار sourceUrl رمان رو از DB می‌خونه.

#### `POST /api/translate/novel/:id`
پارامترهای جدید:
- `mode: 'range'` — حالت جدید برای ترجمه محدوده
- `start` (number, 1-indexed)
- `end` (number, inclusive)

### queue.js — runScrape بازنویسی شد
- تشخیص خودکار اگه رمان قبلاً وجود داره (با sourceUrl) → از `scrapeNovelRange` استفاده می‌کنه
- اگه رمان جدیده → از `scrapeNovel` با `{startChapter, endChapter}` استفاده می‌کنه
- اگر `translateRange` مشخص شده باشه، از mode='range' برای ترجمه استفاده می‌کنه

### queue.js — runTranslateNovel بازنویسی شد
- mode='range' اضافه شد — فصل‌ها رو بر اساس start/end فیلتر می‌کنه
- mode='all' — همه فصل‌ها (حتی ترجمه‌شده)
- mode='pending' — فقط ترجمه‌نشده‌ها (default)

### scraper.js
- `scrapeNovel(url, limit, onProgress, opts)` — پارامتر opts اضافه شد
  - `opts.startChapter` — فیلتر فصل‌ها از این شماره
  - `opts.endChapter` — فیلتر فصل‌ها تا این شماره
- `scrapeNovelRange(url, startChapter, endChapter, onProgress, existingNovel)` (جدید) — برای دانلود فصل‌های بیشتر روی رمان موجود

## 🎨 تغییرات Frontend

### توابع جدید در app.js

#### `openAddNovelModal(novelInfo)`
یک modal کامل با:
- نمایش اطلاعات رمان (عنوان، نویسنده، توضیحات، منبع)
- بخش دانلود با گزینه «همه فصل‌ها» / «محدوده خاص»
- بخش ترجمه با checkbox و گزینه‌های محدوده
- validation و شمارش زنده
- بازگشت Promise با opts یا null (اگه کاربر انصراف بزنه)

#### `addNovelWithModal(novelInfo)`
wrapper که modal رو باز می‌کنه و سپس `POST /api/add` رو صال می‌کنه.

### به‌روزرسانی توابع موجود

#### `initDiscover`
- دکمه «📥 نصب و ترجمهٔ سریع» → «📥 افزودن به کتابخونه»
- به جای `api.add(url, 3, true)`، از `addNovelWithModal` استفاده می‌کنه
- اطلاعات رمان (title, author, desc, cover, site) رو به modal پاس می‌ده

#### `initCatalog`
- دکمه «📥 نصب و ترجمه» → «📥 افزودن به کتابخونه»
- به جای `api.add(u, 3, true)` و confirm، از `addNovelWithModal` استفاده می‌کنه

#### `initHome`
- recommended cards: به جای confirm + `api.add(url, 3, true)`، از `addNovelWithModal` استفاده می‌کنه

#### `initAdmin`
- فیلدهای جدید: `startChapter` و `endChapter` (به جای `limit`)
- شمارش زنده تعداد فصل‌های دانلودی
- validation محدوده
- راهنمای به‌روزشده

#### `initDetail` (صفحه جزئیات رمان)
- دکمه جدید: «🎯 ترجمه محدوده خاص»
  - modal با فیلدهای از/تا (max = تعداد فصل‌های موجود)
  - صدا زدن `/api/translate/novel/:id` با `mode: 'range', start, end`
- دکمه جدید: «📥 دانلود فصل‌های بیشتر»
  - modal با فیلدهای از/تا (default: از فصل بعد از آخرین فصل موجود)
  - checkbox ترجمه خودکار
  - صدا زدن `/api/add-more` با novelId و محدوده
  - progress live با SSE
  - refresh خودکار صفحه بعد از اتمام

## 📋 فایل‌های تغییر یافته

- `lib/queue.js` — بازنویسی runScrape و runTranslateNovel با پشتیبانی از range
- `lib/scraper.js` — افزودن scrapeNovelRange + opts در scrapeNovel
- `server.js` — بهبود /api/add + افزودن /api/add-more + پشتیبانی از range در /api/translate/novel/:id
- `public/app.js` — توابع جدید (openAddNovelModal, addNovelWithModal) + به‌روزرسانی همه init functions + دکمه‌های جدید در detail
- `public/admin.html` — فیلدهای startChapter/endChapter + راهنمای به‌روزشده

## 🎯 تجربه کاربری بهتر

### قبل
1. کاربر روی «نصب و ترجمهٔ سریع» کلیک می‌کرد
2. سرور ۳ فصل اول رو دانلود + ترجمه می‌کرد (بدون سوال)
3. کاربر کنترلی روی تعداد/محدوده نداشت
4. اگه فصل‌های بیشتر می‌خواست، راهی نبود
5. اگه محدوده خاصی رو می‌خواست ترجمه کنه، راهی نبود

### بعد
1. کاربر روی «افزودن به کتابخونه» کلیک می‌کنه
2. modal باز می‌شه با:
   - اطلاعات رمان (عنوان، نویسنده، توضیحات)
   - انتخاب محدوده دانلود (از فصل X تا Y یا همه)
   - انتخاب ترجمه خودکار (با محدوده جداگانه اختیاری)
3. کاربر تأیید می‌کنه → دانلود شروع می‌شه
4. بعداً از صفحه جزئیات می‌تونه «دانلود فصل‌های بیشتر» بزنه
5. می‌تونه «ترجمه محدوده خاص» بزنه (مثلاً فقط فصل ۵ تا ۱۰)

## 🚀 راه‌اندازی

```bash
npm install
node server.js
```
