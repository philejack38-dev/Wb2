const translator = require('./lib/translator');
translator.translate('沧州以北，落凤城风家。', 'Persian', 'agnes-2.0-flash', { novelId: 'nmrt6meqphki1n' })
  .then(t => { console.log('RESULT len:', (t||'').length, '|', (t||'').slice(0,200)); process.exit(0); })
  .catch(e => { console.log('ERR:', e.message); process.exit(1); });
