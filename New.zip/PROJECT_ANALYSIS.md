# پروژه Novel Reader v2 — تحلیل کامل و گزارش خطاها

## ✅ چیزهایی که درست کار می‌کنند

| بخش | وضعیت | توضیحات |
|------|-------|----------|
| **ساختار کلی پروژه** | ✅ عالی | معماری ماژولار، تمیز، با جداسازی خوب (server, lib/, public/) |
| **دیتابیس (SQLite + FTS5)** | ✅ عالی | با fallback به JSON، atomic write، migration خودکار |
| **صف کارها (Job Queue) + SSE** | ✅ عالی | Concurrency control، پیشرفت زنده، retry logic |
| **موتور اسکرپر چندسایتی** | ✅ عالی | ۸ پلاگین (piaotia, webnovel, wuxiaworld, novelfull, lightnovelworld, royalroad, scribblehub, mangadex) + generic fallback |
| **موتور ترجمه چند‌ارائه‌دهنده** | ✅ عالی | ۸ provider، chunking هوشمند، Translation Memory، Glossary auto-extraction، Style guide |
| **رابط کاربری (Frontend)** | ✅ عالی | ۱۸ صفحه HTML، app.js ماژولار ۲۵۰۰+ خط، PWA، Keyboard shortcuts، TTS، Tap zones، Swipe، Pinch zoom |
| **Export (EPUB/Markdown/PDF)** | ✅ کار می‌کند | ZIP دستی برای EPUB، بدون وابستگی خارجی |
| **جستجوی Full-text (FTS5)** | ✅ عالی | Snippet highlighting |
| **Gamification (Achievements/Goals)** | ✅ کامل | ۱۲ دستاورد، اهداف قابل تنظیم |
| **Wiki خودکار شخصیت‌ها** | ✅ کامل | استخراج با LLM |
| **آمار خواندن + نمودار** | ✅ کامل | Streak، Sessions، نمودار SVG روزانه |
| **تست‌های واحد** | ✅ عبور | ۵ تست scraper پاس می‌شوند |

---

## ❌ مشکلات بحرانی (جلوگیر کارکرد_backend)

### ۱. **پروکسی اجباری اما غیرفعال** — **مهم‌ترین باگ**
```json
// config.json خط ۴۹۶
"proxy": "socks5://127.0.0.1:40629"
```
- **مشکل**: همه درخواست‌های خارجی (اسکرپ سایت‌ها + فراخوانی API ترجمه) از این پروکسی می‌گذرند
- **علامت**: `connect ECONNREFUSED 127.0.0.1:40629`
- **تأثیر**: **اسکرپ کار نمی‌کند، ترجمه کار نمی‌کند** — فقط UI لود می‌شود
- **راه‌حل**: یا پروکسی SOCKS5 روی پورت ۴۰۶۲۹ راه‌اندازی شود، یا این تنظیم غیرفعال شود

### ۲. **عدم قابلیت غیرفعال‌سازی پروکسی از UI**
- در `settings.html` و `app.js` هیچ کنترلی برای تغییر/غیرفعال‌سازی proxy وجود ندارد
- کاربر باید به صورت دستی `config.json` را ویرایش کند

### ۳. **API Keyهای هاردکد شده (ممکن است نامعتبر/اشتراکی باشند)**
```json
"opencode": {
  "apiKey": "sk-zGwsJ33FoJZ7J0UsTGKGoRgSrKPNwKTCvlzr3jlz531VHfJKg23jgcmE7xCxmSfm"
},
"agnes": {
  "apiKey": "sk-jEW11RGjEQUbCfUAbVVhZX7agYUDcQAw3o0kfWqiGJdFQ3vO"
}
```
- این کلیدها در repo عمومی قرار دارند → امنیت پایین
- ممکن است rate-limited یا revoked شده باشند
- کاربر جدید نمی‌تواند از این‌ها استفاده کند

### ۴. **Allow-list دامنه بسیار محدودکننده**
- ۲۰۰+ دامنه در `config.json` → سایت‌های جدید بلاک می‌شوند
- پیغام خطا: `domain not allowed: example.com (add to scraper.allowedDomains)`
- باید دستی به config اضافه شود

---

## ⚠️ مشکلات متوسط

| مشکل | فایل | توضیح |
|--------|------|-------|
| **Webnovel scraper** | `lib/scraper.js` | وابسته به `__NEXT_DATA__` JSON که ممکن است تغییر کند |
| **NovelUpdates scraper** | `lib/scraper.js` | سایت aggregator است، لینک‌های فصل نیاز به JS دارد |
| **Generic adapter** | `lib/scraper.js` | Readability گاهی محتوای ناخواسته برمی‌گرداند |
| **PDF export** | `lib/pdf.js` | Fallback ساده، کیفیت پایین |
| **Rate limiting** | `lib/rateLimit.js` | In-memory، در clustered env کار نمی‌کند |
| **Auth token secret** | `config.json` | پیش‌فرض `rotate-this-secret` — باید تغییر کند |

---

## 🔧 راه‌حل‌های پیشنهادی (اولویت‌بندی شده)

### اولویت ۱: فوری (برای کارکرد backend)

**گزینه A: غیرفعال کردن پروکسی (سریع‌ترین)**
```bash
# در config.json
"proxy": ""
```

**گزینه B: راه‌اندازی پروکسی SOCKS5 (اگر برای دور زدن فیلتر لازم است)**
```bash
# مثلاً با ssh tunnel
ssh -D 40629 user@your-server
# یا shadowsocks/v2ray با پورت 40629
```

**گزینه C: اضافه کردن تنظیم proxy به UI** (پیشنهاد من)
- در `settings.html` فیلد proxy اضافه شود
- در `app.js` API برای ذخیره/خواندن proxy
- در `server.js` و `lib/scraper.js` و `lib/translator.js` از تنظیم دیتابیس خوانده شود

### اولویت ۲: امنیت و انعطاف‌پذیری

1. **API Keyها را از config.json حذف کنید** — در UI تنظیمات مترجم وارد شوند
2. **Allow-list را قابل تنظیم کنید** — در UI یا فایل جداگانه
3. **Auth secret را rotate کنید** — رشته تصادفی ۳۲+ کاراکتر

### اولویت ۳: بهبود Scraperها

1. **Webnovel**: به‌روزرسانی selectorهای جدید
2. **NovelUpdates**: استفاده از API رسمی یا RSS
3. **Generic**: بهبود heuristicهای استخراج محتوا

---

## 📋 چک‌لیست تست دستی (برای کاربر)

```bash
# 1. نصب وابستگی‌ها
npm install

# 2. غیرفعال کردن proxy (موقت برای تست)
# ویرایش config.json: "proxy": ""

# 3. اجرای سرور
node server.js
# باید ببیند: "Translator provider: agnes — ✓ configured"

# 4. تست اسکرپ (در ترمینال جداگانه)
node -e "
const s = require('./lib/scraper');
s.scrapeNovel('https://www.novelfull.com/book/TEST_BOOK.html', 1, console.log)
  .then(r => console.log('OK:', r.meta.title, r.chapters.length))
  .catch(e => console.error('ERR:', e.message));
"

# 5. تست ترجمه
node -e "
const t = require('./lib/translator');
t.translateChunk('Hello world', { provider: 'opencode' })
  .then(r => console.log('Translated:', r.text))
  .catch(e => console.error('ERR:', e.message));
"

# 6. تست UI
# باز کردن http://localhost:8080 در مرورگر
# → /admin برای اضافه کردن رمان
# → /library برای دیدن کتابخانه
# → /reader برای خواندن
```

---

## 📁 فایل‌های کلیدی برای 수정

| فایل | تغییر پیشنهادی |
|------|----------------|
| `config.json` | `proxy: ""`، حذف API keyها، allow-list قابل گسترش |
| `public/settings.html` | اضافه کردن فیلد Proxy + API Key providerها |
| `public/app.js` | API calls برای ذخیره/خواندن proxy و API keys |
| `lib/scraper.js` | خواندن proxy از دیتابیس به جای config.json |
| `lib/translator.js` | خواندن proxy و API keys از دیتابیس |
| `lib/db.js` | اضافه کردن settings برای proxy و apiKeys |
| `server.js` | پاس‌دادن تنظیمات proxy به scraper/translator |

---

## 🎯 نتیجه‌گیری

**پروژه از نظر معماری و امکانات بسیار کامل و حرفه‌ای است (Surface Level 5).**
اما **پروکسی اجباری و غیرفعال بودن آن** باعث شده تمام قابلیت‌های backend (اسکرپ، ترجمه، چک آپدیت، découvر آنلاین) کار نکنند.

**راه‌حل سریع**: در `config.json` خط ۴۹۶ را به `"proxy": ""` تغییر دهید.
**راه‌حل اصولی**: اضافه کردن مدیریت proxy و API keys در UI تنظیمات.

> نکته: پروژه در GitHub public است — API keyهای واقعی در config.json نباید commit شوند.