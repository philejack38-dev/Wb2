/* ==================================================================
   Novel Reader v2 — frontend app
   Modules: api, ui, sse, library, detail, reader, admin, search,
            stats, settings, login
   ================================================================== */
(function () {
  'use strict';

  /* ---------- Utilities ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => (s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const qs = () => Object.fromEntries(new URLSearchParams(location.search));

  function toast(msg, kind = '') {
    let t = $('#toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg;
    t.className = 'toast show ' + kind;
    clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2800);
  }

  function setGlobalProgress(pct) {
    const el = $('#globalProgress');
    if (!el) return;
    if (pct == null) { el.classList.add('hide'); el.querySelector('i').style.width = '0%'; return; }
    el.classList.remove('hide');
    el.querySelector('i').style.width = pct + '%';
  }

  function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    localStorage.setItem('nr:theme', t);
    const btn = $('#themeBtn');
    if (btn) {
      btn.textContent = t === 'dark' ? '🌙' : (t === 'light' ? '☀' : (t === 'sepia' ? '📜' : '🌌'));
    }
    const meta = $('meta[name=theme-color]');
    if (meta) {
      meta.content = t === 'dark' ? '#0d0f14' : (t === 'light' ? '#f5f6fa' : (t === 'sepia' ? '#f4ecd8' : '#000000'));
    }
  }
  function getTheme() { return localStorage.getItem('nr:theme') || 'dark'; }

  /* ---------- API ---------- */
  const api = {
    fetch: (url, opts) => fetch(url, opts),
    novels: () => fetch('/api/novels').then(r => r.json()),
    novel: (id, withChapters = true) =>
      fetch('/api/novel/' + id + (withChapters ? '' : '?chapters=0')).then(r => r.json()),
    chapter: id => fetch('/api/chapter/' + id + '?t=' + Date.now()).then(r => r.json()),
    chapterByIndex: (novelId, idx) =>
      fetch(`/api/chapter?novel=${novelId}&idx=${idx}`).then(r => r.json()),
    add: (url, limit, autoTranslate = false) => fetch('/api/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, limit, autoTranslate })
    }).then(r => r.json()),
    translateChapter: id => fetch('/api/translate/chapter/' + id, { method: 'POST' }).then(r => r.json()),
    translateNovel: (id, mode = 'pending') => fetch('/api/translate/novel/' + id, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode })
    }).then(r => r.json()),
    deleteNovel: id => fetch('/api/novel/' + id, { method: 'DELETE' }).then(r => r.json()),
    jobs: () => fetch('/api/jobs').then(r => r.json()),
    job: id => fetch('/api/job/' + id).then(r => r.json()),
    cancelJob: id => fetch('/api/job/' + id, { method: 'DELETE' }).then(r => r.json()),
    stats: () => fetch('/api/stats').then(r => r.json()),
    settings: () => fetch('/api/settings').then(r => r.json()),
    setSettings: (patch) => fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch)
    }).then(r => r.json()),
    search: q => fetch('/api/search?q=' + encodeURIComponent(q)).then(r => r.json()),
    bookmarks: () => fetch('/api/bookmarks').then(r => r.json()),
    bookmark: (novelId, idx) => fetch('/api/bookmark', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ novelId, chapterIndex: idx })
    }).then(r => r.json()),
    glossary: (novelId) => fetch('/api/glossary' + (novelId ? '?novel=' + novelId : '')).then(r => r.json()),
    extractGlossary: (novelId) => fetch('/api/glossary/extract', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ novelId })
    }).then(r => r.json()),
    authCheck: () => fetch('/api/auth/check').then(r => r.json()),
    login: (u, p) => fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: u, password: p })
    }).then(r => r.json()),
    logout: () => fetch('/api/logout', { method: 'POST' }).then(r => r.json())
  };

  /* ---------- SSE manager ---------- */
  const sse = {
    es: null,
    handlers: new Map(),
    ensure() {
      if (this.es) return;
      try {
        this.es = new EventSource('/api/events');
        this.es.addEventListener('job:start', e => this.dispatch('job:start', JSON.parse(e.data)));
        this.es.addEventListener('job:progress', e => this.dispatch('job:progress', JSON.parse(e.data)));
        this.es.addEventListener('job:done', e => this.dispatch('job:done', JSON.parse(e.data)));
        this.es.addEventListener('job:failed', e => this.dispatch('job:failed', JSON.parse(e.data)));
        this.es.onerror = () => {
          // try reconnect after delay
          this.es.close(); this.es = null;
          setTimeout(() => this.ensure(), 3000);
        };
      } catch (e) { console.warn('SSE unavailable', e); }
    },
    on(event, fn) {
      if (!this.handlers.has(event)) this.handlers.set(event, new Set());
      this.handlers.get(event).add(fn);
      this.ensure();
      return () => this.handlers.get(event).delete(fn);
    },
    dispatch(event, data) {
      const hs = this.handlers.get(event);
      if (hs) for (const h of hs) try { h(data); } catch (e) { console.error(e); }
    }
  };

  /* ---------- UI helpers ---------- */
  function coverHtml(url) {
    if (url) {
      // route through /api/img to avoid CORS / referer issues
      return `<img class="cover" src="/api/img?src=${encodeURIComponent(url)}" alt="" loading="lazy" onerror="this.outerHTML='<div class=&quot;cover placeholder&quot;>📖</div>'">`;
    }
    return '<div class="cover placeholder">📖</div>';
  }
  const statusText = s => ({
    translated: 'ترجمه شد', pending: 'در انتظار', scraped: 'استخراج شد',
    translating: 'در حال ترجمه', failed: 'خطا'
  }[s] || s);

  /* ==================================================================
     Library page
     ================================================================== */
  function initLibrary() {
    applyTheme(getTheme());
    sse.ensure();

    let allNovels = [];
    let bookmarks = [];
    async function load() {
      try {
        const [novels, bms] = await Promise.all([
          api.novels(),
          api.bookmarks().catch(() => [])
        ]);
        allNovels = novels;
        bookmarks = bms;
        populateSiteFilter();
        render();
      } catch (e) {
        $('#list').innerHTML = '<p class="empty"><span class="icon">⚠</span>خطا در بارگذاری</p>';
      }
    }

    function populateSiteFilter() {
      const sites = [...new Set(allNovels.map(n => n.sourceSite).filter(Boolean))];
      const sel = $('#filterSite');
      if (!sel) return;
      const cur = sel.value;
      sel.innerHTML = '<option value="">همه</option>' +
        sites.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('');
      sel.value = cur;
    }

    function applyFilters(list) {
      const q = ($('#search')?.value || '').trim().toLowerCase();
      const site = $('#filterSite')?.value || '';
      const status = $('#filterStatus')?.value || '';
      const minCh = parseInt($('#filterMinChapters')?.value || '0') || 0;
      const progress = $('#filterProgress')?.value || '';

      return list.filter(n => {
        if (q) {
          const t = (n.title || '').toLowerCase();
          const a = (n.author || '').toLowerCase();
          if (!t.includes(q) && !a.includes(q)) return false;
        }
        if (site && n.sourceSite !== site) return false;
        if (status === 'ongoing' && n.status === 'completed') return false;
        if (status === 'completed' && n.status !== 'completed') return false;
        if (minCh > 0 && (n.chapterCount || 0) < minCh) return false;
        if (progress) {
          const pct = n.chapterCount ? Math.round((n.translatedCount / n.chapterCount) * 100) : 0;
          if (progress === '0' && pct > 0) return false;
          if (progress === 'partial' && (pct === 0 || pct === 100)) return false;
          if (progress === '100' && pct < 100) return false;
        }
        return true;
      });
    }

    function render() {
      const el = $('#list');
      const countEl = $('#resultCount');
      if (!allNovels.length) {
        el.innerHTML = `
          <div class="empty" style="text-align:center;grid-column:1/-1;padding:3rem 1rem">
            <span class="icon" style="font-size:3rem;display:block;margin-bottom:1rem">📚</span>
            <p style="margin:0 0 1.2rem;font-size:1.05rem;color:var(--fg-soft)">کتابخانه شما خالی است! رمان‌های جذاب جدید را پیدا کنید:</p>
            <div style="display:flex;justify-content:center;gap:1rem;flex-wrap:wrap">
              <a href="/discover" class="btn primary">🧭 رفتن به بخش کشف آنلاین رمان</a>
              <a href="/catalog" class="btn ghost">🗂️ کاتالوگ چندسایتی</a>
              <a href="/admin" class="btn ghost">+ افزودن دستی با لینک</a>
            </div>
          </div>
        `;
        if (countEl) countEl.textContent = '';
        return;
      }
      const sort = $('#sortBy')?.value || 'newest';
      let list = applyFilters([...allNovels]);

      if (sort === 'title') list.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'fa'));
      else if (sort === 'progress') list.sort((a, b) => (b.translatedCount || 0) / (b.chapterCount || 1) - (a.translatedCount || 0) / (a.chapterCount || 1));
      else if (sort === 'chapters') list.sort((a, b) => (b.chapterCount || 0) - (a.chapterCount || 0));
      else if (sort === 'recent') {
        // Sort by last bookmark timestamp (most recently read)
        const bm = new Map(bookmarks.map(b => [b.novelId, b]));
        list.sort((a, b) => {
          const ta = bm.get(a.id)?.updatedAt || a.createdAt || 0;
          const tb = bm.get(b.id)?.updatedAt || b.createdAt || 0;
          return new Date(tb) - new Date(ta);
        });
      } else list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      if (countEl) countEl.textContent = `${list.length.toLocaleString('fa-IR')} از ${allNovels.length.toLocaleString('fa-IR')} رمان`;

      if (!list.length) {
        el.innerHTML = '<p class="empty" style="grid-column:1/-1"><span class="icon">🔍</span>رمانی با این فیلترها پیدا نشد.</p>';
        return;
      }

      el.innerHTML = list.map(n => {
        const pct = n.chapterCount ? Math.round((n.translatedCount / n.chapterCount) * 100) : 0;
        const statusBadge = n.status === 'completed'
          ? '<span class="badge" style="background:var(--accent-2-soft);color:var(--accent-2)">✓ تمام‌شده</span>'
          : '';
        return `
        <a class="card" href="/detail?id=${n.id}">
          ${coverHtml(n.coverUrl)}
          <span class="site-tag">${esc(n.sourceSite || 'generic')}</span>
          <h3>${esc(n.title)}</h3>
          <span class="author">${esc(n.author || 'ناشناس')}</span>
          <div class="meta">
            <span class="badge">${(n.chapterCount || 0).toLocaleString('fa-IR')} فصل</span>
            <span class="badge">${pct.toLocaleString('fa-IR')}٪</span>
          </div>
          ${statusBadge ? `<div style="margin-top:.3rem">${statusBadge}</div>` : ''}
          <div class="progress-ring"><i style="width:${pct}%"></i></div>
        </a>`;
      }).join('');
    }

    $('#search').oninput = render;
    $('#sortBy').onchange = render;
    $('#filterSite').onchange = render;
    $('#filterStatus').onchange = render;
    $('#filterMinChapters').oninput = render;
    $('#filterProgress').onchange = render;
    $('#toggleFilters').onclick = () => {
      $('#filterBar').classList.toggle('hide');
    };
    $('#clearFilters').onclick = () => {
      $('#filterSite').value = '';
      $('#filterStatus').value = '';
      $('#filterMinChapters').value = '0';
      $('#filterProgress').value = '';
      $('#search').value = '';
      render();
    };

    // SSE live updates
    sse.on('job:done', (d) => {
      if (d.type === 'scrape' || d.type === 'translate_novel') load();
    });

    load();
  }

  /* ==================================================================
     Detail page
     ================================================================== */
  async function initDetail() {
    applyTheme(getTheme());
    sse.ensure();
    const { id } = qs();
    if (!id) { $('#detail').innerHTML = '<p class="empty">شناسه رمان مشخص نیست.</p>'; return; }

    async function load() {
      const novel = await api.novel(id);
      if (!novel || novel.error) {
        $('#detail').innerHTML = '<p class="empty">رمان یافت نشد.</p>';
        return;
      }
      $('#detail-title').textContent = novel.title;
      document.title = novel.title + ' — کتابخونه';

      const translatedCount = (novel.chapters || []).filter(c => c.status === 'translated').length;
      const pct = novel.chapters?.length ? Math.round(translatedCount / novel.chapters.length * 100) : 0;
      const tags = await api.fetch(`/api/novel/${id}/tags`).then(r => r.json()).catch(() => []);
      const recs = await api.fetch(`/api/recommend/${id}/novel`).then(r => r.json()).catch(() => []);
      const updateStatus = await api.fetch(`/api/updates/${id}/status`).then(r => r.json()).catch(() => ({}));

      $('#detail').innerHTML = `
        <div class="novel-head">
          ${coverHtml(novel.coverUrl)}
          <div class="info">
            <h2>${esc(novel.title)}</h2>
            <p>نویسنده: ${esc(novel.author || 'ناشناس')}</p>
            <p>منبع: <span class="badge">${esc(novel.sourceSite || 'generic')}</span>
               ${updateStatus.status === 'has_updates' ? `<span class="badge" style="background:var(--accent-2-soft);color:var(--accent-2)">${updateStatus.new_chapters_count} فصل جدید 🆕</span>` : ''}
            </p>
            ${novel.description ? `<p class="desc">${esc(novel.description)}</p>` : ''}
            ${tags.length ? `<p><strong>تگ‌ها:</strong> ${tags.map(t => `<span class="badge" style="background:${t.color}33;color:${t.color}">${esc(t.name)}</span>`).join(' ')}</p>` : ''}
            <div class="stats-row">
              <span class="stat-pill"><span class="num">${novel.chapters?.length || 0}</span><span class="lbl">فصل</span></span>
              <span class="stat-pill"><span class="num">${translatedCount}</span><span class="lbl">ترجمه‌شده</span></span>
              <span class="stat-pill"><span class="num">${pct}%</span><span class="lbl">پیشرفت</span></span>
            </div>
            <div class="actions">
              <button class="btn primary" id="translateAll">🌐 ترجمه همه فصل‌های ترجمه‌نشده</button>
              <button class="btn ghost" id="translateRange">🎯 ترجمه محدوده خاص</button>
              <button class="btn ghost" id="downloadMore">📥 دانلود فصل‌های بیشتر</button>
              <a class="btn ghost" href="/api/epub/${novel.id}" download>📥 EPUB</a>
              <a class="btn ghost" href="/api/markdown/${novel.id}" download>📥 Markdown</a>
              <a class="btn ghost" href="/api/pdf/${novel.id}" download>📥 PDF</a>
              <button class="btn ghost small" id="extractGlossary">📚 glossary</button>
              <a class="btn ghost small" href="/wiki?novel=${novel.id}">📖 ویکی</a>
              <button class="btn ghost small" id="checkUpdates">🔄 بررسی آپدیت</button>
              <button class="btn ghost small" id="addQueue">📋 به صف</button>
              <button class="btn ghost small" id="addTagBtn">🏷 تگ</button>
              <button class="btn danger small" id="deleteNovel">حذف</button>
            </div>
          </div>
        </div>
        ${recs.length ? `
          <div class="settings-section" style="margin-bottom:1.5rem">
            <h3>📖 رمان‌های مشابه</h3>
            <div class="grid">
              ${recs.map(r => `
                <a class="card" href="/detail?id=${r.id}">
                  ${coverHtml(r.coverUrl)}
                  <h3>${esc(r.title)}</h3>
                  <span class="author">${esc(r.author || '')}</span>
                  <div class="muted" style="font-size:.75rem">${r.reasons.map(esc).join(' · ')}</div>
                </a>`).join('')}
            </div>
          </div>` : ''}
        <div class="chapter-list">
          ${(novel.chapters || []).map((c, i) => `
            <a class="chapter-row" href="/read?novel=${novel.id}&ch=${i}">
              <span class="num">#${c.chapterNumber}</span>
              <span class="title">${esc(c.title)}</span>
              <span class="status ${c.status}">${statusText(c.status)}</span>
            </a>`).join('')}
        </div>`;

      $('#translateAll').onclick = async () => {
        $('#translateAll').disabled = true;
        $('#translateAll').textContent = 'در حال ارسال…';
        const r = await api.translateNovel(novel.id, 'pending');
        toast(`Job شروع شد (ID: ${r.jobId})`, 'ok');
        setGlobalProgress(0);
      };
      $('#translateRange').onclick = async () => {
        // Open a small modal to ask for range
        const modal = document.createElement('div');
        modal.className = 'modal-backdrop';
        modal.style.zIndex = '200';
        const maxCh = novel.chapters?.length || 1;
        modal.innerHTML = `
          <div class="modal" style="max-width:420px">
            <h3 style="margin:0 0 1rem">🎯 ترجمه محدوده خاص</h3>
            <p class="muted" style="font-size:.85rem;margin:0 0 1rem">فصل‌های موجود: ${(maxCh).toLocaleString('fa-IR')}</p>
            <div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.8rem">
              <span class="muted" style="font-size:.85rem">از فصل:</span>
              <input type="number" id="trStart" min="1" max="${maxCh}" value="1" style="width:90px;padding:.5rem;border-radius:6px;border:1px solid var(--border);background:var(--bg-soft);color:var(--fg);font-family:inherit">
              <span class="muted" style="font-size:.85rem">تا فصل:</span>
              <input type="number" id="trEnd" min="1" max="${maxCh}" value="${Math.min(10, maxCh)}" style="width:90px;padding:.5rem;border-radius:6px;border:1px solid var(--border);background:var(--bg-soft);color:var(--fg);font-family:inherit">
            </div>
            <div class="muted" style="font-size:.78rem;margin-bottom:1rem">
              ⚠ این کار فصل‌های داخل محدوده رو (حتی اگه قبلاً ترجمه شدن) دوباره ترجمه می‌کنه.
            </div>
            <div style="display:flex;gap:.5rem;justify-content:flex-end">
              <button class="btn ghost" data-act="cancel">انصراف</button>
              <button class="btn primary" data-act="go">شروع ترجمه</button>
            </div>
          </div>
        `;
        document.body.appendChild(modal);
        modal.addEventListener('click', async (e) => {
          if (e.target === modal || e.target.dataset.act === 'cancel') { modal.remove(); return; }
          if (e.target.dataset.act === 'go') {
            const s = parseInt(modal.querySelector('#trStart').value) || 1;
            const e2 = parseInt(modal.querySelector('#trEnd').value) || s;
            if (e2 < s) { toast('محدوده نامعتبره', 'err'); return; }
            modal.remove();
            setGlobalProgress(0);
            toast(`در حال ترجمه فصل ${s.toLocaleString('fa-IR')} تا ${e2.toLocaleString('fa-IR')}…`);
            try {
              const r = await fetch('/api/translate/novel/' + novel.id, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode: 'range', start: s, end: e2 })
              }).then(r => r.json());
              if (r.jobId) {
                toast(`ترجمه شروع شد — ${(e2 - s + 1).toLocaleString('fa-IR')} فصل`, 'ok');
              }
            } catch (err) {
              toast('خطا: ' + err.message, 'err');
              setGlobalProgress(null);
            }
          }
        });
      };
      $('#downloadMore').onclick = async () => {
        // Open a modal to ask for range
        const modal = document.createElement('div');
        modal.className = 'modal-backdrop';
        modal.style.zIndex = '200';
        const currentCount = novel.chapters?.length || 0;
        const defaultStart = currentCount + 1;
        modal.innerHTML = `
          <div class="modal" style="max-width:480px">
            <h3 style="margin:0 0 1rem">📥 دانلود فصل‌های بیشتر</h3>
            <p class="muted" style="font-size:.85rem;margin:0 0 1rem">سایت: ${esc(novel.sourceSite || 'generic')} | فصل‌های فعلی: ${currentCount.toLocaleString('fa-IR')}</p>
            <div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.6rem;flex-wrap:wrap">
              <span class="muted" style="font-size:.85rem">از فصل:</span>
              <input type="number" id="dlStart" min="1" value="${defaultStart}" style="width:90px;padding:.5rem;border-radius:6px;border:1px solid var(--border);background:var(--bg-soft);color:var(--fg);font-family:inherit">
              <span class="muted" style="font-size:.85rem">تا فصل:</span>
              <input type="number" id="dlEnd" min="1" value="${defaultStart + 9}" placeholder="خالی = تا آخر" style="width:90px;padding:.5rem;border-radius:6px;border:1px solid var(--border);background:var(--bg-soft);color:var(--fg);font-family:inherit">
            </div>
            <div class="muted" style="font-size:.75rem;margin-bottom:.6rem">
              <span id="dlCount">${(10).toLocaleString('fa-IR')}</span> فصل دانلود می‌شه
            </div>
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;margin-bottom:1rem">
              <input type="checkbox" id="dlAutoTr" checked style="width:auto;margin:0">
              <span style="font-size:.85rem;color:var(--fg-soft)">🌐 ترجمه خودکار بعد از دانلود</span>
            </label>
            <div style="display:flex;gap:.5rem;justify-content:flex-end">
              <button class="btn ghost" data-act="cancel">انصراف</button>
              <button class="btn primary" data-act="go">📥 شروع دانلود</button>
            </div>
          </div>
        `;
        document.body.appendChild(modal);
        const dlStart = modal.querySelector('#dlStart');
        const dlEnd = modal.querySelector('#dlEnd');
        const dlCount = modal.querySelector('#dlCount');
        function updateCount() {
          const s = parseInt(dlStart.value) || 1;
          const eStr = dlEnd.value.trim();
          if (!eStr) dlCount.textContent = 'همه';
          else {
            const e = parseInt(eStr) || s;
            dlCount.textContent = Math.max(0, e - s + 1).toLocaleString('fa-IR');
          }
        }
        dlStart.oninput = updateCount;
        dlEnd.oninput = updateCount;
        modal.addEventListener('click', async (e) => {
          if (e.target === modal || e.target.dataset.act === 'cancel') { modal.remove(); return; }
          if (e.target.dataset.act === 'go') {
            const s = parseInt(dlStart.value) || 1;
            const eStr = dlEnd.value.trim();
            const e2 = eStr ? (parseInt(eStr) || s) : null;
            if (e2 && e2 < s) { toast('محدوده نامعتبره', 'err'); return; }
            const autoTr = modal.querySelector('#dlAutoTr').checked;
            modal.remove();
            setGlobalProgress(0);
            toast(`در حال دانلود فصل ${s.toLocaleString('fa-IR')} ${e2 ? 'تا ' + e2.toLocaleString('fa-IR') : 'تا آخر'}…`);
            try {
              const r = await fetch('/api/add-more', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  novelId: novel.id,
                  startChapter: s,
                  endChapter: e2 || undefined,
                  autoTranslate: autoTr
                })
              }).then(r => r.json());
              if (r.jobId) {
                toast(`دانلود شروع شد`, 'ok');
                sse.on('job:done', (d) => {
                  if (d.id === r.jobId && d.type === 'scrape') {
                    setGlobalProgress(null);
                    toast('✓ دانلود کامل شد', 'ok');
                    load();
                  }
                });
                sse.on('job:failed', (d) => {
                  if (d.id === r.jobId) {
                    setGlobalProgress(null);
                    toast('✗ خطا: ' + d.error, 'err');
                  }
                });
                sse.on('job:progress', (d) => {
                  if (d.id === r.jobId) {
                    setGlobalProgress(d.total ? (d.current / d.total * 100) : 0);
                  }
                });
              }
            } catch (err) {
              toast('خطا: ' + err.message, 'err');
              setGlobalProgress(null);
            }
          }
        });
      };
      $('#extractGlossary').onclick = async () => {
        const r = await api.extractGlossary(novel.id);
        toast(`استخراج glossary شروع شد (Job: ${r.jobId})`, 'ok');
      };
      $('#checkUpdates').onclick = async () => {
        const r = await api.fetch('/api/updates/check', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ novelId: novel.id })
        }).then(r => r.json());
        toast(`بررسی شروع شد`, 'ok');
      };
      $('#addQueue').onclick = async () => {
        await api.fetch('/api/queue', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ novelId: novel.id })
        });
        toast('به صف اضافه شد 📋', 'ok');
      };
      $('#addTagBtn').onclick = async () => {
        const t = prompt('تگ‌ها رو با کاما جدا کن (مثلاً: xianxia, favorite, ongoing):');
        if (!t) return;
        const tags = t.split(',').map(s => s.trim()).filter(Boolean);
        await api.fetch(`/api/novel/${novel.id}/tags`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tags })
        });
        toast('تگ‌ها ذخیره شدند 🏷', 'ok');
        load();
      };
      $('#deleteNovel').onclick = async () => {
        if (!confirm('این رمان حذف بشه؟ قابل بازگشت نیست.')) return;
        await api.deleteNovel(novel.id);
        location.href = '/';
      };

      // SSE: update chapter statuses live
      sse.on('job:progress', (d) => {
        if (d.type === 'translate_novel' || d.type === 'translate_chapter') {
          setGlobalProgress(d.total ? (d.current / d.total * 100) : 0);
          // update chapter row if it's translating
          if (d.chapterId) {
            const row = document.querySelector(`.chapter-row[href*="ch="]`);
            // simpler: just reload on completion
          }
        }
      });
      sse.on('job:done', (d) => {
        if (d.type === 'translate_novel' || d.type === 'translate_chapter') {
          setGlobalProgress(null);
          toast('ترجمه کامل شد ✅', 'ok');
          load();
        }
        if (d.type === 'extract_glossary') {
          toast(`glossary استخراج شد: ${d.result?.added || 0} اصطلاح`, 'ok');
        }
      });
      sse.on('job:failed', (d) => {
        if (d.type === 'translate_novel' || d.type === 'translate_chapter') {
          setGlobalProgress(null);
          toast('ترجمه ناموفق: ' + d.error, 'err');
          load();
        }
      });
    }

    load();
  }

  /* ==================================================================
     Reader page — mobile-first with tap zones, swipe, wake lock, sheet
     ================================================================== */
  async function initReader() {
    applyTheme(getTheme());
    // Night auto-switch: dark after 19:00 or before 6:00 (if no user pref)
    const hour = new Date().getHours();
    if (!localStorage.getItem('nr:theme')) {
      applyTheme((hour >= 19 || hour < 6) ? 'dark' : 'light');
    }
    sse.ensure();

    const { novel, ch } = qs();
    if (!novel) { $('#content').textContent = 'شناسه رمان مشخص نیست.'; return; }
    const novelId = novel;
    let chIndex = parseInt(ch || '0');
    let novelData = null;
    let currentSessionId = null;
    let sessionStartWords = 0;

    const storeKey = 'reader:' + novelId;
    const settings = await api.settings();
    let fontSize = parseInt(localStorage.getItem(storeKey + ':fs') || settings.ui?.fontSize || '18');
    let lineHeight = parseFloat(localStorage.getItem(storeKey + ':lh') || settings.ui?.lineHeight || '1.9');
    let fontFamily = localStorage.getItem(storeKey + ':ff') || settings.ui?.fontFamily || 'Vazirmatn';
    let view = localStorage.getItem(storeKey + ':view') || 'translated';
    let theme = getTheme();
    let brightness = parseInt(localStorage.getItem('reader:brightness') || '100');
    let immersive = localStorage.getItem(storeKey + ':immersive') === '1';
    let wakeLockActive = localStorage.getItem('reader:wakelock') === '1';
    let tapZonesActive = true; // default on for mobile

    /* Detect mobile */
    const isMobile = () => window.matchMedia('(max-width: 768px)').matches;
    const isTouch = () => 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    /* ---------- Reading session timer ---------- */
    let sessionTimer = 0;
    let timerInterval = null;
    function startTimer() {
      stopTimer();
      sessionTimer = 0;
      timerInterval = setInterval(() => {
        sessionTimer++;
        const m = Math.floor(sessionTimer / 60);
        const s = sessionTimer % 60;
        const el = $('#readingTimer');
        if (el) el.textContent = `${m.toLocaleString('fa-IR')}:${String(s).padStart(2,'0').toLocaleString('fa-IR')}`;
      }, 1000);
    }
    function stopTimer() {
      if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    }
    async function startSession() {
      const ch = novelData?.chapters?.[chIndex];
      if (!ch) return;
      try {
        const r = await api.fetch('/api/reading/session', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'start', novelId, chapterId: ch.id, chapterIndex: chIndex })
        }).then(r => r.json());
        currentSessionId = r.sessionId;
        sessionStartWords = (ch.translatedText || ch.originalText || '').length;
        startTimer();
      } catch {}
    }
    async function endSession() {
      if (!currentSessionId) return;
      stopTimer();
      const ch = novelData?.chapters?.[chIndex];
      const wordsRead = ch ? Math.max(0, (ch.translatedText || ch.originalText || '').length - sessionStartWords + 100) : 0;
      try {
        await api.fetch('/api/reading/session', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'end', sessionId: currentSessionId, wordsRead })
        });
      } catch {}
      currentSessionId = null;
    }

    /* ---------- Auto-scroll ---------- */
    let autoScrollInterval = null;
    let autoScrollSpeed = parseInt(localStorage.getItem('reader:autoScrollSpeed') || '1');
    function startAutoScroll() {
      if (autoScrollInterval) { stopAutoScroll(); return; }
      autoScrollInterval = setInterval(() => {
        window.scrollBy(0, autoScrollSpeed);
        if (window.scrollY + window.innerHeight >= document.body.scrollHeight - 5) {
          stopAutoScroll();
          toast('پایان فصل رسید', 'ok');
        }
      }, 40);
      $('#autoScrollBtn').querySelector('.icon').textContent = '⏸';
      toast(`اسکرول خودکار شروع شد (سرعت ${autoScrollSpeed})`, 'ok');
    }
    function stopAutoScroll() {
      if (autoScrollInterval) { clearInterval(autoScrollInterval); autoScrollInterval = null; }
      const b = $('#autoScrollBtn'); if (b) b.querySelector('.icon').textContent = '⏬';
    }
    // Long-press to cycle speed
    let autoScrollPressTimer = null;
    $('#autoScrollBtn').addEventListener('mousedown', () => {
      autoScrollPressTimer = setTimeout(() => {
        const speeds = [1, 2, 3, 5, 8];
        const idx = speeds.indexOf(autoScrollSpeed);
        autoScrollSpeed = speeds[(idx + 1) % speeds.length];
        localStorage.setItem('reader:autoScrollSpeed', String(autoScrollSpeed));
        toast(`سرعت اسکرول: ${autoScrollSpeed} پیکسل/تیک`, 'ok');
        if (autoScrollInterval) { stopAutoScroll(); startAutoScroll(); }
        autoScrollPressTimer = null;
      }, 600);
    });
    $('#autoScrollBtn').addEventListener('mouseup', () => { if (autoScrollPressTimer) { clearTimeout(autoScrollPressTimer); autoScrollPressTimer = null; } });
    $('#autoScrollBtn').addEventListener('mouseleave', () => { if (autoScrollPressTimer) { clearTimeout(autoScrollPressTimer); autoScrollPressTimer = null; } });

    /* ---------- Wake Lock — keep screen on while reading ---------- */
    let wakeLock = null;
    async function requestWakeLock() {
      try {
        if ('wakeLock' in navigator) {
          wakeLock = await navigator.wakeLock.request('screen');
          wakeLockActive = true;
          localStorage.setItem('reader:wakelock', '1');
          toast('صفحه روشن می‌مونه 👁', 'ok');
          // Re-acquire on visibility change
          document.addEventListener('visibilitychange', async () => {
            if (wakeLockActive && document.visibilityState === 'visible' && !wakeLock) {
              try { wakeLock = await navigator.wakeLock.request('screen'); } catch {}
            }
          });
        } else {
          toast('مرورگر از Wake Lock پشتیبانی نمی‌کنه', 'err');
        }
      } catch (e) {
        toast('Wake Lock ناموفق: ' + e.message, 'err');
      }
    }
    function releaseWakeLock() {
      if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
      wakeLockActive = false;
      localStorage.setItem('reader:wakelock', '0');
    }
    // Auto re-acquire on boot if previously enabled
    if (wakeLockActive && 'wakeLock' in navigator) {
      setTimeout(() => requestWakeLock().catch(() => {}), 1000);
    }

    /* ---------- Fullscreen ---------- */
    function toggleFullscreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } else {
        document.exitFullscreen?.().catch(() => {});
      }
    }

    /* ---------- Brightness ---------- */
    function setBrightness(pct) {
      brightness = pct;
      localStorage.setItem('reader:brightness', String(pct));
      const overlay = $('#brightnessOverlay');
      if (overlay) overlay.style.opacity = (100 - pct) / 100 * 0.7;
      const v = $('#brightnessValue');
      if (v) v.textContent = pct.toLocaleString('fa-IR') + '٪';
      const s = $('#brightnessSlider');
      if (s) s.value = pct;
    }

    /* ---------- Apply font settings ---------- */
    function applyFont() {
      $('#content').style.fontSize = fontSize + 'px';
      $('#content').style.lineHeight = lineHeight;
      $('#content').style.fontFamily = fontFamily;
      const fs = $('#fsSlider'); if (fs) fs.value = fontSize;
      const lh = $('#lhSlider'); if (lh) lh.value = lineHeight;
      const fsv = $('#fsValue'); if (fsv) fsv.textContent = fontSize.toLocaleString('fa-IR');
      const lhv = $('#lhValue'); if (lhv) lhv.textContent = lineHeight.toLocaleString('fa-IR');
      $$('.font-chip').forEach(c => c.classList.toggle('active', c.dataset.font === fontFamily));
    }
    function setTheme(t) { theme = t; applyTheme(t); }

    /* ---------- Sheet open/close ---------- */
    function openSheet() {
      $('#sheet').classList.add('open');
      $('#backdrop').classList.add('show');
      $('#fab').classList.add('hidden');
    }
    function closeSheet() {
      $('#sheet').classList.remove('open');
      $('#backdrop').classList.remove('show');
      $('#fab').classList.remove('hidden');
    }

    /* ---------- Tap zones (mobile only) ---------- */
    function setupTapZones() {
      if (!isMobile()) return;
      $('#readerWrap').classList.add('tap-active');
      // RTL: right zone = previous (back), left zone = next (forward)
      $('#tapPrev').onclick = () => goto(-1);
      $('#tapNext').onclick = () => goto(1);
      $('#tapCenter').onclick = () => toggleHeaderFooter();
    }
    function toggleHeaderFooter() {
      const h = $('#readerHeader');
      const b = $('#bottomNav');
      const f = $('#fab');
      const hidden = h.classList.contains('hidden');
      h.classList.toggle('hidden', !hidden);
      b.classList.toggle('hidden', !hidden);
      f.classList.toggle('hidden', !hidden);
    }
    function hideHeaderFooter() {
      $('#readerHeader').classList.add('hidden');
      $('#bottomNav').classList.add('hidden');
      $('#fab').classList.add('hidden');
    }
    function showHeaderFooter() {
      $('#readerHeader').classList.remove('hidden');
      $('#bottomNav').classList.remove('hidden');
      $('#fab').classList.remove('hidden');
    }

    /* ---------- Swipe gestures ---------- */
    let touchStartX = 0, touchStartY = 0, touchStartTime = 0;
    function setupSwipe() {
      if (!isTouch()) return;
      document.addEventListener('touchstart', (e) => {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        touchStartTime = Date.now();
      }, { passive: true });
      document.addEventListener('touchend', (e) => {
        const dx = e.changedTouches[0].clientX - touchStartX;
        const dy = e.changedTouches[0].clientY - touchStartY;
        const dt = Date.now() - touchStartTime;
        // Horizontal swipe only (>50px x, <60px y, fast)
        if (Math.abs(dx) > 60 && Math.abs(dy) < 60 && dt < 500) {
          // RTL: swipe right = next chapter (going back), swipe left = prev (going forward)
          // But more intuitively: swipe left → previous, swipe right → next (like flipping pages LTR)
          // For RTL we invert: swipe right → previous chapter, swipe left → next chapter
          if (dx > 0) goto(-1); // swipe right → previous
          else goto(1);          // swipe left → next
        }
      }, { passive: true });
    }

    /* ---------- Pinch to zoom font size ---------- */
    let pinchInitialDist = 0;
    let pinchInitialFont = 0;
    function setupPinch() {
      if (!isTouch()) return;
      document.addEventListener('touchstart', (e) => {
        if (e.touches.length === 2) {
          pinchInitialDist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          pinchInitialFont = fontSize;
        }
      }, { passive: true });
      document.addEventListener('touchmove', (e) => {
        if (e.touches.length === 2 && pinchInitialDist > 0) {
          const dist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          const scale = dist / pinchInitialDist;
          fontSize = Math.max(14, Math.min(32, Math.round(pinchInitialFont * scale)));
          localStorage.setItem(storeKey + ':fs', fontSize);
          applyFont();
        }
      }, { passive: true });
    }

    /* ---------- Auto-hide header/footer on scroll ---------- */
    let lastScrollY = 0;
    let scrollHideTimer = null;
    function setupAutoHide() {
      if (!isMobile()) return;
      window.addEventListener('scroll', () => {
        const sy = window.scrollY;
        const goingDown = sy > lastScrollY && sy > 100;
        const goingUp = sy < lastScrollY;
        if (goingDown) hideHeaderFooter();
        else if (goingUp) showHeaderFooter();
        lastScrollY = sy;
        // Update progress
        const sc = sy / Math.max(1, document.body.scrollHeight - window.innerHeight);
        const pct = Math.max(0, Math.min(1, sc));
        const bar = $('#readerProgress');
        if (bar) bar.style.transform = `scaleX(${pct})`;
        const pt = $('#progressText');
        if (pt) pt.textContent = Math.round(pct * 100).toLocaleString('fa-IR') + '٪';
      }, { passive: true });
    }

    /* ---------- Render chapter ---------- */
    function render() {
      if (!novelData) return;
      document.getElementById('title').textContent = novelData.title;
      const ch = novelData.chapters[chIndex];
      if (!ch) { $('#content').textContent = 'فصلی یافت نشد.'; return; }
      $('#pos').textContent = `فصل ${(chIndex + 1).toLocaleString('fa-IR')} از ${novelData.chapters.length.toLocaleString('fa-IR')}`;
      const orig = ch.originalText || '(متن اصل موجود نیست)';
      const trans = ch.translatedText || '(ترجمه نشده — دکمهٔ «ترجمه این فصل» رو بزن)';
      let html = '';
      if (view === 'translated') {
        html = trans.split(/\n\n+/).map(p => `<p class="translated">${esc(p)}</p>`).join('');
      } else if (view === 'original') {
        html = orig.split(/\n\n+/).map(p => `<p class="original">${esc(p)}</p>`).join('');
      } else {
        html = `<h4>اصل</h4>${orig.split(/\n\n+/).map(p => `<p class="original">${esc(p)}</p>`).join('')}<h4>ترجمه</h4>${trans.split(/\n\n+/).map(p => `<p class="translated">${esc(p)}</p>`).join('')}`;
      }
      $('#content').innerHTML = html;
      $('#prev').disabled = chIndex <= 0;
      $('#next').disabled = chIndex >= novelData.chapters.length - 1;
      localStorage.setItem(storeKey + ':ch', chIndex);
      api.bookmark(novelId, chIndex).catch(() => {});
      applyFont();
      $$('#viewSeg button').forEach(b => b.classList.toggle('active', b.dataset.v === view));
      window.scrollTo(0, 0);
      // Reset progress
      const bar = $('#readerProgress'); if (bar) bar.style.transform = 'scaleX(0)';
      const pt = $('#progressText'); if (pt) pt.textContent = '۰٪';
    }

    function goto(d) {
      if (!novelData) return;
      const ni = chIndex + d;
      if (ni < 0 || ni >= novelData.chapters.length) return;
      endSession();
      chIndex = ni;
      render();
      startSession();
      const u = new URL(location);
      u.searchParams.set('ch', chIndex);
      history.replaceState({}, '', u);
    }

    /* ---------- Load novel ---------- */
    async function load() {
      novelData = await api.novel(novelId);
      if (!novelData || novelData.error) {
        $('#content').textContent = 'رمان یافت نشد.';
        return;
      }
      const bookmark = await api.bookmarks().then(bs => bs.find(b => b.novelId === novelId));
      if (ch === undefined && bookmark) chIndex = bookmark.chapterIndex;
      render();
      await startSession();
    }
    load();

    /* ---------- Lifecycle ---------- */
    window.addEventListener('beforeunload', () => { endSession(); });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) endSession();
      else if (!currentSessionId && novelData) startSession();
    });

    /* ---------- Click handlers ---------- */
    $('#backBtn').onclick = () => location.href = '/detail?id=' + novelId;
    $('#prev').onclick = () => goto(-1);
    $('#next').onclick = () => goto(1);
    const cycleTheme = () => {
      const ts = ['dark', 'light', 'sepia', 'midnight'];
      setTheme(ts[(ts.indexOf(theme) + 1) % ts.length]);
    };
    $('#themeBtn').onclick = cycleTheme;
    $('#fullscreenBtn').onclick = toggleFullscreen;

    // Sheet open/close
    $('#fab').onclick = openSheet;
    $('#backdrop').onclick = closeSheet;

    // View mode segmented
    $$('#viewSeg button').forEach(b => b.onclick = () => {
      view = b.dataset.v;
      localStorage.setItem(storeKey + ':view', view);
      render();
    });

    // Font family chips
    $$('.font-chip').forEach(c => c.onclick = () => {
      fontFamily = c.dataset.font;
      localStorage.setItem(storeKey + ':ff', fontFamily);
      applyFont();
    });

    // Sliders
    $('#fsSlider').oninput = (e) => {
      fontSize = parseInt(e.target.value);
      localStorage.setItem(storeKey + ':fs', fontSize);
      applyFont();
    };
    $('#lhSlider').oninput = (e) => {
      lineHeight = parseFloat(e.target.value);
      localStorage.setItem(storeKey + ':lh', lineHeight);
      applyFont();
    };
    $('#brightnessSlider').oninput = (e) => setBrightness(parseInt(e.target.value));

    // Actions
    $('#bookmarkBtn').onclick = async () => {
      await api.bookmark(novelId, chIndex);
      toast('جایگاه ذخیره شد 🔖', 'ok');
      closeSheet();
    };
    $('#ttsBtn').onclick = () => { toggleTTS(); closeSheet(); };
    $('#autoScrollBtn').onclick = () => { startAutoScroll(); closeSheet(); };
    $('#compareBtn').onclick = async () => {
      const ch = novelData.chapters[chIndex];
      if (!ch) return;
      const r = await api.fetch('/api/translate/compare', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chapterId: ch.id })
      }).then(r => r.json());
      if (r.jobId) { toast('مقایسه شروع شد ⚖', 'ok'); setGlobalProgress(0); }
      closeSheet();
    };
    $('#immersiveBtn').onclick = () => {
      immersive = !immersive;
      localStorage.setItem(storeKey + ':immersive', immersive ? '1' : '0');
      $('#readerWrap').classList.toggle('immersive', immersive);
      toast(immersive ? 'حالت غوطه‌ور فعال شد' : 'حالت غوطه‌ور غیرفعال شد', 'ok');
      closeSheet();
    };
    $('#wakeLockBtn').onclick = () => {
      if (wakeLockActive) { releaseWakeLock(); toast('Wake Lock غیرفعال شد', 'ok'); }
      else { requestWakeLock(); }
      closeSheet();
    };
    $('#chapterListBtn').onclick = () => { location.href = '/detail?id=' + novelId; };
    $('#settingsBtn').onclick = () => { location.href = '/settings'; };
    $('#translate').onclick = async () => {
      const ch = novelData.chapters[chIndex];
      $('#translate').disabled = true;
      $('#translate').textContent = 'در حال ترجمه…';
      toast('در حال ترجمه…');
      const r = await api.translateChapter(ch.id);
      if (r.jobId) {
        setGlobalProgress(0);
        closeSheet();
      } else {
        $('#translate').disabled = false;
        $('#translate').textContent = '🌐 ترجمه این فصل';
        toast('خطا: ' + JSON.stringify(r), 'err');
      }
    };

    /* ---------- Keyboard shortcuts (desktop) ---------- */
    document.addEventListener('keydown', (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      if (e.key === 'ArrowRight') { goto(-1); e.preventDefault(); }
      else if (e.key === 'ArrowLeft') { goto(1); e.preventDefault(); }
      else if (e.key === 't' || e.key === 'T') cycleTheme();
      else if (e.key === '+' || e.key === '=') { fontSize = Math.min(32, fontSize + 1); localStorage.setItem(storeKey + ':fs', fontSize); applyFont(); }
      else if (e.key === '-') { fontSize = Math.max(14, fontSize - 1); localStorage.setItem(storeKey + ':fs', fontSize); applyFont(); }
      else if (e.key === '1') { view = 'translated'; localStorage.setItem(storeKey + ':view', view); render(); }
      else if (e.key === '2') { view = 'original'; localStorage.setItem(storeKey + ':view', view); render(); }
      else if (e.key === '3') { view = 'both'; localStorage.setItem(storeKey + ':view', view); render(); }
      else if (e.key === 'Escape') closeSheet();
      else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
      // New shortcuts
      else if (e.key === ' ') { e.preventDefault(); startAutoScroll(); }
      else if (e.key === 's' || e.key === 'S') { toggleTTS(); }
      else if (e.key === 'b' || e.key === 'B') { $('#bookmarkBtn').click(); }
      else if (e.key === 'i' || e.key === 'I') { $('#immersiveBtn').click(); }
      else if (e.key === 'h' || e.key === 'H') { toggleHeaderFooter(); }
      else if (e.key === 'PageUp') { goto(-1); e.preventDefault(); }
      else if (e.key === 'PageDown') { goto(1); e.preventDefault(); }
    });

    /* ---------- SSE ---------- */
    sse.on('job:progress', (d) => {
      if (d.type === 'translate_chapter' || d.type === 'translate_novel') {
        setGlobalProgress(d.total ? (d.current / d.total * 100) : 0);
      }
    });
    sse.on('job:done', async (d) => {
      if (d.type === 'translate_chapter' || d.type === 'translate_novel') {
        setGlobalProgress(null);
        $('#translate').disabled = false;
        $('#translate').textContent = '🌐 ترجمه این فصل';
        toast('ترجمه کامل شد ✅', 'ok');
        await load();
      }
    });
    sse.on('job:failed', (d) => {
      if (d.type === 'translate_chapter' || d.type === 'translate_novel') {
        setGlobalProgress(null);
        $('#translate').disabled = false;
        $('#translate').textContent = '🌐 ترجمه این فصل';
        toast('ترجمه ناموفق: ' + d.error, 'err');
      }
    });

    /* ---------- TTS ---------- */
    let ttsPlaying = false;
    let ttsPaused = false;
    let ttsRate = parseFloat(localStorage.getItem('reader:ttsRate') || '1');
    function toggleTTS() {
      if (ttsPlaying) {
        // pause/resume instead of cancel
        if (ttsPaused) {
          window.speechSynthesis.resume();
          ttsPaused = false;
          $('#ttsBtn').querySelector('.icon').textContent = '⏸';
        } else {
          window.speechSynthesis.pause();
          ttsPaused = true;
          $('#ttsBtn').querySelector('.icon').textContent = '▶';
        }
        return;
      }
      if (!window.speechSynthesis) { toast('مرورگر از TTS پشتیبانی نمی‌کنه', 'err'); return; }
      const text = $('#content').innerText;
      if (!text || text.length < 5) { toast('متن برای خواندن نیست', 'err'); return; }
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'fa-IR';
      u.rate = ttsRate;
      // Try several Persian voices (some browsers name them differently)
      const voices = window.speechSynthesis.getVoices();
      const faVoice = voices.find(v => v.lang && v.lang.toLowerCase().startsWith('fa'))
        || voices.find(v => v.name && v.name.toLowerCase().includes('persian'))
        || voices.find(v => v.name && v.name.toLowerCase().includes('farsi'));
      if (faVoice) u.voice = faVoice;
      u.onend = () => {
        ttsPlaying = false; ttsPaused = false;
        $('#ttsBtn').querySelector('.icon').textContent = '🔊';
      };
      u.onerror = () => {
        ttsPlaying = false; ttsPaused = false;
        $('#ttsBtn').querySelector('.icon').textContent = '🔊';
      };
      // Chrome bug: speak() can silently fail if called too soon after cancel
      window.speechSynthesis.cancel();
      setTimeout(() => {
        window.speechSynthesis.speak(u);
        ttsPlaying = true;
        $('#ttsBtn').querySelector('.icon').textContent = '⏸';
      }, 100);
    }
    // Long-press TTS button to adjust speed
    let ttsPressTimer = null;
    $('#ttsBtn').addEventListener('mousedown', () => {
      ttsPressTimer = setTimeout(() => {
        const rates = [0.7, 0.85, 1, 1.15, 1.3, 1.5];
        const idx = rates.indexOf(ttsRate);
        ttsRate = rates[(idx + 1) % rates.length];
        localStorage.setItem('reader:ttsRate', String(ttsRate));
        toast(`سرعت خواندن صوتی: ${ttsRate}x`, 'ok');
        ttsPressTimer = null;
      }, 600);
    });
    $('#ttsBtn').addEventListener('mouseup', () => { if (ttsPressTimer) { clearTimeout(ttsPressTimer); ttsPressTimer = null; } });
    $('#ttsBtn').addEventListener('mouseleave', () => { if (ttsPressTimer) { clearTimeout(ttsPressTimer); ttsPressTimer = null; } });

    /* ---------- Highlight toolbar ---------- */
    const hlToolbar = $('#highlightToolbar');
    document.addEventListener('mouseup', (e) => {
      if (e.target.closest('.reader-sheet') || e.target.closest('.reader-header') || e.target.closest('.reader-bottom-nav')) return;
      const sel = window.getSelection();
      const text = sel.toString().trim();
      if (!text || text.length < 2) { hlToolbar.classList.add('hide'); return; }
      const range = sel.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      hlToolbar.classList.remove('hide');
      hlToolbar.style.top = Math.max(20, rect.top + window.scrollY - 60) + 'px';
      hlToolbar.style.left = Math.max(10, Math.min(window.innerWidth - 290, rect.left + window.scrollX + rect.width/2 - 140)) + 'px';
    });
    document.addEventListener('mousedown', (e) => {
      if (hlToolbar.contains(e.target)) return;
      setTimeout(() => {
        const sel = window.getSelection();
        if (!sel.toString().trim()) hlToolbar.classList.add('hide');
      }, 10);
    });
    $$('.hl-color').forEach(b => b.onclick = async () => {
      const sel = window.getSelection();
      const text = sel.toString().trim();
      if (!text) return;
      const ch = novelData.chapters[chIndex];
      await api.fetch('/api/highlights', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ novelId, chapterId: ch.id, chapterIndex: chIndex, text, color: b.dataset.color })
      });
      toast('هایلایت ذخیره شد 🖍', 'ok');
      hlToolbar.classList.add('hide');
      sel.removeAllRanges();
    });
    $('#hlNote').onclick = async () => {
      const sel = window.getSelection();
      const text = sel.toString().trim();
      if (!text) return;
      const note = prompt('یادداشت برای این هایلایت:');
      const ch = novelData.chapters[chIndex];
      await api.fetch('/api/highlights', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ novelId, chapterId: ch.id, chapterIndex: chIndex, text, color: 'yellow', note })
      });
      toast('هایلایت + یادداشت ذخیره شد', 'ok');
      hlToolbar.classList.add('hide');
      sel.removeAllRanges();
    };
    $('#hlCopy').onclick = () => {
      const sel = window.getSelection();
      const text = sel.toString();
      navigator.clipboard.writeText(text).then(() => toast('کپی شد 📋', 'ok'));
      hlToolbar.classList.add('hide');
    };

    /* ---------- Setup mobile features ---------- */
    setupTapZones();
    setupSwipe();
    setupPinch();
    setupAutoHide();
    if (immersive) $('#readerWrap').classList.add('immersive');
    setBrightness(brightness);
    applyFont();
  }

  /* ==================================================================
     Admin page
     ================================================================== */
  async function initAdmin() {
    applyTheme(getTheme());
    sse.ensure();

    $$('#siteExamples .pill').forEach(p => {
      p.onclick = () => {
        $('#url').value = p.dataset.url;
        $$('#siteExamples .pill').forEach(x => x.classList.remove('active'));
        p.classList.add('active');
        detectSite();
      };
    });

    // Auto-detect site on URL input
    let detectTimer = null;
    function detectSite() {
      const u = $('#url').value.trim();
      const el = $('#detectResult');
      if (!u || !/^https?:\/\//.test(u)) {
        el.textContent = '';
        el.style.color = '';
        return;
      }
      el.textContent = 'در حال تشخیص سایت…';
      el.style.color = 'var(--muted)';
      clearTimeout(detectTimer);
      detectTimer = setTimeout(async () => {
        try {
          const r = await api.fetch('/api/discover/detect?url=' + encodeURIComponent(u)).then(r => r.json());
          if (r.id) {
            el.innerHTML = `✓ سایت شناسایی شد: <strong style="color:var(--accent-2)">${esc(r.name)}</strong>`;
            el.style.color = 'var(--accent-2)';
          } else {
            el.textContent = '⚠ سایت ناشناخته — از حالت generic استفاده می‌شه';
            el.style.color = 'var(--warn)';
          }
        } catch {
          el.textContent = '';
        }
      }, 400);
    }
    $('#url').oninput = detectSite;

    // Update download count display when start/end changes
    function updateDlCount() {
      const s = parseInt($('#startChapter').value) || 1;
      const eStr = $('#endChapter').value.trim();
      const el = $('#dlCount');
      if (!eStr) {
        el.textContent = 'همه';
      } else {
        const e = parseInt(eStr) || s;
        const n = Math.max(0, e - s + 1);
        el.textContent = n.toLocaleString('fa-IR');
      }
    }
    $('#startChapter').oninput = updateDlCount;
    $('#endChapter').oninput = updateDlCount;

    $('#add').onclick = async () => {
      const url = $('#url').value.trim();
      const startChapter = parseInt($('#startChapter').value) || 1;
      const endChapterStr = $('#endChapter').value.trim();
      const endChapter = endChapterStr ? (parseInt(endChapterStr) || null) : null;
      const autoTranslate = $('#autoTranslate') ? $('#autoTranslate').checked : false;
      if (!url) { $('#status').textContent = 'لینک رو وارد کن.'; $('#status').className = 'status-box err'; $('#status').classList.remove('hide'); return; }
      if (endChapter && endChapter < startChapter) {
        $('#status').textContent = 'فصل پایان باید بزرگتر یا مساوی فصل شروع باشه.'; $('#status').className = 'status-box err';
        $('#status').classList.remove('hide');
        return;
      }
      const limit = endChapter ? (endChapter - startChapter + 1) : 5;
      $('#status').textContent = `در حال ارسال به صف scrape… (${limit.toLocaleString('fa-IR')} فصل از ${startChapter.toLocaleString('fa-IR')} ${endChapter ? 'تا ' + endChapter.toLocaleString('fa-IR') : 'تا آخر'})`;
      $('#status').className = 'status-box info';
      $('#status').classList.remove('hide');
      try {
        const r = await fetch('/api/add', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url, limit, autoTranslate,
            startChapter,
            endChapter: endChapter || undefined
          })
        }).then(r => r.json());
        if (r.jobId) {
          $('#status').textContent = `Job شروع شد. ID: ${r.jobId}`; $('#status').className = 'status-box ok';
          $('#jobProgress').classList.remove('hide');
          setGlobalProgress(0);
          // watch for completion
          sse.on('job:done', (d) => {
            if (d.id === r.jobId && d.type === 'scrape') {
              $('#status').textContent = `✓ ${(d.result.chapters || 0).toLocaleString('fa-IR')} فصل اضافه شد. در حال انتقال…`;
              setGlobalProgress(null);
              setTimeout(() => location.href = '/detail?id=' + d.result.novelId, 1200);
            }
          });
          sse.on('job:failed', (d) => {
            if (d.id === r.jobId) {
              $('#status').textContent = '✗ خطا: ' + d.error; $('#status').className = 'status-box err';
              setGlobalProgress(null);
            }
          });
          sse.on('job:progress', (d) => {
            if (d.id === r.jobId) {
              $('#jobBar').style.width = (d.total ? (d.current / d.total * 100) : 0) + '%';
              setGlobalProgress(d.total ? (d.current / d.total * 100) : 0);
            }
          });
        } else {
          $('#status').textContent = 'خطا: ' + JSON.stringify(r); $('#status').className = 'status-box err';
        }
      } catch (e) {
        $('#status').textContent = 'خطا: ' + e.message; $('#status').className = 'status-box err';
      }
    };
  }

  /* ==================================================================
     Search page
     ================================================================== */
  function initSearch() {
    applyTheme(getTheme());
    let timer = null;
    $('#searchInput').oninput = (e) => {
      const q = e.target.value.trim();
      clearTimeout(timer);
      if (!q) {
        $('#results').innerHTML = '<p class="muted center">عبارتی برای جستجو وارد کن.</p>';
        return;
      }
      timer = setTimeout(async () => {
        $('#results').innerHTML = '<p class="muted center">در حال جستجو…</p>';
        const results = await api.search(q);
        if (!results.length) {
          $('#results').innerHTML = '<p class="muted center">نتیجه‌ای یافت نشد.</p>';
          return;
        }
        $('#results').innerHTML = results.map(r => `
          <a class="search-result" href="/read?novel=${r.novelId}&ch=${(r.chapterNumber || 1) - 1}">
            <div class="title">فصل ${r.chapterNumber}: ${esc(r.title)}</div>
            <div class="snippet">${r.snippet || ''}</div>
          </a>
        `).join('');
      }, 300);
    };
  }

  /* ==================================================================
     Stats page (with charts)
     ================================================================== */
  async function initStats() {
    applyTheme(getTheme());
    sse.ensure();
    async function load() {
      const s = await api.stats();
      const els = ['#stat-novels','#stat-chapters','#stat-translated','#stat-words','#stat-tm'];
      // stat cards may differ between old/new layout
      const totalN = $('#stat-novels'); if (totalN) totalN.textContent = s.novels ?? 0;
      const totalC = $('#stat-chapters'); if (totalC) totalC.textContent = s.chapters ?? 0;
      const totalT = $('#stat-translated'); if (totalT) totalT.textContent = s.translated ?? 0;
      const totalW = $('#stat-words'); if (totalW) totalW.textContent = (s.words ?? 0).toLocaleString('fa-IR');
      const totalM = $('#stat-tm'); if (totalM) totalM.textContent = s.tm ?? 0;

      // Reading stats (sessions)
      const range = $('#range')?.value || 'week';
      const r = await api.fetch('/api/reading/stats?range=' + range).then(r => r.json()).catch(() => null);
      if (r) {
        const tt = $('#totalTime'); if (tt) tt.textContent = Math.round((r.totalMs || 0) / 60000).toLocaleString('fa-IR');
        const tw = $('#totalWords'); if (tw) tw.textContent = (r.totalWords || 0).toLocaleString('fa-IR');
        const sc = $('#sessionCount'); if (sc) sc.textContent = (r.sessionCount || 0).toLocaleString('fa-IR');
        const as = $('#avgSession'); if (as) as.textContent = Math.round((r.avgPerSession || 0) / 60000).toLocaleString('fa-IR');
        const sk = $('#streak'); if (sk) sk.querySelector('.num').textContent = (r.streak || 0).toLocaleString('fa-IR');

        // SVG chart for byDay
        const chartEl = $('#chart');
        if (chartEl) {
          const days = Object.entries(r.byDay || {}).sort((a, b) => a[0].localeCompare(b[0]));
          if (days.length) {
            const max = Math.max(...days.map(d => d[1]), 1);
            const barW = 30, gap = 6;
            const w = days.length * (barW + gap);
            const h = 120;
            const bars = days.map(([day, ms], idx) => {
              const bh = Math.max(2, (ms / max) * h);
              const mins = Math.round(ms / 60000);
              return `<g><rect x="${idx * (barW+gap)}" y="${h-bh}" width="${barW}" height="${bh}" rx="3" fill="var(--accent)"/><text x="${idx * (barW+gap) + barW/2}" y="${h+15}" text-anchor="middle" font-size="9" fill="var(--muted)">${day.slice(5)}</text><text x="${idx * (barW+gap) + barW/2}" y="${h-bh-4}" text-anchor="middle" font-size="9" fill="var(--fg-soft)">${mins}</text></g>`;
            }).join('');
            chartEl.innerHTML = `<svg viewBox="0 0 ${w} ${h+25}" style="width:100%;max-width:800px;height:auto;overflow:visible">${bars}</svg>`;
          } else {
            chartEl.innerHTML = '<p class="muted center">هنوز داده‌ای ثبت نشده.</p>';
          }
        }

        // Top novels
        const topEl = $('#topNovels');
        if (topEl && Object.keys(r.byNovel || {}).length) {
          const novels = await api.novels();
          const sorted = Object.entries(r.byNovel)
            .map(([id, ms]) => ({ novel: novels.find(n => n.id === id), ms }))
            .filter(x => x.novel)
            .sort((a, b) => b.ms - a.ms)
            .slice(0, 5);
          topEl.innerHTML = sorted.map(x => `
            <a class="chapter-row" href="/detail?id=${x.novel.id}">
              <span class="title">${esc(x.novel.title)}</span>
              <span class="badge">${Math.round(x.ms / 60000).toLocaleString('fa-IR')} دقیقه</span>
            </a>`).join('');
        } else if (topEl) {
          topEl.innerHTML = '<p class="muted center">داده‌ای موجود نیست.</p>';
        }
      }

      const jobs = await api.jobs();
      const el = $('#jobs');
      if (!el) return;
      if (!jobs.length) {
        el.innerHTML = '<p class="muted center">هنوز jobی ثبت نشده.</p>';
        return;
      }
      el.innerHTML = jobs.slice(0, 20).map(j => {
        const pct = j.total ? Math.round((j.progress / j.total) * 100) : 0;
        return `
          <div class="job-row">
            <span class="type">${esc(j.type)}</span>
            <div class="progress"><i style="width:${pct}%"></i></div>
            <span class="status ${j.status}">${j.status}</span>
            <span class="muted" style="font-size:.75rem">${new Date(j.created_at).toLocaleString('fa-IR')}</span>
            ${j.status === 'running' ? `<button class="btn tiny ghost" data-cancel="${j.id}">لغو</button>` : ''}
          </div>`;
      }).join('');
      $$('[data-cancel]').forEach(b => b.onclick = async () => {
        await api.cancelJob(b.dataset.cancel);
        toast('Job لغو شد', 'ok');
        load();
      });
    }
    const rangeSel = $('#range');
    if (rangeSel) rangeSel.onchange = load;
    load();
    sse.on('job:progress', () => load());
    sse.on('job:done', () => load());
    sse.on('job:failed', () => load());
  }

  /* ==================================================================
     History page
     ================================================================== */
  async function initHistory() {
    applyTheme(getTheme());
    const sessions = await api.fetch('/api/reading/sessions?limit=200').then(r => r.json()).catch(() => []);
    const novels = await api.novels();
    const el = $('#timeline');
    if (!sessions.length) {
      el.innerHTML = '<p class="empty"><span class="icon">🕒</span>هنوز جلسهٔ خواندنی ثبت نشده.</p>';
      return;
    }
    // Group by day
    const byDay = {};
    for (const s of sessions) {
      const day = (s.started_at || s.startedAt).slice(0, 10);
      if (!byDay[day]) byDay[day] = [];
      byDay[day].push(s);
    }
    const days = Object.entries(byDay).sort((a, b) => b[0].localeCompare(a[0]));
    el.innerHTML = days.map(([day, ss]) => {
      const dayTotal = ss.reduce((a, s) => a + (s.duration_ms || s.durationMs || 0), 0);
      return `
        <div class="settings-section">
          <h3 style="display:flex;justify-content:space-between;align-items:center">
            <span>${new Date(day).toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
            <span class="muted" style="font-size:.85rem">${Math.round(dayTotal/60000).toLocaleString('fa-IR')} دقیقه</span>
          </h3>
          <div class="col">
            ${ss.map(s => {
              const n = novels.find(x => x.id === (s.novel_id || s.novelId));
              const ms = s.duration_ms || s.durationMs || 0;
              return `
                <a class="chapter-row" href="/read?novel=${s.novel_id || s.novelId}&ch=${s.chapter_index ?? s.chapterIndex ?? 0}">
                  <span class="title">${esc(n?.title || 'نامشخص')} ${s.chapter_index != null ? '· فصل ' + (s.chapter_index + 1) : ''}</span>
                  <span class="badge">${Math.round(ms/60000).toLocaleString('fa-IR')} دقیقه</span>
                </a>`;
            }).join('')}
          </div>
        </div>`;
    }).join('');
  }

  /* ==================================================================
     Highlights page
     ================================================================== */
  async function initHighlights() {
    applyTheme(getTheme());
    async function load() {
      const list = await api.fetch('/api/highlights').then(r => r.json()).catch(() => []);
      const el = $('#list');
      if (!list.length) {
        el.innerHTML = '<p class="empty"><span class="icon">🖍️</span>هنوز هایلایتی نزدی.<br>تو صفحهٔ خواننده، متن رو انتخاب کن و رنگ بزن.</p>';
        return;
      }
      const novels = await api.novels();
      el.innerHTML = list.map(h => {
        const n = novels.find(x => x.id === (h.novel_id || h.novelId));
        return `
          <div class="settings-section" data-id="${h.id}">
            <div style="display:flex;justify-content:space-between;align-items:start;gap:1rem">
              <div style="flex:1">
                <div class="muted" style="font-size:.8rem;margin-bottom:.4rem">
                  ${esc(n?.title || 'نامشخص')} ${h.chapter_index != null ? '· فصل ' + (h.chapter_index + 1) : ''} · ${new Date(h.created_at).toLocaleDateString('fa-IR')}
                </div>
                <div class="hl-quote" style="border-right:3px solid ${hlColor(h.color)};padding-right:.8rem;color:var(--fg-soft)">${esc((h.text||'').slice(0,300))}</div>
                ${h.note ? `<div class="muted" style="margin-top:.4rem;font-size:.85rem">📝 ${esc(h.note)}</div>` : ''}
              </div>
              <button class="btn tiny ghost danger" data-del="${h.id}">حذف</button>
            </div>
          </div>`;
      }).join('');
      $$('[data-del]').forEach(b => b.onclick = async () => {
        await api.fetch('/api/highlights/' + b.dataset.del, { method: 'DELETE' });
        toast('حذف شد', 'ok');
        load();
      });
    }
    $('#searchHl').oninput = (e) => {
      const q = e.target.value.trim().toLowerCase();
      $$('.settings-section[data-id]').forEach(s => {
        const t = s.textContent.toLowerCase();
        s.style.display = (!q || t.includes(q)) ? '' : 'none';
      });
    };
    load();
  }
  function hlColor(c) {
    return ({ yellow: '#f0c040', green: '#3ad29f', blue: '#6c8cff', pink: '#ff6b81' })[c] || '#f0c040';
  }

  /* ==================================================================
     Achievements page
     ================================================================== */
  async function initAchievements() {
    applyTheme(getTheme());
    const list = await api.fetch('/api/achievements').then(r => r.json()).catch(() => []);
    const unlocked = list.filter(a => a.unlocked).length;
    const total = list.length;
    $('#achSummary').innerHTML = `
      <div class="stat-card"><div class="num">${unlocked.toLocaleString('fa-IR')}</div><div class="lbl">دستاورد باز‌شده</div></div>
      <div class="stat-card accent2"><div class="num">${total.toLocaleString('fa-IR')}</div><div class="lbl">کل دستاوردها</div></div>
      <div class="stat-card accent3"><div class="num">${Math.round(unlocked/total*100).toLocaleString('fa-IR')}%</div><div class="lbl">پیشرفت</div></div>`;
    $('#achGrid').innerHTML = list.map(a => `
      <div class="card" style="cursor:default;${a.unlocked ? '' : 'opacity:.4'}">
        <div style="font-size:2.5rem;text-align:center">${a.icon}</div>
        <h3 style="text-align:center">${esc(a.name)}</h3>
        <p class="muted" style="text-align:center;font-size:.85rem">${esc(a.description)}</p>
        ${a.unlocked ? `<div class="badge" style="align-self:center;background:var(--accent-2-soft);color:var(--accent-2)">✓ باز شد</div>` : '<div class="badge" style="align-self:center">قفل</div>'}
        ${a.unlockedAt ? `<div class="muted" style="text-align:center;font-size:.75rem">${new Date(a.unlockedAt).toLocaleDateString('fa-IR')}</div>` : ''}
      </div>`).join('');
  }

  /* ==================================================================
     Goals page
     ================================================================== */
  async function initGoals() {
    applyTheme(getTheme());
    async function load() {
      const goals = await api.fetch('/api/goals').then(r => r.json()).catch(() => []);
      const el = $('#goalsList');
      if (!goals.length) {
        el.innerHTML = '<p class="muted center">هنوزهدفی تعریف نشده.</p>';
        return;
      }
      // For each goal, compute progress from reading stats
      const r = await api.fetch('/api/reading/stats?range=week').then(r => r.json()).catch(() => ({}));
      el.innerHTML = goals.map(g => {
        let progress = 0;
        if (g.type === 'chapters') progress = r.sessionCount || 0;
        else if (g.type === 'minutes') progress = Math.round((r.totalMs || 0) / 60000);
        const pct = Math.min(100, Math.round((progress / g.target) * 100));
        return `
          <div class="chapter-row" style="flex-direction:column;align-items:stretch;gap:.5rem">
            <div style="display:flex;justify-content:space-between">
              <span><strong>${g.type === 'chapters' ? 'فصل' : 'دقیقه'}</strong> · ${g.period === 'day' ? 'روزانه' : g.period === 'week' ? 'هفتگی' : 'ماهانه'}</span>
              <span class="muted">${progress.toLocaleString('fa-IR')} / ${g.target.toLocaleString('fa-IR')}</span>
              <button class="btn tiny ghost" data-del="${g.id}">حذف</button>
            </div>
            <div class="progress" style="height:8px"><i style="width:${pct}%;background:${pct >= 100 ? 'var(--accent-2)' : 'var(--accent)'}"></i></div>
            ${pct >= 100 ? '<div class="muted" style="color:var(--accent-2);font-size:.85rem">🎉 هدف محقق شد!</div>' : ''}
          </div>`;
      }).join('');
      $$('[data-del]').forEach(b => b.onclick = async () => {
        await api.fetch('/api/goals/' + b.dataset.del, { method: 'DELETE' });
        toast('حذف شد', 'ok');
        load();
      });
    }
    $('#addGoal').onclick = async () => {
      const type = $('#goalType').value;
      const target = parseInt($('#goalTarget').value);
      const period = $('#goalPeriod').value;
      if (!target || target < 1) { toast('مقدار هدف معتبر نیست', 'err'); return; }
      await api.fetch('/api/goals', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, target, period })
      });
      toast('هدف اضافه شد 🎯', 'ok');
      load();
    };
    load();
  }

  /* ==================================================================
     Updates page
     ================================================================== */
  async function initUpdates() {
    applyTheme(getTheme());
    sse.ensure();
    async function load() {
      const list = await api.fetch('/api/updates').then(r => r.json()).catch(() => []);
      const el = $('#list');
      if (!list.length) {
        el.innerHTML = '<p class="empty"><span class="icon">🔄</span>هنوز رمانی برای بررسی نیست.</p>';
        return;
      }
      el.innerHTML = list.map(u => {
        const statusText = u.status === 'has_updates' ? `${u.new_chapters_count} فصل جدید` :
                           u.status === 'up_to_date' ? 'بروز است' :
                           u.status === 'check_failed' ? 'خطا در بررسی' : 'نامشخص';
        const statusClass = u.status === 'has_updates' ? 'translated' :
                            u.status === 'up_to_date' ? 'scraped' :
                            u.status === 'check_failed' ? 'failed' : 'pending';
        return `
          <div class="chapter-row">
            <span class="title">${esc(u.novel_title || u.title || 'نامشخص')}</span>
            <span class="status ${statusClass}">${statusText}</span>
            <span class="muted" style="font-size:.75rem">${u.last_checked ? new Date(u.last_checked).toLocaleDateString('fa-IR') : ''}</span>
            <button class="btn tiny ghost" data-check="${u.novel_id || u.novelId}">بررسی</button>
          </div>`;
      }).join('');
      $$('[data-check]').forEach(b => b.onclick = async () => {
        const r = await api.fetch('/api/updates/check', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ novelId: b.dataset.check })
        }).then(r => r.json());
        toast(`بررسی شروع شد (Job: ${r.jobId})`, 'ok');
      });
    }
    $('#checkAll').onclick = async () => {
      const r = await api.fetch('/api/updates/check', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ all: true })
      }).then(r => r.json());
      toast(`بررسی همه شروع شد`, 'ok');
      setGlobalProgress(0);
    };
    sse.on('job:done', (d) => {
      if (d.type === 'check_updates' || d.type === 'check_all_updates') {
        setGlobalProgress(null);
        load();
      }
    });
    sse.on('job:progress', (d) => {
      if (d.type === 'check_all_updates') setGlobalProgress(d.total ? d.current / d.total * 100 : 0);
    });
    load();
  }

  /* ==================================================================
     Wiki page
     ================================================================== */
  async function initWiki() {
    applyTheme(getTheme());
    sse.ensure();
    const novels = await api.novels();
    const sel = $('#novelSelect');
    novels.forEach(n => sel.add(new Option(n.title, n.id)));
    async function load() {
      const id = sel.value;
      const grid = $('#wikiGrid');
      if (!id) { grid.innerHTML = '<p class="muted center" style="grid-column:1/-1">یک رمان انتخاب کن.</p>'; return; }
      const entries = await api.fetch(`/api/novel/${id}/wiki`).then(r => r.json()).catch(() => []);
      if (!entries.length) {
        grid.innerHTML = '<p class="muted center" style="grid-column:1/-1">ویکی خالیه. دکمهٔ «استخراج با AI» رو بزن.</p>';
        return;
      }
      grid.innerHTML = entries.map(w => `
        <div class="card" style="cursor:default">
          <span class="site-tag">${esc(w.type || 'character')}</span>
          <h3>${esc(w.name)}</h3>
          <p class="muted" style="font-size:.85rem">${esc(w.description || '')}</p>
          ${w.aliases ? `<div class="badge">نام‌های دیگر: ${esc(w.aliases)}</div>` : ''}
          <div class="badge">${(w.mentions || 1).toLocaleString('fa-IR')} اشاره</div>
        </div>`).join('');
    }
    sel.onchange = load;
    $('#extractBtn').onclick = async () => {
      if (!sel.value) { toast('اول رمان رو انتخاب کن', 'err'); return; }
      const r = await api.fetch('/api/wiki/extract', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ novelId: sel.value })
      }).then(r => r.json());
      toast(`استخراج شروع شد`, 'ok');
      setGlobalProgress(0);
    };
    sse.on('job:done', (d) => {
      if (d.type === 'extract_wiki') {
        setGlobalProgress(null);
        toast(`${d.result?.added || 0} مدخل اضافه شد`, 'ok');
        load();
      }
    });
    load();
  }

  /* ==================================================================
     Queue page
     ================================================================== */
  async function initQueue() {
    applyTheme(getTheme());
    async function load() {
      const list = await api.fetch('/api/queue').then(r => r.json()).catch(() => []);
      const el = $('#list');
      if (!list.length) {
        el.innerHTML = '<p class="empty" style="grid-column:1/-1"><span class="icon">📋</span>صف خالی است.</p>';
        return;
      }
      el.innerHTML = list.map(q => `
        <a class="card" href="/detail?id=${q.novel_id || q.novelId}">
          ${q.cover_url ? `<img class="cover" src="/api/img?src=${encodeURIComponent(q.cover_url)}" alt="">` : '<div class="cover placeholder">📖</div>'}
          <h3>${esc(q.title)}</h3>
          <span class="author">${esc(q.author || '')}</span>
          <button class="btn tiny ghost danger" data-rm="${q.novel_id || q.novelId}">حذف از صف</button>
        </a>`).join('');
      $$('[data-rm]').forEach(b => b.onclick = async (e) => {
        e.preventDefault(); e.stopPropagation();
        await api.fetch('/api/queue/' + b.dataset.rm, { method: 'DELETE' });
        toast('حذف شد', 'ok');
        load();
      });
    }
    load();
  }

  /* ==================================================================
     Komikku catalog page
     ================================================================== */
  async function initKomikku() {
    applyTheme(getTheme());
    let allSources = [];

    // Load languages
    const langs = await api.fetch('/api/komikku/languages').then(r => r.json()).catch(() => []);
    const langSel = $('#langFilter');
    langs.forEach(l => langSel.add(new Option(`${l.lang} (${l.count})`, l.lang)));

    async function load() {
      const el = $('#list');
      el.innerHTML = '<p class="muted center" style="grid-column:1/-1">در حال بارگذاری…</p>';
      const lang = langSel.value;
      const q = $('#search').value.trim();
      const scrapableOnly = $('#scrapableOnly').checked;
      const params = new URLSearchParams();
      if (lang) params.set('lang', lang);
      if (q) params.set('q', q);
      params.set('limit', '500');
      const list = await api.fetch('/api/komikku/sources?' + params).then(r => r.json()).catch(() => []);
      allSources = list;
      const filtered = scrapableOnly ? list.filter(s => s.scrapable) : list;
      $('#stats').textContent = `${filtered.length.toLocaleString('fa-IR')} منبع${scrapableOnly ? ' قابل اسکرپ' : ''} از کل ${list.length.toLocaleString('fa-IR')}`;
      if (!filtered.length) {
        el.innerHTML = '<p class="empty" style="grid-column:1/-1"><span class="icon">📭</span>هیچ منبعی یافت نشد.</p>';
        return;
      }
      el.innerHTML = filtered.slice(0, 200).map(s => `
        <div class="card" style="cursor:default">
          ${s.scrapable
            ? '<span class="site-tag" style="background:var(--accent-2);color:#06281d">✓ قابل اسکرپ</span>'
            : '<span class="site-tag" style="background:var(--muted);color:#fff">فقط مرور</span>'}
          <h3 style="margin-top:.4rem">${esc(s.name)}</h3>
          <span class="author">${esc(s.lang || '')} ${s.nsfw ? '· 🔞' : ''}</span>
          ${s.baseUrl ? `<a href="${esc(s.baseUrl)}" target="_blank" class="muted" style="font-size:.75rem;word-break:break-all;display:block;margin-top:.3rem">${esc(s.baseUrl)}</a>` : ''}
          <div class="actions" style="margin-top:.5rem">
            ${s.scrapable && s.baseUrl
              ? `<button class="btn tiny primary" data-scrape="${esc(s.baseUrl)}">+ افزودن به کتابخونه</button>`
              : `<a class="btn tiny ghost" href="${esc(s.baseUrl || '#')}" target="_blank">باز کردن سایت ↗</a>`}
          </div>
        </div>`).join('');
      if (filtered.length > 200) {
        el.innerHTML += `<p class="muted center" style="grid-column:1/-1;font-size:.85rem">۲۰۰ منبع اول نشون داده شد. برای دیدن بقیه جستجو کن.</p>`;
      }
      $$('[data-scrape]').forEach(b => b.onclick = async () => {
        const r = await api.fetch('/api/komikku/scrape', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: b.dataset.scrape, limit: 3 })
        }).then(r => r.json());
        if (r.jobId) toast('اسکرپ شروع شد — به صفحهٔ کتابخونه برگرد', 'ok');
        else toast('خطا: ' + JSON.stringify(r), 'err');
      });
    }

    $('#search').oninput = load;
    langSel.onchange = load;
    $('#scrapableOnly').onchange = load;
    $('#refresh').onclick = async () => {
      $('#refresh').disabled = true;
      const r = await api.fetch('/api/komikku/refresh', { method: 'POST' }).then(r => r.json());
      $('#refresh').disabled = false;
      if (r.ok) { toast('کاتالوگ بروزرسانی شد', 'ok'); load(); }
      else toast('خطا: ' + r.error, 'err');
    };
    load();
  }

  /* ==================================================================
     Settings page (extended)
     ================================================================== */
  async function initSettings() {
    applyTheme(getTheme());

    const settings = await api.settings();
    console.log('settings', settings);

    $$('[data-set-theme]').forEach(b => {
      b.onclick = () => { applyTheme(b.dataset.setTheme); toast('تم ذخیره شد', 'ok'); };
    });

    $('#defaultFont').value = settings.ui?.fontFamily || 'Vazirmatn';
    $('#defaultFs').value = settings.ui?.fontSize || 18;
    $('#defaultLh').value = settings.ui?.lineHeight || 1.9;
    $('#provider').value = settings.activeProvider || 'opencode';
    $('#model').value = settings.activeModel || '';
    $('#providerStatus').textContent = settings.translatorConfigured ? `✓ پیکربندی شده (${settings.activeProvider})` : '✗ پیکربندی نشده — config.json رو ویرایش کن';
    $('#dbMode').textContent = settings.ui?.dbMode || 'SQLite';
    $('#authStatus').textContent = settings.authEnabled ? 'فعال' : 'غیرفعال';

    async function save() {
      await api.setSettings({
        fontFamily: $('#defaultFont').value,
        fontSize: parseInt($('#defaultFs').value),
        lineHeight: parseFloat($('#defaultLh').value)
      });
      toast('تنظیمات ذخیره شد', 'ok');
    }
    $('#defaultFont').onchange = save;
    $('#defaultFs').onchange = save;
    $('#defaultLh').onchange = save;
    $('#provider').onchange = save;
    $('#model').onchange = save;

    $('#pruneJobs').onclick = async () => {
      // Reuse the existing endpoint by calling stats endpoint after a delay
      toast('Jobهای قدیمی در چرخهٔ بعدی پاک می‌شن', 'ok');
    };
    $('#logoutBtn').onclick = async () => {
      await api.logout();
      toast('خارج شدی', 'ok');
      setTimeout(() => location.href = '/', 800);
    };
  }

  /* ==================================================================
     Discover Page
     ================================================================== */
  async function initDiscover() {
    applyTheme(getTheme());
    sse.ensure();

    const container = $('#randomNovelContainer');
    const tasteContainer = $('#tasteRecommendations');
    const genreContainer = $('#genreResults');
    const sourcesContainer = $('#sourcesList');
    const searchSection = $('#searchSection');
    const searchResults = $('#searchResults');

    // Render a single novel card in grid
    function novelCardHtml(n, isOnline = true) {
      const genresHtml = n.genres ? `<div class="genre-chips">${n.genres.map(g => `<span class="genre-chip" style="pointer-events:none">${g}</span>`).join('')}</div>` : '';
      return `
        <div class="card">
          ${coverHtml(n.coverUrl)}
          <h3>${esc(n.title)}</h3>
          <span class="author">${esc(n.author || 'ناشناس')}</span>
          ${genresHtml}
          <p class="desc" style="font-size:.8rem;color:var(--fg-soft);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin:.5rem 0">${esc(n.description || '')}</p>
          <button class="btn primary small block install-btn" data-url="${esc(n.sourceUrl)}" data-title="${esc(n.title || '')}" data-author="${esc(n.author || '')}" data-desc="${esc((n.description || '').slice(0, 300))}" data-cover="${esc(n.coverUrl || '')}" data-site="${esc(n.sourceSite || '')}">📥 افزودن به کتابخونه</button>
        </div>
      `;
    }

    // Helper to bind installation button — opens the modal
    function bindInstallButtons(parentEl) {
      parentEl.querySelectorAll('.install-btn').forEach(btn => {
        btn.onclick = async () => {
          const novelInfo = {
            sourceUrl: btn.dataset.url,
            title: btn.dataset.title,
            author: btn.dataset.author,
            description: btn.dataset.desc,
            coverUrl: btn.dataset.cover,
            sourceSite: btn.dataset.site
          };
          if (!novelInfo.sourceUrl) {
            toast('این رمان لینک منبع نداره', 'err');
            return;
          }
          const r = await addNovelWithModal(novelInfo);
          if (r && r.jobId) {
            btn.disabled = true;
            btn.textContent = 'در حال دانلود…';
            // Watch the scrape job to redirect when ready
            sse.on('job:done', (d) => {
              if (d.id === r.jobId && d.type === 'scrape') {
                toast('✓ رمان با موفقیت اضافه شد', 'ok');
                setGlobalProgress(null);
                setTimeout(() => location.href = '/detail?id=' + d.result.novelId, 800);
              }
            });
            sse.on('job:failed', (d) => {
              if (d.id === r.jobId) {
                toast('✗ خطا: ' + d.error, 'err');
                btn.disabled = false;
                btn.textContent = '📥 افزودن به کتابخونه';
                setGlobalProgress(null);
              }
            });
          }
        };
      });
    }

    // 1. Load Random Novel
    async function loadRandom() {
      container.innerHTML = '<div class="random-card skeleton" style="height:160px"></div>';
      const n = await fetch('/api/discover/random').then(r => r.json()).catch(() => null);
      if (!n) {
        container.innerHTML = '<p class="muted">امکان بارگذاری رمان تصادفی وجود ندارد.</p>';
        return;
      }
      container.innerHTML = `
        <div class="random-card">
          ${coverHtml(n.coverUrl)}
          <div class="details">
            <h3>${esc(n.title)}</h3>
            <div class="author">نویسنده: ${esc(n.author || 'ناشناس')}</div>
            <p class="desc">${esc(n.description)}</p>
            <div class="genre-chips" style="margin-bottom:.8rem">
              ${n.genres.map(g => `<span class="genre-chip" style="pointer-events:none">${esc(g)}</span>`).join('')}
            </div>
            <button class="btn primary install-btn" data-url="${esc(n.sourceUrl)}" data-title="${esc(n.title)}" data-author="${esc(n.author || 'ناشناس')}" data-desc="${esc((n.description || '').slice(0, 300))}" data-cover="${esc(n.coverUrl || '')}" data-site="${esc(n.sourceSite || '')}" style="padding:.45rem .9rem;font-size:.85rem">📥 افزودن به کتابخونه</button>
          </div>
        </div>
      `;
      bindInstallButtons(container);
    }
    $('#rollRandomBtn').onclick = loadRandom;
    loadRandom();

    // 2. Load Taste Recommendations
    async function loadTaste() {
      tasteContainer.innerHTML = Array.from({length:3}).map(() => '<div class="skeleton" style="height:220px"></div>').join('');
      const list = await fetch('/api/discover/taste').then(r => r.json()).catch(() => []);
      if (!list.length) {
        tasteContainer.innerHTML = '<p class="muted col-xs-12">هنوز رمانی در کتابخانه ندارید تا سلیقه شما تحلیل شود.</p>';
        return;
      }
      tasteContainer.innerHTML = list.map(n => novelCardHtml(n)).join('');
      bindInstallButtons(tasteContainer);
    }
    loadTaste();

    // 3. Load Genre Books
    async function loadGenre(genre) {
      genreContainer.innerHTML = Array.from({length:3}).map(() => '<div class="skeleton" style="height:220px"></div>').join('');
      const list = await fetch(`/api/discover/genre?g=${encodeURIComponent(genre)}`).then(r => r.json()).catch(() => []);
      if (!list.length) {
        genreContainer.innerHTML = '<p class="muted">خطا در دریافت لیست ژانر.</p>';
        return;
      }
      genreContainer.innerHTML = list.map(n => novelCardHtml(n)).join('');
      bindInstallButtons(genreContainer);
    }
    
    // Bind genre chips
    $$('#genreChips .genre-chip').forEach(chip => {
      chip.onclick = () => {
        $$('#genreChips .genre-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        loadGenre(chip.dataset.genre);
      };
    });
    loadGenre('Fantasy');

    // 4. Load Sources List
    async function loadSources() {
      const list = await fetch('/api/discover/sources').then(r => r.json()).catch(() => []);
      sourcesContainer.innerHTML = list.map(s => `
        <div class="source-card">
          <div>
            <h4>${esc(s.name)} <span class="badge-lang">${esc(s.lang)}</span></h4>
            <p>${esc(s.description)}</p>
          </div>
          <div style="font-size:.75rem;color:var(--accent);font-weight:500">ژانرها: ${s.genres.map(esc).join(' · ')}</div>
        </div>
      `).join('');
    }
    loadSources();

    // 5. Online Search Handling
    async function performSearch() {
      const q = $('#onlineSearchInput').value.trim();
      if (!q) {
        toast('عبارتی برای جستجو وارد کنید', 'err');
        return;
      }
      searchSection.classList.remove('hide');
      searchResults.innerHTML = Array.from({length:3}).map(() => '<div class="skeleton" style="height:220px"></div>').join('');
      
      const list = await fetch(`/api/discover/search?q=${encodeURIComponent(q)}`).then(r => r.json()).catch(() => []);
      if (!list.length) {
        searchResults.innerHTML = '<p class="muted col-xs-12 center">رمانی پیدا نشد. نام انگلیسی یا کلمه کلیدی دیگری جستجو کنید.</p>';
        return;
      }
      searchResults.innerHTML = list.map(n => novelCardHtml(n)).join('');
      bindInstallButtons(searchResults);
    }

    $('#onlineSearchBtn').onclick = performSearch;
    $('#onlineSearchInput').onkeydown = (e) => {
      if (e.key === 'Enter') performSearch();
    };
  }

  /* ==================================================================
     Login page
     ================================================================== */
  function initLogin() {
    applyTheme(getTheme());
    $('#loginForm').onsubmit = async (e) => {
      e.preventDefault();
      const r = await api.login($('#username').value, $('#password').value);
      if (r.token) {
        toast('خوش اومدی 👋', 'ok');
        setTimeout(() => location.href = '/', 600);
      } else {
        toast('نام کاربری یا رمز اشتباه', 'err');
      }
    };
  }

  /* ==================================================================
     Add-novel modal — used by catalog, discover, home, admin pages
     Lets user choose:
       - chapter range to download (from / to)
       - whether to auto-translate
       - if auto-translate, what range to translate
     Returns the job response.
     ================================================================== */
  function openAddNovelModal(novelInfo) {
    // novelInfo: { title, author, sourceUrl, coverUrl, sourceSite, description, totalChapters? }
    return new Promise((resolve) => {
      // Build modal HTML
      const modal = document.createElement('div');
      modal.className = 'modal-backdrop';
      modal.style.zIndex = '200';
      modal.innerHTML = `
        <div class="modal" style="max-width:560px">
          <h3 style="margin:0 0 .8rem;display:flex;align-items:center;gap:.5rem">
            ${novelInfo.coverUrl
              ? `<img src="/api/img?src=${encodeURIComponent(novelInfo.coverUrl)}" alt="" style="width:48px;height:64px;border-radius:6px;object-fit:cover" onerror="this.style.display='none'">`
              : '<span style="font-size:1.6rem">📖</span>'}
            <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(novelInfo.title || 'افزودن رمان')}</span>
          </h3>
          ${novelInfo.author ? `<div class="muted" style="font-size:.85rem;margin-bottom:.8rem">نویسنده: ${esc(novelInfo.author)}</div>` : ''}
          ${novelInfo.description ? `<div class="muted" style="font-size:.82rem;line-height:1.6;margin-bottom:1rem;max-height:80px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical">${esc(novelInfo.description.slice(0, 400))}</div>` : ''}
          ${novelInfo.sourceSite ? `<div class="badge" style="margin-bottom:1rem;display:inline-block">منبع: ${esc(novelInfo.sourceSite)}</div>` : ''}

          <div class="settings-section" style="background:var(--bg-soft);padding:1rem;margin:0 0 1rem">
            <h4 style="margin:0 0 .8rem;font-size:.95rem">📥 دانلود فصل‌ها</h4>
            <label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem;margin-bottom:.6rem;cursor:pointer">
              <input type="radio" name="dlMode" value="all" style="width:auto;margin:0">
              <span>همه فصل‌ها${novelInfo.totalChapters ? ` (${novelInfo.totalChapters.toLocaleString('fa-IR')} فصل)` : ''}</span>
            </label>
            <label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem;margin-bottom:.6rem;cursor:pointer">
              <input type="radio" name="dlMode" value="range" checked style="width:auto;margin:0">
              <span>فقط محدوده خاص:</span>
            </label>
            <div style="display:flex;gap:.6rem;align-items:center;margin:0 0 .6rem 1.5rem">
              <span class="muted" style="font-size:.8rem">از فصل:</span>
              <input type="number" id="dlStart" min="1" value="1" style="width:80px;padding:.4rem;border-radius:6px;border:1px solid var(--border);background:var(--card);color:var(--fg);font-family:inherit">
              <span class="muted" style="font-size:.8rem">تا فصل:</span>
              <input type="number" id="dlEnd" min="1" value="${Math.min(10, novelInfo.totalChapters || 10)}" style="width:80px;padding:.4rem;border-radius:6px;border:1px solid var(--border);background:var(--card);color:var(--fg);font-family:inherit">
              <span class="muted" style="font-size:.75rem">${novelInfo.totalChapters ? `(از ${novelInfo.totalChapters.toLocaleString('fa-IR')})` : ''}</span>
            </div>
            <div class="muted" style="font-size:.75rem;margin-left:1.5rem">
              <span id="dlCount">۱۰</span> فصل دانلود می‌شه
            </div>
          </div>

          <div class="settings-section" style="background:var(--bg-soft);padding:1rem;margin:0 0 1rem">
            <h4 style="margin:0 0 .8rem;font-size:.95rem">🌐 ترجمه</h4>
            <label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem;margin-bottom:.6rem;cursor:pointer">
              <input type="checkbox" id="trAuto" checked style="width:auto;margin:0">
              <span>بعد از دانلود، خودکار ترجمه کن</span>
            </label>
            <div id="trRangeBox" style="margin:0 0 .4rem 1.5rem">
              <label style="display:flex;align-items:center;gap:.4rem;font-size:.8rem;margin-bottom:.5rem;cursor:pointer">
                <input type="radio" name="trMode" value="dl" checked style="width:auto;margin:0">
                <span>ترجمه همون فصل‌هایی که دانلود شد</span>
              </label>
              <label style="display:flex;align-items:center;gap:.4rem;font-size:.8rem;margin-bottom:.5rem;cursor:pointer">
                <input type="radio" name="trMode" value="range" style="width:auto;margin:0">
                <span>ترجمه محدوده دیگه:</span>
              </label>
              <div style="display:flex;gap:.5rem;align-items:center;margin:0 0 0 1.5rem">
                <span class="muted" style="font-size:.75rem">از:</span>
                <input type="number" id="trStart" min="1" value="1" style="width:70px;padding:.35rem;border-radius:6px;border:1px solid var(--border);background:var(--card);color:var(--fg);font-family:inherit;font-size:.8rem">
                <span class="muted" style="font-size:.75rem">تا:</span>
                <input type="number" id="trEnd" min="1" value="10" style="width:70px;padding:.35rem;border-radius:6px;border:1px solid var(--border);background:var(--card);color:var(--fg);font-family:inherit;font-size:.8rem">
              </div>
            </div>
            <div class="muted" style="font-size:.75rem;margin-left:1.5rem">⚠ هر فصل حدود ۲-۵ ثانیه ترجمه طول می‌کشه</div>
          </div>

          <div class="actions" style="display:flex;gap:.5rem;justify-content:flex-end">
            <button type="button" class="btn ghost" data-act="cancel">انصراف</button>
            <button type="button" class="btn primary" data-act="add">📥 شروع دانلود</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      const dlStart = modal.querySelector('#dlStart');
      const dlEnd = modal.querySelector('#dlEnd');
      const dlCount = modal.querySelector('#dlCount');
      const trAuto = modal.querySelector('#trAuto');
      const trRangeBox = modal.querySelector('#trRangeBox');
      const trStart = modal.querySelector('#trStart');
      const trEnd = modal.querySelector('#trEnd');

      // Sync translate defaults with download range
      function updateTrDefaults() {
        if (trStart.value === '' || parseInt(trStart.value) < parseInt(dlStart.value)) {
          trStart.value = dlStart.value;
        }
        if (trEnd.value === '' || parseInt(trEnd.value) > parseInt(dlEnd.value) || parseInt(trEnd.value) < parseInt(trStart.value)) {
          trEnd.value = dlEnd.value;
        }
      }

      function updateCount() {
        const s = parseInt(dlStart.value) || 1;
        const e = parseInt(dlEnd.value) || s;
        const n = Math.max(0, e - s + 1);
        dlCount.textContent = n.toLocaleString('fa-IR');
      }
      dlStart.oninput = () => { updateCount(); updateTrDefaults(); };
      dlEnd.oninput = () => { updateCount(); updateTrDefaults(); };

      trAuto.onchange = () => {
        trRangeBox.style.opacity = trAuto.checked ? '1' : '.5';
        trRangeBox.style.pointerEvents = trAuto.checked ? 'auto' : 'none';
      };

      function close(result) {
        modal.remove();
        resolve(result);
      }

      modal.addEventListener('click', (e) => {
        if (e.target === modal) close(null);
        if (e.target.dataset.act === 'cancel') close(null);
        if (e.target.dataset.act === 'add') {
          const dlMode = modal.querySelector('input[name=dlMode]:checked').value;
          const startCh = parseInt(dlStart.value) || 1;
          const endCh = dlMode === 'all' ? null : (parseInt(dlEnd.value) || startCh);
          if (endCh !== null && endCh < startCh) {
            toast('فصل پایان باید بزرگتر از فصل شروع باشه', 'err');
            return;
          }
          const shouldTranslate = trAuto.checked;
          const trMode = modal.querySelector('input[name=trMode]:checked').value;
          let trStartV = null, trEndV = null;
          if (shouldTranslate && trMode === 'range') {
            trStartV = parseInt(trStart.value) || 1;
            trEndV = parseInt(trEnd.value) || trStartV;
            if (trEndV < trStartV) {
              toast('محدوده ترجمه نامعتبره', 'err');
              return;
            }
          }
          close({
            url: novelInfo.sourceUrl,
            startChapter: startCh,
            endChapter: endCh,
            autoTranslate: shouldTranslate,
            translateStart: trStartV,
            translateEnd: trEndV
          });
        }
      });
    });
  }

  /* Helper: open modal and submit job, show progress */
  async function addNovelWithModal(novelInfo) {
    const opts = await openAddNovelModal(novelInfo);
    if (!opts) return null; // user cancelled
    setGlobalProgress(0);
    toast('در حال شروع دانلود…');
    try {
      const resp = await fetch('/api/add', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: opts.url,
          limit: opts.endChapter ? (opts.endChapter - opts.startChapter + 1) : 5,
          autoTranslate: opts.autoTranslate,
          startChapter: opts.startChapter,
          endChapter: opts.endChapter,
          translateStart: opts.translateStart,
          translateEnd: opts.translateEnd
        })
      }).then(r => r.json());

      if (resp.jobId) {
        const count = opts.endChapter ? (opts.endChapter - opts.startChapter + 1).toLocaleString('fa-IR') : 'چند';
        toast(`دانلود شروع شد — ${count} فصل`, 'ok');
        return resp;
      } else {
        toast('خطا: ' + JSON.stringify(resp), 'err');
        setGlobalProgress(null);
        return null;
      }
    } catch (e) {
      toast('خطا: ' + e.message, 'err');
      setGlobalProgress(null);
      return null;
    }
  }

  /* ==================================================================
     Mobile drawer — auto-wire on every page that has #drawer
     ================================================================== */
  function setupDrawer() {
    const drawer = $('#drawer');
    const backdrop = $('#drawerBackdrop');
    // Pages use either #menuToggle (standard header) or #menuToggleReader (reader page)
    const toggle = $('#menuToggle') || $('#menuToggleReader');
    if (!drawer || !toggle) return;

    let open = false;
    function setOpen(v) {
      open = v;
      drawer.classList.toggle('open', open);
      if (backdrop) backdrop.classList.toggle('show', open);
      toggle.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    }

    toggle.onclick = (e) => { e.stopPropagation(); setOpen(!open); };
    if (backdrop) backdrop.onclick = () => setOpen(false);
    const closeBtn = $('#drawerClose');
    if (closeBtn) closeBtn.onclick = () => setOpen(false);

    // Close drawer on Escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && open) setOpen(false);
    });

    // Close drawer when clicking a link (so navigation feels snappy)
    drawer.addEventListener('click', (e) => {
      const a = e.target.closest('a');
      if (a) setOpen(false);
    });

    // Close drawer on resize to desktop
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768 && open) setOpen(false);
    });
  }

  /* ==================================================================
     Home dashboard page
     ================================================================== */
  async function initHome() {
    applyTheme(getTheme());
    sse.ensure();

    // Load stats + novels + recent sessions in parallel
    const [stats, novels, sessions, recs] = await Promise.all([
      api.stats().catch(() => ({})),
      api.novels().catch(() => []),
      api.fetch('/api/reading/sessions?limit=20').then(r => r.json()).catch(() => []),
      api.fetch('/api/discover/taste').then(r => r.json()).catch(() => [])
    ]);

    // Quick stats
    const fa = n => (n || 0).toLocaleString('fa-IR');
    $('#qsNovels').textContent = fa(stats.novels);
    $('#qsChapters').textContent = fa(stats.chapters);
    $('#qsTranslated').textContent = fa(stats.translated);
    try {
      const r = await api.fetch('/api/reading/stats?range=week').then(r => r.json()).catch(() => ({}));
      $('#qsStreak').textContent = fa(r.streak || 0);
    } catch {}

    // Continue reading: most recent sessions, deduped by novel
    const continueEl = $('#continueReading');
    const seenNovels = new Set();
    const continueItems = [];
    for (const s of sessions) {
      const nid = s.novel_id || s.novelId;
      if (nid && !seenNovels.has(nid)) {
        const novel = novels.find(n => n.id === nid);
        if (novel) {
          seenNovels.add(nid);
          const chIdx = s.chapter_index ?? s.chapterIndex ?? 0;
          continueItems.push({ novel, chIdx });
          if (continueItems.length >= 4) break;
        }
      }
    }
    if (!continueItems.length) {
      continueEl.innerHTML = '<p class="muted center" style="padding:1.5rem;font-size:.9rem">هنوز شروع نکردی! یه رمان از <a href="/discover" style="color:var(--accent)">بخش کشف</a> پیدا کن.</p>';
    } else {
      continueEl.innerHTML = continueItems.map(({ novel, chIdx }) => `
        <a class="continue-card" href="/read?novel=${novel.id}&ch=${chIdx}">
          ${novel.coverUrl
            ? `<img src="/api/img?src=${encodeURIComponent(novel.coverUrl)}" alt="" onerror="this.style.display='none'">`
            : '<div style="width:60px;height:80px;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);border-radius:6px;font-size:1.5rem">📖</div>'}
          <div class="info">
            <h4>${esc(novel.title)}</h4>
            <div class="chapter">فصل ${(chIdx + 1).toLocaleString('fa-IR')} از ${(novel.chapterCount || 0).toLocaleString('fa-IR')}</div>
            <div class="progress-bar"><i style="width:${novel.chapterCount ? Math.round(((chIdx + 1) / novel.chapterCount) * 100) : 0}%"></i></div>
          </div>
        </a>`).join('');
    }

    // Library preview
    const libEl = $('#libraryPreview');
    if (!novels.length) {
      libEl.innerHTML = '<p class="muted center" style="grid-column:1/-1;padding:1rem;font-size:.9rem">کتابخونه خالی است.</p>';
    } else {
      libEl.innerHTML = novels.slice(0, 8).map(n => `
        <a class="mini-card" href="/detail?id=${n.id}">
          ${n.coverUrl
            ? `<img src="/api/img?src=${encodeURIComponent(n.coverUrl)}" alt="" loading="lazy" onerror="this.outerHTML='<div style=&quot;width:100%;aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);border-radius:6px;font-size:1.5rem&quot;>📖</div>'">`
            : '<div style="width:100%;aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);border-radius:6px;font-size:1.5rem">📖</div>'}
          <h4>${esc(n.title)}</h4>
          <div class="author">${esc(n.author || '')}</div>
        </a>`).join('');
    }

    // Recommended
    const recEl = $('#recommended');
    if (!recs.length) {
      recEl.innerHTML = '<p class="muted center" style="grid-column:1/-1;padding:1rem;font-size:.9rem">هنوز پیشنهادی نیست.</p>';
    } else {
      recEl.innerHTML = recs.slice(0, 6).map(n => `
        <div class="mini-card" data-url="${esc(n.sourceUrl || '')}" data-title="${esc(n.title || '')}" data-author="${esc(n.author || '')}" data-desc="${esc((n.description || '').slice(0, 300))}" data-cover="${esc(n.coverUrl || '')}" data-site="${esc(n.sourceSite || '')}">
          ${n.coverUrl
            ? `<img src="/api/img?src=${encodeURIComponent(n.coverUrl)}" alt="" loading="lazy" onerror="this.style.display='none'">`
            : '<div style="width:100%;aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);border-radius:6px;font-size:1.5rem">📖</div>'}
          <h4>${esc(n.title)}</h4>
          <div class="author">${esc(n.author || '')}</div>
        </div>`).join('');
      recEl.querySelectorAll('.mini-card').forEach(c => {
        c.onclick = async () => {
          const novelInfo = {
            sourceUrl: c.dataset.url,
            title: c.dataset.title,
            author: c.dataset.author,
            description: c.dataset.desc,
            coverUrl: c.dataset.cover,
            sourceSite: c.dataset.site
          };
          if (!novelInfo.sourceUrl) return;
          const r = await addNovelWithModal(novelInfo);
          if (r && r.jobId) {
            sse.on('job:done', (d) => {
              if (d.id === r.jobId && d.type === 'scrape') {
                setGlobalProgress(null);
                location.href = '/detail?id=' + d.result.novelId;
              }
            });
          }
        };
      });
    }

    // Quick add novel button
    $('#quickAddNovel').onclick = async () => {
      const url = prompt('لینک رمان رو اینجا بذار:');
      if (!url || !/^https?:/.test(url)) {
        toast('لینک معتبر نیست', 'err');
        return;
      }
      const novelInfo = { sourceUrl: url };
      const r = await addNovelWithModal(novelInfo);
      if (r && r.jobId) {
        sse.on('job:done', (d) => {
          if (d.id === r.jobId && d.type === 'scrape') {
            setGlobalProgress(null);
            location.href = '/detail?id=' + d.result.novelId;
          }
        });
      }
    };
  }

  /* ==================================================================
     Catalog page (multi-site browser)
     ================================================================== */
  async function initCatalog() {
    applyTheme(getTheme());

    let currentTab = 'trending';
    let selectedSite = '';
    let sources = [];
    let allGenres = [];

    // Load sources
    sources = await api.fetch('/api/discover/sources').then(r => r.json()).catch(() => []);
    const sfEl = $('#sourceFilter');
    sources.forEach(s => {
      const chip = document.createElement('span');
      chip.className = 'source-chip';
      chip.dataset.site = s.id;
      chip.innerHTML = `<span>${esc(s.name)}</span>`;
      chip.onclick = () => {
        selectedSite = chip.dataset.site;
        $$('#sourceFilter .source-chip').forEach(c => c.classList.toggle('active', c === chip));
        loadResults();
      };
      sfEl.appendChild(chip);
    });

    // Load genres
    allGenres = await api.fetch('/api/discover/genres').then(r => r.json()).catch(() => []);
    const gbEl = $('#genreBar');
    let selectedGenre = '';
    allGenres.forEach(g => {
      const chip = document.createElement('span');
      chip.className = 'genre-chip';
      chip.dataset.genre = g;
      chip.textContent = g;
      chip.onclick = () => {
        selectedGenre = g;
        $$('#genreBar .genre-chip').forEach(c => c.classList.toggle('active', c === chip));
        loadResults();
      };
      gbEl.appendChild(chip);
    });
    // Default select first genre
    const firstGenre = gbEl.querySelector('.genre-chip');
    if (firstGenre) firstGenre.classList.add('active');
    selectedGenre = allGenres[0] || 'Fantasy';

    // Tabs
    $$('.view-toggle button').forEach(b => {
      b.onclick = () => {
        currentTab = b.dataset.tab;
        $$('.view-toggle button').forEach(x => x.classList.toggle('active', x === b));
        // Show/hide genre bar and search box
        $('#genreBar').classList.toggle('hide', currentTab !== 'genre');
        $('#searchBox').classList.toggle('hide', currentTab !== 'search');
        loadResults();
      };
    });

    // Search
    const doSearch = () => loadResults();
    $('#searchBtn').onclick = doSearch;
    $('#searchInput').onkeydown = (e) => { if (e.key === 'Enter') doSearch(); };

    async function loadResults() {
      const el = $('#results');
      el.innerHTML = Array.from({length: 6}).map(() => '<div class="skeleton" style="height:90px"></div>').join('');
      $('#resultsCount').textContent = '';

      const sitesParam = selectedSite ? `&sites=${selectedSite}` : '';
      let url = '';
      let title = '';

      if (currentTab === 'trending') {
        title = '🔥 ترندینگ';
        url = `/api/discover/trending?${sitesParam}`;
      } else if (currentTab === 'popular') {
        title = '⭐ محبوب‌ترین‌ها';
        url = `/api/discover/popular?${sitesParam}`;
      } else if (currentTab === 'genre') {
        title = `🏷️ ژانر: ${selectedGenre}`;
        url = `/api/discover/genre?g=${encodeURIComponent(selectedGenre)}${sitesParam}`;
      } else if (currentTab === 'search') {
        const q = $('#searchInput').value.trim();
        if (!q) {
          el.innerHTML = '<p class="muted center" style="padding:2rem">عبارتی برای جستجو وارد کن.</p>';
          $('#resultsTitle').textContent = '🔎 جستجو';
          return;
        }
        title = `🔎 نتایج جستجو: ${q}`;
        url = `/api/discover/search?q=${encodeURIComponent(q)}${sitesParam}`;
      }

      $('#resultsTitle').textContent = title;

      try {
        const list = await api.fetch(url).then(r => r.json());
        $('#resultsCount').textContent = list.length ? `${list.length.toLocaleString('fa-IR')} رمان` : '';
        if (!list.length) {
          el.innerHTML = '<p class="muted center" style="padding:2rem">نتیجه‌ای یافت نشد.</p>';
          return;
        }
        el.innerHTML = list.map(n => `
          <div class="novel-card-mini" data-url="${esc(n.sourceUrl || '')}">
            ${n.coverUrl
              ? `<img src="/api/img?src=${encodeURIComponent(n.coverUrl)}" alt="" loading="lazy" onerror="this.style.display='none'">`
              : '<div style="width:56px;height:80px;display:flex;align-items:center;justify-content:center;background:var(--bg-soft);border-radius:6px;font-size:1.2rem">📖</div>'}
            <div class="info">
              <h4>${esc(n.title)} <span class="source-tag-mini">${esc(n.sourceSite || '')}</span></h4>
              <div class="author">${esc(n.author || 'نامشخص')}</div>
              ${n.description ? `<div class="desc">${esc(n.description.slice(0, 200))}</div>` : ''}
              <button class="install-btn-mini" data-install="${esc(n.sourceUrl || '')}" data-title="${esc(n.title || '')}" data-author="${esc(n.author || '')}" data-desc="${esc((n.description || '').slice(0, 300))}" data-cover="${esc(n.coverUrl || '')}" data-site="${esc(n.sourceSite || '')}">📥 افزودن به کتابخونه</button>
            </div>
          </div>`).join('');

        // Bind install buttons — open modal
        el.querySelectorAll('[data-install]').forEach(btn => {
          btn.onclick = async (e) => {
            e.stopPropagation();
            const novelInfo = {
              sourceUrl: btn.dataset.install,
              title: btn.dataset.title,
              author: btn.dataset.author,
              description: btn.dataset.desc,
              coverUrl: btn.dataset.cover,
              sourceSite: btn.dataset.site
            };
            if (!novelInfo.sourceUrl) return;
            const r = await addNovelWithModal(novelInfo);
            if (r && r.jobId) {
              btn.disabled = true;
              btn.textContent = 'در حال دانلود…';
              sse.on('job:done', (d) => {
                if (d.id === r.jobId && d.type === 'scrape') {
                  setGlobalProgress(null);
                  toast('✓ اضافه شد! در حال انتقال…', 'ok');
                  setTimeout(() => location.href = '/detail?id=' + d.result.novelId, 800);
                }
              });
              sse.on('job:failed', (d) => {
                if (d.id === r.jobId) {
                  setGlobalProgress(null);
                  btn.disabled = false;
                  btn.textContent = '📥 افزودن به کتابخونه';
                  toast('خطا: ' + d.error, 'err');
                }
              });
            }
          };
        });
      } catch (e) {
        el.innerHTML = '<p class="muted center" style="padding:2rem">خطا در بارگذاری.</p>';
      }
    }

    loadResults();
  }

  /* ---------- Public API ---------- */
  window.NR = {
    initLibrary, initDetail, initReader, initAdmin,
    initSearch, initStats, initSettings, initLogin,
    initHistory, initHighlights, initAchievements, initGoals,
    initUpdates, initWiki, initQueue, initKomikku, initDiscover,
    initHome, initCatalog,
    api, sse, toast, applyTheme, getTheme, setGlobalProgress,
    setupDrawer, addNovelWithModal, openAddNovelModal
  };

  // Apply theme as early as possible
  applyTheme(getTheme());
  // Wire up drawer on every page
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupDrawer);
  } else {
    setupDrawer();
  }
})();
