const { spawn } = require('child_process');

const server = spawn('node', ['server.js'], { 
  stdio: ['ignore', 'pipe', 'pipe'],
  cwd: '/home/user'
});

server.stdout.on('data', (data) => {
  console.log('SERVER:', data.toString().trim());
});

server.stderr.on('data', (data) => {
  console.error('SERVER ERR:', data.toString().trim());
});

async function waitForServer() {
  return new Promise(resolve => setTimeout(resolve, 5000));
}

async function test() {
  await waitForServer();
  
  const http = require('http');
  
  function request(path) {
    return new Promise((resolve, reject) => {
      http.get('http://127.0.0.1:8080' + path, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve(data));
      }).on('error', reject);
    });
  }

  try {
    const stats = await request('/api/stats');
    console.log('\n=== STATS ===', stats);
  } catch (e) {
    console.error('STATS error:', e.message);
  }

  try {
    const novels = await request('/api/novels');
    console.log('\n=== NOVELS ===', novels);
  } catch (e) {
    console.error('NOVELS error:', e.message);
  }

  try {
    const trending = await request('/api/discover/trending');
    console.log('\n=== TRENDING ===', trending.substring(0, 300));
  } catch (e) {
    console.error('TRENDING error:', e.message);
  }

  try {
    const popular = await request('/api/discover/popular');
    console.log('\n=== POPULAR ===', popular.substring(0, 300));
  } catch (e) {
    console.error('POPULAR error:', e.message);
  }

  try {
    const genre = await request('/api/discover/genre?g=Fantasy');
    console.log('\n=== GENRE Fantasy ===', genre.substring(0, 300));
  } catch (e) {
    console.error('GENRE error:', e.message);
  }

  try {
    const sources = await request('/api/discover/sources');
    console.log('\n=== SOURCES ===', sources.substring(0, 300));
  } catch (e) {
    console.error('SOURCES error:', e.message);
  }

  server.kill();
  process.exit(0);
}

test().catch(e => {
  console.error('Test failed:', e);
  server.kill();
  process.exit(1);
});