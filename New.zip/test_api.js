const http = require('http');

function request(path) {
  return new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:8080' + path, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

async function test() {
  console.log('Testing API endpoints...\n');
  
  try {
    const stats = await request('/api/stats');
    console.log('STATS:', stats);
  } catch (e) {
    console.error('STATS error:', e.message);
  }

  try {
    const novels = await request('/api/novels');
    console.log('NOVELS:', novels);
  } catch (e) {
    console.error('NOVELS error:', e.message);
  }

  try {
    const trending = await request('/api/discover/trending');
    console.log('TRENDING:', trending.substring(0, 200));
  } catch (e) {
    console.error('TRENDING error:', e.message);
  }

  try {
    const popular = await request('/api/discover/popular');
    console.log('POPULAR:', popular.substring(0, 200));
  } catch (e) {
    console.error('POPULAR error:', e.message);
  }

  try {
    const genre = await request('/api/discover/genre?g=Fantasy');
    console.log('GENRE:', genre.substring(0, 200));
  } catch (e) {
    console.error('GENRE error:', e.message);
  }
}

test().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });